$(document).ready(function () {
    var objPriceGroup = new priceGrouping();
    objPriceGroup.refreshSelectors();
    objPriceGroup.loadOptionStatus();
    objPriceGroup.getAllcustomersInGroups();

    $(document).on('click', '.Choice', function () {
        objPriceGroup.loadOptionStatus(this.value);
    });

    $(document).on('click', '.actionCol a', function () {
        objPriceGroup.handleActionResponce(this);
    });

    $(document).on('click', '.actionCol button,#add_group', function () {
        objPriceGroup.openCreateOrEditCustomerModal(this);
    });

    $(document).on('submit', '#PricingGroupForm', function (e) {
        e.preventDefault();
        objPriceGroup.cearteGroupPricing();
    });

    $(document).on('click', '#updatePrice', function (e) {
        e.preventDefault();
        objPriceGroup.savePricingFlavorForGroup();
    });

    $(document).on('click', '.commit', function (e) {
        var family = $(this).attr('family');
        var commitValue = $("#commitfield_" + family).val();
        $("#family_" + family).find('.cprice').val(commitValue);
    });

});
function priceGrouping() {
    this.refreshSelectors();
}
priceGrouping.prototype = {
    refreshSelectors: function () {
        this.selectorCustomerPricingForm = $('#CustomerPricingForm');
        this.selectorGroupPricingDiv = $('#GroupPricing');
        this.selectorGroupPricingTable = $('#GroupPricingTable');
        this.selectorOwnerId = $('#ownerId');
        this.selectorGroupName = $('#GpName');
        this.selectorGroupId = $('#g_Id');
        this.selectorCustomerTable = $('#customertable');
        this.selectorGroupModal = $('#GroupModal');
        this.selectorPricingGroupForm = $('#PricingGroupForm');
        this.selectorPricingModal = $('#PricingModal');
        this.selectorDataReceivedDiv = $('#dataReceived');
        this.selectorAllGroupPrices = $('.cprice');
    },
    loadOptionStatus: function (value) {
        let thisObj = this;
        if (value == 4) {
            thisObj.selectorCustomerPricingForm.hide();
            thisObj.selectorGroupPricingDiv.show();
            thisObj.loadGroupPricingTableInfo();
        } else {
            thisObj.selectorCustomerPricingForm.show();
            thisObj.selectorGroupPricingDiv.hide();
        }
    },
    loadGroupPricingTableInfo: function () {
        this.refreshSelectors();
        let thisObj = this;
        window.GroupPricingTable = this.selectorGroupPricingTable.DataTable({
            "ajax": {
                "url": apiUrl + 'pricing/load-price-grouping',
                "type": "GET",
                "data": {OwnerId: thisObj.selectorOwnerId.val()},
                "dataSrc": function (response) {
                    if (!response.status) {
                        return [];
                    }
                    return response.response;
                }
            },
            "columns": [
                {"data": "groupname"},
                {
                    class: 'textAligCenter actionCol',
                    mRender: function (data, type, full)
                    {
                        return `<center>
                                    <a class="btn btn-info btn-xs">
                                        <i class="glyphicon glyphicon-Edit"></i>
                                        Edit Pricing
                                    </a>
                                    <a class="btn btn-danger btn-xs remove">
                                        <i class="glyphicon glyphicon-remove"></i>
                                        Remove Group
                                    </a>
                                    <button class="btn btn-warning btn-xs">
                                        <i class="glyphicon glyphicon-edit"></i>
                                        Edit Customers
                                    </button>
                                </center>`;
                    }
                }
            ],
            createdRow: function (row, data, index) {
                $(row).attr('data-id', data.group_id);
            }
        });
    },
    reloadGroupPricingTable: function () {
        this.selectorGroupPricingTable.DataTable().ajax.reload();
    },
    cearteGroupPricing: function () {
        let thisObj = this;
        var cIds = [];
        $("input:checkbox:checked[name='cust_id[]']").each(function (i) {
            cIds[i] = $(this).val();
        });

        var uIds = [];
        $("input:checkbox:not(:checked)[name='cust_id[]']").each(function (i) {
            uIds[i] = $(this).val();
        });

        if (cIds.length == 0) {
            swal({
                title: "Error!",
                text: 'Please select customer for Group',
                icon: "warning",
                button: 'OK',
            });

            return;
        }

        var url = apiUrl + 'pricing/' + (this.selectorGroupId.val() == '' ? 'save-customers-group' : 'update-customers-group');
        var payload = this.selectorGroupId.val() == '' ? {ownerId: this.selectorOwnerId.val(), customerIds: cIds, GroupName: this.selectorGroupName.val()} : {ownerId: this.selectorOwnerId.val(), customerIds: cIds, uncheckIds: uIds, GroupName: this.selectorGroupName.val(), groupID: this.selectorGroupId.val()};

        ajax(url, 'post', payload).then(function (response) {
            swal({
                title: response.status ? response.response.title : "Error",
                text: response.status ? response.response.message : new Array(response.message, ...response.response).join('\n'),
                icon: response.status ? "success" : "error",
                button: "OK"
            }).then(function () {
                thisObj.reloadGroupPricingTable();
                thisObj.selectorGroupModal.modal('toggle');
            });
        });
    },
    loadCustomerInfo: function () {
        this.refreshSelectors();
        if (isSet(window.CustomerTable)) {
            this.reloadCustomerTable();
            $("input:checkbox[name='cust_id[]']").each(function (i) {
                $(this).attr('checked', false);
                $(this).attr('disabled', false);
            });
            return;
        }

        var url = apiUrl + 'order-forms/load-customers';
        var payload = {ownerId: this.selectorOwnerId.val()};


        window.CustomerTable = this.selectorCustomerTable.DataTable({
            "ajax": {
                "url": url,
                data: payload,
                "type": "GET",
                "dataSrc": function (response) {
                    if (!response.status) {
                        return [];
                    }
                    return response.response;
                }
            },
            "autoWidth": false,
            "scrollY": "300px",
            "scrollCollapse": true,
            "paging": false,
            "dom": '<"top"f>rt<"bottom"><"clear">',
            "columns": [
                {
                    'searchable': false,
                    'orderable': false,
                    'className': 'dt-body-center',
                    render: function (row, data, index) {
                        return `<input type="checkbox" name="cust_id[]" value="${index.id}">`;
                    }
                },
                {"data": "custname"},
                {"data": "custaddress"}
            ]
        });

        $("input:checkbox[name='cust_id[]']").each(function (i) {
            $(this).attr('checked', false);
            $(this).attr('disabled', false);
        });

    },
    reloadCustomerTable: function () {
        this.selectorCustomerTable.DataTable().ajax.reload();
    },
    handleActionResponce: function (reference) {
        var groupId = parseInt(getRecordId(reference));
        var payload = {groupId: groupId};
        let thisObj = this;
        thisObj.selectorGroupId.val(parseInt(getRecordId(reference)));
        var url = apiUrl + 'pricing/' + ($(reference).hasClass('remove') ? 'remove-pricing-group?groupId=' + groupId : 'get-pricing');
        var method = $(reference).hasClass('remove') ? 'delete' : 'get';
        ajax(url, method, payload).then(function (response) {
            if (!response.status) {
                swal({
                    title: "Error!",
                    text: response.message,
                    icon: "error",
                    button: 'OK',
                });
                return;
            }
            if ($(reference).hasClass('remove')) {
                swal({
                    title: response.response.title,
                    text: response.response.response,
                    icon: "success",
                    button: 'OK',
                }).then(function () {
                    thisObj.reloadGroupPricingTable();
                })

                return;
            }
            thisObj.selectorDataReceivedDiv.html(response.response.table);
            thisObj.selectorPricingModal.modal("show");
        });
    },
    getAllcustomersInGroups: function (reference) {
        var payload = $(reference).attr('id') == 'add_group' ? {} : {groupId: parseInt(getRecordId(reference))};
        var url = apiUrl + 'pricing/get-price-group-customers';
        ajax(url, 'get', payload).then(function (response) {
            if (!response.status) {
                swal({
                    title: "Error!",
                    text: response.message,
                    icon: "error",
                    button: 'OK',
                });
                return;
            }
            if (response.response.custid) {
                var checked = response.response.custid.split(',');
                $(checked).each(function (index, value) {
                    $("input:checkbox[name='cust_id[]']").each(function (i) {
                        if (value == $(this).val()) {
                            $(reference).attr('id') == 'add_group' ? $(this).attr('disabled', true) : $(this).attr('checked', true);
                        }
                    });
                });
            }

            if (response.response.uncheckids) {
                var unchecked = response.response.uncheckids.split(',');
                $(unchecked).each(function (index, value) {
                    $("input:checkbox[name='cust_id[]']").each(function (i) {
                        if (value == $(this).val() && $(reference).attr('id') != 'add_group') {
                            $(this).attr('disabled', true);
                        }
                    });
                    $("input:checkbox[class=toCustomers]").each(function (i) {
                        if (value == $(this).val()) {
                            $(this).attr('disabled', true);
                        }
                    });
                    $("#fromCustomer > option").each(function (i) {
                        if (value == $(this).val()) {
                            $(this).attr('disabled', true);
                        }
                    });
                });
            }
        });
    },
    openCreateOrEditCustomerModal: function (reference) {
        let thisObj = this;
        setTimeout(function() {
            thisObj.selectorPricingGroupForm.trigger("reset"); 
            thisObj.loadCustomerInfo();
            thisObj.selectorGroupModal.find('.modal-title').text($(reference).attr('id') == 'add_group' ? 'Create Pricing Group' : 'Edit Pricing Group');
            thisObj.selectorGroupName.val($(reference).attr('id') == 'add_group' ? '' : $(reference).parents('tr').find("td:first").text());
            thisObj.selectorGroupId.val($(reference).attr('id') == 'add_group' ? '' : parseInt(getRecordId(reference)));
            thisObj.getAllcustomersInGroups(reference);
        }, 500);
        thisObj.selectorGroupModal.modal("show");
    },
    savePricingFlavorForGroup: function () {
        this.refreshSelectors();
        var data = new Object();
        this.selectorAllGroupPrices.each(function (index, element) {
            var val = $(this).val();
            var id = $(this).parents('.parentRow').attr('index');
            if ($.trim(val) > 0)
            {
                data[id] = val;
            }
        });
        if (Object.keys(data).length < 0) {
            swal({
                title: "Error!",
                text: 'Please update price for Group',
                icon: "warning",
                button: 'OK',
            });

            return;
        }
        let thisObj = this;
        var url = apiUrl + 'pricing/update-pricing-info';
        var payload = {'pricingdata': JSON.stringify(data), 'groupid': this.selectorGroupId.val()};

        ajax(url, 'post', payload).then(function (response) {
            if (!response.status) {
                swal({
                    title: "Error!",
                    text: response.message,
                    icon: "error",
                    button: 'OK',
                });
                return;
            }
            swal({
                title: response.response.title,
                text: response.response.response,
                icon: "success",
                button: 'OK',
            }).then(function () {
                thisObj.selectorPricingModal.modal('toggle');
            });
        });

    }

}
