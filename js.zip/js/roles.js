
/* global Promise */

$(document).ready(function () {
    let objRole = new Roles();
    objRole.load();
    $(document).on('click', '.edit-role', function () {
        objRole.openModelEditRole(this);
    });
    $(document).on('click', '.delete-role', function () {
        objRole.delete(this);
    });
    $(document).on('click', '#add_role', function () {
        objRole.openModelAddRole();
    });
    $(document).on('click', objRole.selectorButtonSubmit.selector, function () {
        objRole.handleRole();
    });
    $(document).on('hidden.bs.modal', '.modal', function () {
        $(this).find('form')[0].reset();
    });

});


function Roles() {
    this.refreshSelectors();
}

Roles.prototype = {
    refreshSelectors: function () {
        this.selectorTableRole = $('#roles');
        this.selectorModal = $('#RoleModal');
        this.selectorRoleId =  this.selectorModal.find('[name="roleid"]');
        this.selectorModalTitle = this.selectorModal.find('.modal-title');
        this.selectorModalTitleName = this.selectorModalTitle.find('span');
        this.selectorButtonSubmit = this.selectorModal.find('[name="RoleBut"]');
        this.selectorRoleName = this.selectorModal.find('[name="rolename"]');

    },
    reloadTable: function () {
        if (typeof window.tableRoles === 'undefined') {
            this.load();
        } else {
            window.tableRoles.ajax.reload();
        }
    },
    load: function () {
        this.refreshSelectors();
        window.tableRoles = this.selectorTableRole.DataTable({
            ajax: {
                url: apiUrl + 'roles/all',
                dataSrc: function (data) {
                    return  data.status ? data.response : [];
                }
            },
            order: [[0, "asc"]],
            columns: [
                {
                    render: function (data, type, row, meta) {
                        return meta.row + 1;
                    }
                },
                {
                    render: function (data, type, row) {
                        return row.name;
                    }
                },
                {
                    render: function (data, type, row) {
                        return row.last_modified;
                    }
                },

                {
                    sortable: false,
                    render: function (data, type, row) {
                        return `
                  <button class="btn btn-info edit-role mb-3"><i class="fa fa-pencil"></i></button>
                  <button class="btn btn-danger delete-role mb-3"><i class="fa fa-trash"></i></button>
                                `;
                    }
                }
            ],
            createdRow: function (row, data, index) {
                $(row).attr('data-id', data.id);
            }
        });
    },

    openModelEditRole: function (reference) {
        let thisObj = this;
        this.selectorModal.modal();
        var roleId = getRecordId(reference);
        
        this.selectorModalTitle.html('Edit role info: ');
        this.selectorRoleId.val(roleId);
 
        this.getRoleInfo(roleId).then(function (role) {
                thisObj.selectorRoleName.val(role.name);

        });
    },
    delete: function (reference) {
        let thisObj = this;
        let roleId = getRecordId(reference);
        let payload = {
            "role_id": roleId
        };
        ajax(apiUrl + 'roles/delete', 'post', payload).then(function (response) {
            swal({
                title: response.status ? "Success" : "Error",
                text: response.status ? response.message : response.response.join('<br>'),
                icon: response.status ? "success" : "error",
                button: "OK"
            }).then(() => {
                if (response.status) {
                    thisObj.reloadTable();
                }
            });

        });
    },
    openModelAddRole: function () {
        this.selectorModal.modal();
        this.selectorModalTitle.html('Add new role');
        this.selectorRoleId.val('')
        let thisObj = this;
        Promise.all([thisObj.getRoles()]).then((values) => {
            var [roles] = values;
            thisObj.selectorRole.html(roles);

        });

    },
    getPayloadRole: function () {
          var rolename='';
        this.selectorModal.find('.form-field-data').each(function () {
            rolename=$(this).val();
        });
        var payload ={
            'rolename':rolename,
            'roleid':this.selectorRoleId.val()
        }

        return payload;
    },
    handleRole: function () {
        var payload = this.getPayloadRole();
       // console.log(payload);
        if (payload.roleid) {
            this.updateRole(payload);
        } else {
            delete payload.roleid;
            this.addRole(payload);
        }
    },
    addRole: function (payload) {
        console.log(payload);
        let thisObj = this;

        ajax(apiUrl + 'roles/add', 'post', payload).then(function (response) {
            swal({
                title: response.status ? "Success" : "Error",
                text: response.status ? response.message : response.response.join('\n'),
                icon: response.status ? "success" : "error",
                button: "OK"
            }).then(() => {
                if (response.status) {
                    thisObj.selectorModal.modal('hide');
                }
                thisObj.reloadTable();
            });
            // auto close and refresh
        });
    },
    updateRole: function (payload) {
        let thisObj = this;
        ajax(apiUrl + 'roles/update', 'post', payload).then(function (response) {
            swal({
                title: response.status ? "Success" : "Error",
                text: response.status ? response.message : response.response.join('\n'),
                icon: response.status ? "success" : "error",
                button: "OK"
            }).then(() => {
                if (response.status) {
                    thisObj.selectorModal.modal('hide');
                }
                thisObj.reloadTable();
            });
        });
    },

    getRoles: function (roleId = null) {
        return new Promise(function (resolve) {
            ajax(apiUrl + 'roles/all', 'get').then(function (response) {
                if (!response.status) {
                    resolve('');
                    return;
                }
                let config = {
                    emptyIndex: 'Select User Role'
                };
                if (roleId) {
                    config['value'] = roleId;
                } else {
                    config['index'] = 0;
                }
                resolve(generateDropdownHtml(arrayColumns(response.response, ['id', 'name']), config));
            });
        });
    },

    getRoleInfo: function (roleId) {
        return new Promise(function (resolve) {
            let payload = {
                "role_id": roleId
            };
            ajax(apiUrl + 'roles/all', 'get', payload).then(function (response) {
                if (!response.status) {
                    resolve({});
                    return;
                }
                
                resolve(response.response[0]);
            });
        });
    }
};


