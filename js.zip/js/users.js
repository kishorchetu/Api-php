
/* global Promise */

$(document).ready(function () {
    let objUser = new Users();
    objUser.load();
    $(document).on('change', '.locked', function () {
        objUser.lock(this);
    });
    $(document).on('change', '.suspended', function () {
        objUser.suspend(this);
    });
    $(document).on('click', '.edit-user', function () {
        objUser.openModelEditUser(this);
    });
    $(document).on('click', '.delete-user', function () {
        objUser.delete(this);
    });
    $(document).on('click', '#add_user', function () {
        objUser.openModelAddUser();
    });
    $(document).on('click', objUser.selectorButtonSubmit.selector, function () {
        objUser.handleUser();
    });
    $(document).on('hidden.bs.modal', objUser.selectorModal.selector, function () {
        $(this).find('form')[0].reset();
        setTimeout(function () {
            var fade = $('.modal-backdrop');
            if (fade.length) {
                console.log(fade.length);
                fade.remove();
            }
        });
    });

});

function Users() {
    this.refreshSelectors();
}

Users.prototype = {
    refreshSelectors: function () {
        this.selectorTableUser = $('#users');

        this.selectorModal = $('#UserModal');
        this.selectorModalTitle = this.selectorModal.find('.modal-title span:first-child()');
        this.selectorModalTitleName = this.selectorModal.find('.modal-title span:nth-child(2)');
        this.selectorButtonSubmit = this.selectorModal.find('[name="UserBut"]');

        this.selectorUserId = this.selectorModal.find('[name="userid"]');
        this.selectorRole = this.selectorModal.find('[name="role"]');
        this.selectorWarehouses = this.selectorModal.find('[name="wharehouse"]');
        this.selectorCompany = this.selectorModal.find('[name="company"]');
        this.selectorUserName = this.selectorModal.find('[name="username"]');
        this.selectorFirstName = this.selectorModal.find('[name="firstname"]');
        this.selectorLastName = this.selectorModal.find('[name="lastname"]');
        this.selectorEmail = this.selectorModal.find('[name="email"]');
    },
    reloadTable: function () {
        if (typeof window.tableUsers === 'undefined') {
            this.load();
        } else {
            window.tableUsers.ajax.reload();
        }
    },
    load: function () {
        this.refreshSelectors();
        window.tableUsers = this.selectorTableUser.DataTable({
            ajax: {
                url: apiUrl + 'users/all',
                dataSrc: function (data) {
                    return  data.status ? data.response : [];
                }
            },
            order: [[0, "asc"]],
            columns: [
                {
                    render: function (data, type, row, meta) {
                        return meta.row + 1;
                    }
                },
                {
                    render: function (data, type, row) {
                        return row.username;
                    }
                },
                {
                    render: function (data, type, row) {
                        return row.roleNames.join(', ');
                    }
                },
                {
                    render: function (data, type, row) {
                        return row.email;
                    }
                },
                {
                    render: function (data, type, row) {
                        var checked = parseInt(row.locked) === 1 ? ' checked' : '';
                        return `<label class="switch">
                          <input type="checkbox"${checked} class="form-control locked">
                          <span class="slider round"></span>
                           </label>`;
                    }
                },
                {
                    render: function (data, type, row) {
                        var checked = parseInt(row.suspended) === 1 ? ' checked' : '';
                        return `<label class="switch">
                         <input type="checkbox"${checked} class="slider round suspended">
                         <span class="slider round"></span>
                         </label>`;
                    }
                },
                {
                    sortable: false,
                    render: function (data, type, row) {
                        return `
                  <button class="btn btn-info edit-user mb-3"><i class="fa fa-pencil"></i></button>
                  <button class="btn btn-danger delete-user mb-3"><i class="fa fa-trash"></i></button>
                                `;
                    }
                }
            ],
            createdRow: function (row, data, index) {
                $(row).attr('data-id', data.id);
            }
        });
    },
    lock: function (reference) {
        let userId = getRecordId(reference);
        let lock = $(reference).prop('checked') ? '1' : '0';
        let payload = {
            "user_id": userId,
            "lock": lock
        };
        ajax(apiUrl + 'users/lock', 'post', payload).then(function (response) {
            console.log(response);
            if (!response.status) {
                $(reference).prop('checked', !$(reference).prop('checked'));
            }
            swal({
                title: response.status ? "Success" : "Error",
                text: response.status ? response.message : response.response.join('<br>'),
                icon: response.status ? "success" : "error",
                button: "OK",
            });
        });
    },
    suspend: function (reference) {
        let userId = getRecordId(reference);
        let suspend = $(reference).prop('checked') ? '1' : '0';
        let payload = {
            "user_id": userId,
            "suspend": suspend
        };
        ajax(apiUrl + 'users/suspend', 'post', payload).then(function (response) {
            console.log(response);

            if (!response.status) {
                $(reference).prop('checked', !$(reference).prop('checked'));
            }
            swal({

                title: response.status ? "Success" : "Error",
                text: response.status ? response.message : response.response.join('<br>'),
                icon: response.status ? "success" : "error",
                button: "OK"
            });
        });
    },
    openModelEditUser: function (reference) {
        let thisObj = this;
        this.selectorModal.modal();
        var userId = getRecordId(reference);
        this.selectorModalTitle.html('Edit user info: ');
        this.selectorUserId.val(userId);
        this.getUserInfo(userId).then(function (user) {
            thisObj.selectorModalTitleName.html([user.firstname, user.lastname].filter(name => {
                return name.length > 0;
            }).map(name => {
                return name.charAt(0).toUpperCase() + name.slice(1).toLowerCase();
            }).join(' '));
            Promise.all([thisObj.getRoles(user.roleIds), thisObj.getWarehouses(user.warehouse), thisObj.getCompanies(user.company)]).then((values) => {
                var [roles, warehouses, companies] = values;
                thisObj.selectorRole.html(roles);
                thisObj.selectorWarehouses.html(warehouses);
                thisObj.selectorCompany.html(companies);
                thisObj.selectorUserName.val(user.username);
                thisObj.selectorFirstName.val(user.firstname);
                thisObj.selectorLastName.val(user.lastname);
                thisObj.selectorEmail.val(user.email);
                initializeDropdown();
            });
        });
    },
    delete: function (reference) {
        let thisObj = this;
        let userId = getRecordId(reference);
        let payload = {
            "user_id": userId
        };
        ajax(apiUrl + 'users/delete', 'post', payload).then(function (response) {
            swal({
                title: response.status ? "Success" : "Error",
                text: response.status ? response.message : response.response.join('<br>'),
                icon: response.status ? "success" : "error",
                button: "OK"
            }).then(() => {
                if (response.status) {
                    thisObj.reloadTable();
                }
            });

        });
    },
    openModelAddUser: function () {
        this.selectorModal.modal();
        this.selectorModalTitle.html('Add new user');
        let thisObj = this;
        Promise.all([thisObj.getRoles(), thisObj.getWarehouses(), thisObj.getCompanies()]).then((values) => {
            var [roles, warehouses, companies] = values;
            thisObj.selectorRole.html(roles);
            thisObj.selectorWarehouses.html(warehouses);
            thisObj.selectorCompany.html(companies);
            initializeDropdown();
        });

    },
    handleUser: function () {
        var payload = this.getPayloadUser();
        console.log(payload);
        if (payload.userid) {
            this.updateUser(payload);
        } else {
            delete payload.userid;
            this.addUser(payload);
        }
    },
    addUser: function (payload) {
        let thisObj = this;
        ajax(apiUrl + 'users/add', 'post', payload).then(function (response) {
            swal({
                title: response.status ? "Success" : "Error",
                text: response.status ? response.message : response.response.join('\n'),
                icon: response.status ? "success" : "error",
                button: "OK"
            }).then(() => {
                if (response.status) {
                    thisObj.selectorModal.modal('hide');
                }
                thisObj.reloadTable();
            });
        });
    },
    updateUser: function (payload) {
        let thisObj = this;
        ajax(apiUrl + 'users/update', 'post', payload).then(function (response) {
            console.log(response);
            swal({
                title: response.status ? "Success" : "Error",
                text: response.status ? response.message : response.response.join('\n'),
                icon: response.status ? "success" : "error",
                button: "OK"
            }).then(() => {
                if (response.status) {
                    thisObj.selectorModal.modal('hide');
                }
                thisObj.reloadTable();
            });
        });
    },
    getPayloadUser: function () {
        var payload = {};
        this.selectorModal.find('.form-field-data').each(function () {
            payload[$(this).attr('name')] = $(this).val();
        });
        payload['wharehouse'] = (Array.isArray(payload['wharehouse']) ? payload['wharehouse'] : []).join(',')
        payload['role'] = (Array.isArray(payload['role']) ? payload['role'] : []).join(',')
        return payload;
    },
    getRoles: function (roleId = null) {
        return new Promise(function (resolve) {
            ajax(apiUrl + 'roles/all', 'get').then(function (response) {
                if (!response.status) {
                    resolve([]);
                    return;
                }
                var roles = [];
                $.each(response.response, function (key, value) {
                    roles.push([key, value]);
                });
                let config = {};
                if (roleId) {
                    config['value'] = roleId.map(i => parseInt(i));
                } else {
//                    config['index'] = 0;
                }
                resolve(generateDropdownHtml(arrayColumns(response.response, ['id', 'name']), config));
            });
        });
    },
    getCompanies: function (companyId = null) {
        return new Promise(function (resolve) {
            ajax(apiUrl + 'companies/all', 'get').then(function (response) {
                if (!response.status) {
                    resolve('');
                    return;
                }
                var companies = [];
                $.each(response.response, function (key, value) {
                    companies.push([key, value]);
                });
                let config = {
                    emptyIndex: 'Select User Company'
                };
                if (companyId) {

                    config['value'] = companyId.toString();
                } else {
                    config['index'] = 0;
                }
                resolve(generateDropdownHtml(companies, config));
            });
        });
    },
    getWarehouses: function (warehouseId = null) {
        return new Promise(function (resolve) {
            ajax(apiUrl + 'warehouses/all', 'get').then(function (response) {
                if (!response.status) {
                    resolve([]);
                    return;
                }
                var warehouses = [];
                $.each(response.response, function (key, value) {
                    warehouses.push([key, value]);
                });
                let config = {};
                if (warehouseId) {
                    config['value'] = warehouseId;
                } else {
//                    config['index'] = 0;
                }
                resolve(generateDropdownHtml(warehouses, config));
            });
        });
    },
    getUserInfo: function (userId) {
        return new Promise(function (resolve) {
            let payload = {
                "user_id": userId
            };
            ajax(apiUrl + 'users/all', 'get', payload).then(function (response) {
                if (!response.status) {
                    resolve({});
                    return;
                }
                resolve(response.response[0]);
            });
        });
    }
};


