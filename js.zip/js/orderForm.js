$(document).ready(function () {
    var objInventoryOrders = new OrderForms();
    objInventoryOrders.refreshSelectors();
    objInventoryOrders.loadInventoryStatus();
    objInventoryOrders.initFormElements();
    objInventoryOrders.checkStatusOfRuningtotal();
    objInventoryOrders.checkStatusOfShowWarehouse();

    $(document).on('change', '#owner', function () {
        objInventoryOrders.fillCustomers($(this).val());
    });

    $(document).on('change', '#customer', function () {
        objInventoryOrders.loadCustomerProductTable(this.value);
    });

    $(document).on('submit', '#PurchaseForm', function (e) {
        e.preventDefault();
        objInventoryOrders.savePurchaseForm();
    });

    $(document).on('click', '#hideshowcol', function () {
        objInventoryOrders.hideShowToggle(this);
    });

    $(document).on('click', '#sprice_update', function () {
        objInventoryOrders.updateSelePrice(this);
    });

    $(document).on('keyup', '.QTY, .saleP, .WHP', function () {
        objInventoryOrders.checkTotal(this);
    });
    window.addEventListener('scroll', objInventoryOrders.handleRuningTotalSection);

    $(document).on('click', '#collapseadv', function () {
        $('body').toggleClass('noAdd');
    });
});
function OrderForms() {
    this.refreshSelectors();
}
OrderForms.prototype = {
    refreshSelectors: function () {
        this.selectPurchaseForm = $('#PurchaseForm');
        this.selectOwner = $('#owner');
        this.selectCustomer = $('#customer');
        this.selectCaseTotal = $('#Casetotal');
        this.selectWeightTotal = $('#Weighttotal');
        this.selectWhtotal = $('#warehousetotal');
        this.selectCustTotal = $('#customertotal');
        this.selectOwnerId = $('#ownerId');
        this.selectDataReceivedDiv = $('#dataReceived');
        this.selectAllFormInputs = $('#PurchaseForm *');
        this.selectMyHeaderTotal = $('#myHeaderTotal');
        this.selectMyHeaderTotalStatus = $('#myHeaderTotalStatus');
        this.selectShowWarehouseStatus = $('#showWarehouseStatus');
        this.selectQtyClass = $(".QTY");
        this.selectComment = $("#comment");
        this.selectCredit = $("#ccredit");
        this.selectPurchaseOrder = $("#purchase_order");
        this.selectMsg = $('#msg');
        this.selectLoader = $('#loader');
        this.selectWhtotalDiv = $('#warehousetotaldiv');
        this.selecttabs = $('#tabs');
        this.selecttablist = $("#tablist");
        this.selectBacktoTop = $('#top-link');
        this.selectOrderId = $('#orderId');
        this.selectSessionUsername = $('#sessionUsername');
        this.selectCustomerId = $('#customerId');
    },
    loadInventoryStatus: function () {

        let thisObj = this;
        var url = apiUrl + 'process-inventory-orders/load-inventory-status';
        ajax(url, 'get').then(function (response) {
            thisObj.selectMsg.html(response.message);
            if (response.response.status == 0) {
//                        thisObj.selectPurchaseForm.find(":submit").attr('disabled', true);
//                        thisObj.selectAllFormInputs.prop('disabled', true);
            } else {
//                        thisObj.selectPurchaseForm.find(":submit").attr('disabled', false);
//                        thisObj.selectAllFormInputs.prop('disabled', false);
            }
        });
    },
    initFormElements: function () {
        this.selectOwner.select2({
            placeholder: "Please Select Partner"
        });

        this.selectCustomer.select2({
            placeholder: "Please Select Customer"
        });

        this.selectCaseTotal.html("0");
        this.selectWeightTotal.html("0.00");
        this.selectWhtotal.html("0.00");
        this.selectCustTotal.html("0.00");
        if (this.selectOrderId.val() == 0 && this.selectCustomerId.val() == 0) {
            this.fillOwners();
        } else if (this.selectCustomerId.val() != 0 && this.selectOrderId.val() == 0) {
            this.fillFormDetails();
        } else if (this.selectCustomerId.val() != 0 && this.selectOrderId.val() != 0) {
            this.fillEditOrderForToBePicked();
        } else {
            this.fillEditOrder();
        }
    },
    fillFormDetails: function () {
        var thisObj = this;
        var url = apiUrl + 'order-forms/get-selected-cust';
        var payload = {customerId: thisObj.selectCustomerId.val()};
        ajax(url, 'get', payload).then(function (response) {
            if (!response.status) {
                swal({
                    title: "Error!",
                    text: response.message,
                    icon: "error",
                    button: 'OK'
                });
                return;
            }
            var data = arrayColumns(response.response.companyinfo, ['owner_id', 'company']);
            var config = {
                'emptyIndex': ''
            };
            if (data.length === 1) {
                config['index'] = 1;
            }
            var html = generateDropdownHtml(data, config);
            thisObj.selectOwner.html(html);
            var customerinfo = response.response.customerinfo.map(customer => {
                var add = customer.custaddress;
                delete(customer.custaddres);
                return [
                    customer.id,
                    customer.custname + ': ' + add
                ];
            });
            var config = {
                'emptyIndex': ''
            };
            if (customerinfo.length === 1) {
                config['index'] = 1;
            }
            var html = generateDropdownHtml(customerinfo, config);
            thisObj.selectCustomer.html(html);
            thisObj.loadCustomerProductTable(thisObj.selectCustomerId.val());
            thisObj.updateTotal();
            $('.modal-backdrop').remove();
        });

    },
    fillOwners: function () {
        var thisObj = this;
        var url = apiUrl + 'order-forms/load-partners';
        var payload = {ownerId: this.selectOwnerId.val()};
        ajax(url, 'get', payload).then(function (response) {
            if (!response.status) {
                //do error handling
                swal({
                    title: "Error!",
                    text: response.message,
                    icon: "error",
                    button: 'OK'
                });
                return;
            }
            var data = arrayColumns(response.response, ['owner_id', 'company']);
            var config = {
                'emptyIndex': ''
            };
            if (data.length === 1) {
                config['index'] = 1;
            }
            var html = generateDropdownHtml(data, config);
            thisObj.selectOwner.html(html);
            if (data.length === 2) {
                setTimeout(function () {
                    thisObj.selectOwner.trigger('change');
                }, 1000)
            }
        });
    },
    fillCustomers: function (ownerId) {
        let thisObj = this;
        var url = apiUrl + 'order-forms/load-customers';
        var payload = {ownerId: ownerId};
        ajax(url, 'get', payload).then(function (response) {
            if (!response.status) {
                swal({
                    title: "Error!",
                    text: response.message,
                    icon: "error",
                    button: 'OK'
                });
            }
            response.response = response.response.map(customer => {
                var add = customer.custaddress;
                delete(customer.custaddres);
                return [
                    customer.id,
                    customer.custname + ': ' + add
                ];
            });
            var config = {
                'emptyIndex': ''
            };
            if (response.response.length === 1) {
                config['index'] = 0;
            }
            var html = generateDropdownHtml(response.response, config);
            thisObj.selectCustomer.html(html);
        });
    },
    loadCustomerProductTable: function (refrence) {
        let thisObj = this;
        var url = apiUrl + 'order-forms/load-customer-table-info';
        var payload = {cust_id: refrence, owner_id: thisObj.selectOwner.val()};
        ajax(url, 'get', payload).then(function (response) {
            if (!response.status) {
                swal({
                    title: "Error!",
                    text: response.message,
                    icon: "error",
                    button: 'OK',
                });
                return;
            }
            thisObj.selectDataReceivedDiv.html(response.response.producttable);
            var tabList = '';
            $.each(response.response.tabs, function (key, value) {
                if (key === 0) {
                    tabList += `<li  class="active"><a data-toggle="tab" href="#tab${value}">${value}</a></li>`;
                } else {
                    tabList += `<li><a data-toggle="tab" href="#tab${value}">${value}</a></li>`;
                }
            });
            $('#tablist').html(tabList);
	    thisObj.checkStatusOfShowWarehouse();	
        });

    },
    checkStatusOfRuningtotal: function () {
        let thisObj = this;
        if (thisObj.selectMyHeaderTotalStatus.val() == 0) {
            thisObj.selectMyHeaderTotal.hide()
        } else if (thisObj.selectMyHeaderTotalStatus.val() == 1) {
            thisObj.selectMyHeaderTotal.show()
        }
    },
    checkStatusOfShowWarehouse: function () {
        let thisObj = this;
        if (thisObj.selectShowWarehouseStatus.val() == 1) {
            $('body').find('*').each(function () {
                if ($(this).hasClass('hideforwp')) {
                    $(this).removeClass("hideforwp");
                }
            });
        }
    },
    savePurchaseForm: function () {
        this.refreshSelectors();
        let thisObj = this;
        var data = new Object();
        thisObj.selectQtyClass.each(function () {
            var val = parseInt($(this).val().trim());
            var id = $(this).parents('.parentRow').attr('index');
            if (val > 0)
            {
                var saleprice = $(this).parents('.parentRow').find('.saleP').val();
                var WHPrice = $(this).parents('.parentRow').find('.WHP').val();
                var custprice = $(this).parents('.parentRow').find('.custP').val();
                var Weight = $(this).parents('.parentRow').find('.Weight').val();
                data[id] = new Object();
                data[id]['qty'] = val;
                data[id]['saleprice'] = saleprice;
                data[id]['WHPrice'] = WHPrice;
                data[id]['custprice'] = custprice;
                data[id]['Weight'] = Weight;
            }
        });
        if (Object.keys(data).length > 0)
        {
            var extraData = new Object();
            extraData['customer'] = thisObj.selectCustomer.val();
            extraData['comment'] = thisObj.selectComment.val();
            extraData['ccredit'] = thisObj.selectCredit.val();
            extraData['purchase_order'] = thisObj.selectPurchaseOrder.val();
            var url = apiUrl + 'order-forms/' + ((thisObj.selectOrderId.val() != 0 && thisObj.selectCustomerId.val() != 0) ? 'update-tobe-pick-order' : (thisObj.selectOrderId.val() != 0) ? 'update-temprory-order-form' : 'submit-order-form');
            var payload = {'extraData': JSON.stringify(extraData), 'data': JSON.stringify(data)};
            (thisObj.selectOrderId.val() != 0 && thisObj.selectCustomerId.val() != 0) ? (payload.CustomerId = thisObj.selectCustomerId.val(), payload.order_id = thisObj.selectOrderId.val()) : (thisObj.selectOrderId.val() != 0) ? (payload.order_id = thisObj.selectOrderId.val()) : '';
            ajax(url, 'post', payload).then(function (response) {
                if (!response.status) {
                    swal({
                        title: "Error!",
                        text: response.message,
                        icon: "error",
                        button: 'OK',
                    });
                    return;
                }
                swal({
                    title: response.response.title,
                    text: response.response.response,
                    icon: "success",
                    button: 'OK',
                }).then(function (i) {
                    location.reload();
                });
            });

        } else {
            swal({
                title: "Cart Empty!",
                text: "Nothing to place",
                icon: "warning",
                button: 'OK',
            });
        }

    },
    hideShowToggle: function (refrence) {
        let thisObj = this;
        if ($(refrence).attr('val') == 1) {
            $(refrence).attr('val', 0);
            thisObj.selectWhtotalDiv.hide();
        } else if ($(refrence).attr('val') == 0) {
            $(refrence).attr('val', 1);
            thisObj.selectWhtotalDiv.show();
        }
        $("." + $(refrence).attr('data')).toggle();
        $('.hideforwp').hide();
    },
    updateSelePrice: function (refrence) {
        let thisObj = this;
        if ($('.sprice_update_' + $(refrence).attr('data')).val() > 0)
        {
            $(".sp_" + $(refrence).attr('data')).val($('.sprice_update_' + $(refrence).attr('data')).val());
            thisObj.updateTotal();

        }
        return false;
    },
    checkTotal: function (refrence) {
        let thisObj = this;
        if ((parseInt($(refrence).val()) >= 0 && parseInt($(refrence).val()) <= 999) || $(refrence).val() == '') {
            thisObj.updateTotal();
        } else {
            $(refrence).val("");
            thisObj.updateTotal();
        }
    },
    updateTotal: function (refrence) {
        this.refreshSelectors();
        let thisObj = this;
        if (thisObj.selectMyHeaderTotalStatus.val() == 1) {
            var customerprice = 0;
            var warehouseprice = 0;
            var caseval = 0;
            var caseweight = 0;
            thisObj.selectQtyClass.each(function (index, element) {
                var qtyval = $(this).val();
                if ($.trim(qtyval) > 0)
                {
                    var custprice = $(this).parents('.parentRow').find('.saleP').val();
                    var WHPrice = $(this).parents('.parentRow').find('.WHP').val();
                    var Weight = $(this).parents('.parentRow').find('.Weight').val();
                    customerprice = parseFloat(customerprice) + (parseFloat(custprice) * parseFloat(qtyval));
                    warehouseprice = parseFloat(warehouseprice) + (parseFloat(WHPrice) * parseFloat(qtyval));
                    caseval = parseInt(caseval) + parseInt(qtyval);
                    caseweight = parseFloat(caseweight) + (parseFloat(Weight) * parseFloat(qtyval));
                }
            });
            thisObj.selectCaseTotal.html(caseval);
            thisObj.selectWeightTotal.html(caseweight.toFixed(2));
            thisObj.selectWhtotal.html(warehouseprice.toFixed(2));
            thisObj.selectCustTotal.html(customerprice.toFixed(2));
        }
    },
    handleRuningTotalSection: function () {
        var header = document.getElementById('myHeaderTotal');
        var sticky = header.offsetTop;
        if (window.pageYOffset > sticky) {
            header.classList.add("sticky");
        } else {
            header.classList.remove("sticky");
        }
    },
    fillEditOrder: function (orderId) {
        var thisObj = this;
        var url = apiUrl + 'order-forms/get-order-details';
        var payload = {orderId: thisObj.selectOrderId.val()};
        ajax(url, 'get', payload).then(function (response) {
            if (!response.status) {
                swal({
                    title: "Error!",
                    text: response.message,
                    icon: "error",
                    button: 'OK'
                });
                return;
            }
            var data = arrayColumns(response.response.companyinfo, ['owner_id', 'company']);
            var config = {
                'emptyIndex': ''
            };
            if (data.length === 1) {
                config['index'] = 1;
            }
            var html = generateDropdownHtml(data, config);
            thisObj.selectOwner.html(html);
            var customerinfo = response.response.customerinfo.map(customer => {
                var add = customer.custaddress;
                delete(customer.custaddres);
                return [
                    customer.id,
                    customer.custname + ': ' + add
                ];
            });
            var config = {
                'emptyIndex': ''
            };
            if (customerinfo.length === 1) {
                config['index'] = 1;
            }
            var html = generateDropdownHtml(customerinfo, config);
            thisObj.selectCustomer.html(html);
            thisObj.selectComment.html(response.response.comment);
            thisObj.selectCredit.val(response.response.ccredit);
            thisObj.selectPurchaseOrder.val(response.response.purchase_order);
            var html = thisObj.loadOrderDetails(response.response);
            thisObj.selectDataReceivedDiv.html(html);
            thisObj.loadTabs(response.response);
            thisObj.loadEditOrderDetails(response.response);
            thisObj.updateTotal();
            thisObj.checkStatusOfShowWarehouse();
        });
    },
    loadOrderDetails: function (response) {
        var html = `<div class="panel panel-default">
                <div class="panel-heading"><b class="panel-title">Customer Information</b></div>
                <div class="panel-body table-responsive">
                <table class="table table-bordered">
                <thead>
                <tr>
                <th width="25%">Customer Name</th>
                <th width="30%">Address</th>
                <th width="15%">City</th>
                <th width="15%">State</th>
                <th width="15%">Zip</th>
                <tr>
                </thead>
                <tbody>`;
        response.customerinfo.map(customer => {
            html += `<tr>
                    <td><input id="cname" name="cname" style="width:200px" type="hidden" readonly="readonly" value=" ${customer.custname}  "> ${customer.custname}  </td>
                    <td><input id="caddress" name="caddress" style="width:200px" type="hidden" readonly="readonly" value=" ${customer.custaddress}  "> ${customer.custaddress}  </td>
                    <td><input id="ccity" name="ccity" style="width:100px" type="hidden" readonly="readonly" value=" ${customer.custcity}  "> ${customer.custcity}  </td>
                    <td><input id="cstate" name="cstate" style="width:50px" type="hidden" readonly="readonly" value=" ${customer.custstate}  "> ${customer.custstate}  </td>
                    <td><input id="czip" name="czip" style="width:50px" type="hidden" readonly="readonly" value=" ${customer.custzip}  "> ${customer.custzip}  </td>
                    </tr>`;

            upcharge = customer.cust_upcharge;
            amtupcharge = customer.cust_upcharge_amt;
        });
        html += `</tbody>
                </table>
                </div>
                </div>
                <div style="text-align:center;width:100%;" id="pactions">
                <a class="btn btn-info" href="javascript:void(0);" data="whprice" id="hideshowcol" val="1">Show/Hide Details</a>
                </div><br/><br/>
                <div id="tabs">
                <ul id="tablist" class="nav nav-tabs"></ul>
                <div class="tab-content">`;
        var endOfTab = false;
        var endOfTable = false;
        var i = 1;
        var type = "";
        var fam = "";
        response.productsinfo.map(product => {
            if (i == 1) {
                var scale = product.pfamily;
                var prod = product.productname;
                type = product.type;
                fam = product.pfamily;

                html += `<div class="tab-pane fade in active" id="tab${ type.replace(" ", "-") }" style="text-align: center">
                    <div class="table-responsive">
                        <h1>${ prod }</h1><br><div style="font-size:15px;">Family Sale Price: $ <input type="text" style="width:120px;" class="sprice_update_${ scale }">&nbsp;&nbsp;<a class="btn btn-info" id="sprice_update" data="${scale}" >Commit</a></div><br/>
                        <table class="table table-bordered table-width-manage-table" >
                            <thead>
                                <tr style="font-size:15px;">
                                    <th class="whprice">E</th>
                                    <th class="whprice">D</th>
                                    <th>Description</th>
                                    <th class="whprice hideforwp">Warehouse Price</th>
                                    <th>QOH</th>
                                    <th>On Order</th>
                                    <th>Sale Price</th>
                                    <th>Customer Price</th><th>QTY</th>
                                    <th style="display:none;">Weight</th></tr>
                            </thead>
                            <tbody>`;
            }
            if (type !== product.type) {
                if (fam !== product.pfamily) {
                    html += `</tbody>
                            </table>
                        </div>
                    </div>`;
                    endOfTab = true;
                }
            } else {
                if (fam !== product.pfamily) {
                    html += `</tbody>
                    </table>`;
                    endOfTable = true;
                }
            }

            if (endOfTable === true || endOfTab === true) {
                scale = product.pfamily;
                prod = product.productname;
                type = product.type;
                fam = product.pfamily;
                if (endOfTab === true) {
                    html += `<div class="tab-pane fade" id="tab${ type.replace(" ", "-") }" style="text-align: center">
                        <div class="table-responsive">`;
                }
                html += `<h1>${ prod }</h1><br><div style="font-size:15px;">Family Sale Price: $ <input type="text" style="width:120px;" class="sprice_update_${ scale }">&nbsp;&nbsp;<a class="btn btn-info" id="sprice_update" data="${scale}" >Commit</a></div><br/>
                        <table class="table table-bordered table-width-manage-table">
                            <thead>
                                <tr style="font-size:15px;">
                                    <th class="whprice">E</th>
                                    <th class="whprice">D</th>
                                    <th>Description</th>
                                    <th class="whprice hideforwp">Warehouse Price</th>
                                    <th>QOH</th>
                                    <th>On Order</th>
                                    <th>Sale Price</th>
                                    <th>Customer Price</th><th>QTY</th>
                                    <th style="display:none;">Weight</th></tr>
                            </thead>
                            <tbody>`;
                endOfTable = false;
                endOfTab = false;
            }
            if (isNaN(product.route_upcharge)) {
                var route_upcharge = 1;
            }
            var desc = product.description;
            var id = product.id;
            var custprice = Number.parseFloat(product.c_price).toFixed(2);
            var price = Number.parseFloat(parseFloat(product.price) * parseFloat(route_upcharge)).toFixed(2);
            var str = "quantity";
            var sprice = "sprice";
            var whprice = "whprice";
            var strb = str + String(id);
            var spriceb = sprice + String(id);
            var whpriceb = whprice + String(id);
            var cust_price = "custprice" + String(id);
            if (custprice == 0.00) {
                var col = "#FFCCCC";
                custprice = Number.parseFloat((1.3 * price)).toFixed(2);
                html += `<tr class="parentRow danger" index="${id}" style="font-size:15px;">`;
            } else {
                var col = "#FFFFFF";
                html += `<tr class="parentRow" index="${ id }" style="font-size:15px;">`;
            }
            html += `<td class="whprice" style="text-align:center;">${ product.Expired }</td>
                <td class="whprice" style="text-align:center;">${ product.Damaged }</td>
                <td>${ desc }</td>
                <td class="whprice hideforwp"><div class="input-group"><span class="input-group-addon">$</span><input id="${ whpriceb }" class="form-control WHP" name="${ whpriceb }" style="width:60px" readonly="readonly" type="text" tabindex="-1" value="${ price }"></div></td>
                <td ><a href="item-detail.php?fid=${ id }" target="_blank" tabindex="-1">${ product.QOH }</a></td>
                <td style="text-align:center;">${ product.OnOrder }</td>`;

            if (this.selectSessionUsername == 'Greenland') {
                if (upcharge == 1) {
                    custprice = Number.parseFloat(price * amtupcharge).toFixed(2);
                } else {
                    custprice = custprice;
                }
            }
            html += `<td><div class="input-group"><span class="input-group-addon">$</span><input id="${ spriceb }" name="${ spriceb }" style="width:65px" previousValue="${ custprice }" class="form-control saleP sp_${ fam }" type="text" class="sprice  sp_${ scale }" tabindex="-1" value="${ custprice }"></div></td>
                <td bgcolor="${ col }">${ custprice }<input id="${ cust_price }" name="${ cust_price }" style="width:60px" readonly="readonly" type="hidden" tabindex="-1" class="custP" value="${ custprice }"></td>
                <td bgcolor="${ col }"><input id="${ strb }" name="${ strb }" prevousValue="" class="form-control QTY"  autocomplete="off" onkeypress="return isNumber(event)" style="font-Weight:bold;width:100px;" type="tel" /></td>
                <td style="display:none;"><input type="hidden" class="Weight" value="${ product.weight }"></td>
            </tr>`;
            i++;
        });


        return html;
    },
    loadTabs: function (response) {
        var tabList = '';
        $.each(response.tabs, function (key, value) {
            if (key === 0) {
                tabList += `<li  class="active"><a data-toggle="tab" href="#tab${value}">${value}</a></li>`;
            } else {
                tabList += `<li><a data-toggle="tab" href="#tab${value}">${value}</a></li>`;
            }
        });
        $('#tablist').html(tabList);
    },
    loadEditOrderDetails: function (response) {
        $.map(response.cleanData, function (value, index) {
            $(`table > tbody  > tr[index='${index}']`).each(function () {
                $(this).find('.saleP').val(value.saleprice);
                $(this).find('.WHP').val(value.WHPrice);
                $(this).find('.custP').val(value.custprice);
                $(this).find('.QTY').val(value.qty);
            });
        });
    },
    fillEditOrderForToBePicked: function () {
        var thisObj = this;
        var url = apiUrl + 'order-forms/get-order-details-tobe-pick-orders';
        var payload = {CustomerId: thisObj.selectCustomerId.val(), orderId: thisObj.selectOrderId.val()};
        ajax(url, 'get', payload).then(function (response) {
            if (!response.status) {
                swal({
                    title: "Error!",
                    text: response.message,
                    icon: "error",
                    button: 'OK'
                });
                return;
            }
            var data = arrayColumns(response.response.companyinfo, ['owner_id', 'company']);
            var config = {
                'emptyIndex': ''
            };
            if (data.length === 1) {
                config['index'] = 1;
            }
            var html = generateDropdownHtml(data, config);
            thisObj.selectOwner.html(html);
            var customerinfo = response.response.customerinfo.map(customer => {
                var add = customer.custaddress;
                delete(customer.custaddres);
                return [
                    customer.id,
                    customer.custname + ': ' + add
                ];
            });
            var config = {
                'emptyIndex': ''
            };
            if (customerinfo.length === 1) {
                config['index'] = 1;
            }
            var html = generateDropdownHtml(customerinfo, config);
            thisObj.selectCustomer.html(html);
            thisObj.selectComment.html(response.response.comment);
            thisObj.selectCredit.val(response.response.ccredit);
            thisObj.selectPurchaseOrder.val(response.response.purchase_order);
            thisObj.selectDataReceivedDiv.html(response.response.producttable);
            var tabList = '';
            $.each(response.response.tabs, function (key, value) {
                if (key === 0) {
                    tabList += `<li  class="active"><a data-toggle="tab" href="#tab${value}">${value}</a></li>`;
                } else {
                    tabList += `<li><a data-toggle="tab" href="#tab${value}">${value}</a></li>`;
                }
            });
            $('#tablist').html(tabList);
            thisObj.updateTotal();
            thisObj.checkStatusOfShowWarehouse();
            
        });
    }
}

$(window).scroll(function () {
    if ($(this).scrollTop() > 50) {
        $('.topnav-header').addClass('shrink-header');
    } else {
        $('.topnav-header').removeClass('shrink-header');
    }
});

