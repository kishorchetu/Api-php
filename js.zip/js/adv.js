$(document).ready(function(){
    //For  advertisement    
    $("body").removeClass("noAdd");
    $("#collapseadv").click(function(){
        $(this).toggleClass("collapse-pos");
    });
});


