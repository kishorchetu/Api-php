$(document).ready(function () {
    var objOrders = new routeOrdersTable();
    objOrders.loadWeeklyStatus();
    $(document).on('click', '#wstatus', function () {
        objOrders.loadWeeklyStatus();
    });

    $(document).on('click', '.NewOrder', function () {
        objOrders.customerNewOrder(this);
    });

    $(document).on('click', '#tobepick', function () {
        objOrders.loadtoBePickedOrderTable();
        objOrders.checktoBePickedColumnPermission();
    });

    $(document).on('click', '.refreshtemp.tobepick', function () {
        objOrders.reloadtoBePickedOrderTable();
    });

    $(document).on('click', '.updateOrder', function () {
        objOrders.updateCustomerOrder(this);
    });

    $(document).on('click', '#pickorder', function () {
        objOrders.loadPickedOrderTable();
        objOrders.checkPickedColumnPermission();
    });

    $(document).on('click', '.refreshtemp.picked', function () {
        objOrders.reloadPickedOrderTable();
    });

    $(document).on('click', '#billed', function () {
        objOrders.loadBilledOrderTable();
        objOrders.checkBilledColumnPermission();
    });

    $(document).on('click', '.refreshtemp.billed', function () {
        objOrders.reloadBilledOrderTable();
    });

});
function routeOrdersTable() {
    this.refreshSelectors();
}
routeOrdersTable.prototype = {
    refreshSelectors: function () {
        this.selectorToBePickedOrderTable = $('#tobepickedtable');
        this.selectorPickedOrderTable = $('#pickedordertable');
        this.selectorBilledOrderTable = $('#billedOrderTable');
        this.selectorLoaderDefault = $('#loader');
        this.selectorGreterthanorEqualtoThree = $('#greterthanorequaltothree');
        this.selectorDivStatusTable = $('#wStatustable');
    },
    loadWeeklyStatus: function () {
        let thisObj = this;
        var url = apiUrl + 'routes/weekly-status-info';
        ajax(url, 'get').then(function (response) {
            if (!response.status) {
                thisObj.selectorDivStatusTable.html('<h3 style="text-align:center;">No Records found</h3>');
                return;
            }
            thisObj.selectorDivStatusTable.html(response.response.weeklytable);
        });
    },
    loadtoBePickedOrderTable: function () {
        this.refreshSelectors();
        if (isSet(window.toBePickedOrdersTable)) {
            this.reloadtoBePickedOrderTable();
            return;
        }
        window.toBePickedOrdersTable = this.selectorToBePickedOrderTable.DataTable({
            "ajax": {
                "url": apiUrl + 'routes/orders-to-be-picked',
                "type": "GET",
                "dataSrc": function (response) {
                    if (!response.status) {
                        return [];
                    }
                    return response.response;
                }
            },
            "columns": [
                {"data": "time-ordered"},
                {"data": "ordnum"},
                {"data": "owner-name"},
                {"data": "comments"},
                {
                    class: 'textAlignCenter',
                    mRender: function (data, type, full)
                    {
                        return 'Not Picked';
                    }
                },
                {"data": "amt-due"},
                {"data": "qty-ord"},
                {"data": "qty-sold"},
                {
                    class: 'textAligCenter',
                    mRender: function (data, type, full)
                    {
                        return `<center>
                                        <button class="btn btn-block btn-xs btn-danger updateOrder">
                                            Update
                                        </button>
                                    </center>`;
                    }
                }
            ],
            createdRow: function (row, data, index) {
                $(row).attr('data-id', data.customer_id + '~' + data.ordnum);
            }
        });
    },
    loadPickedOrderTable: function () {
        this.refreshSelectors();
        if (isSet(window.PickedOrdersTable)) {
            this.reloadPickedOrderTable();
            return;
        }
        window.PickedOrdersTable = this.selectorPickedOrderTable.DataTable({
            "ajax": {
                "url": apiUrl + 'routes/orders-picked',
                "type": "GET",
                "dataSrc": function (response) {
                    if (!response.status) {
                        return [];
                    }
                    return response.response;
                }
            },
            "columns": [
                {"data": "time-ordered"},
                {"data": "ordnum"},
                {"data": "owner-name"},
                {"data": "comments"},
                {
                    class: 'textAlignCenter',
                    mRender: function (data, type, full)
                    {
                        return 'Picked';
                    }
                },
                {"data": "amt-due"},
                {"data": "qty-ord"},
                {"data": "qty-sold"}
            ]
        });
    },
    loadBilledOrderTable: function () {
        this.refreshSelectors();
        if (isSet(window.BilledOrderTable)) {
            this.reloadPickedOrderTable();
            return;
        }
        window.BilledOrderTable = this.selectorBilledOrderTable.DataTable({
            "ajax": {
                "url": apiUrl + 'routes/orders-billed',
                "type": "GET",
                "dataSrc": function (response) {
                    if (!response.status) {
                        return [];
                    }
                    return response.response;
                }
            },
            "columns": [
                {"data": "time-ordered"},
                {"data": "ordnum"},
                {"data": "owner-name"},
                {"data": "comments"},
                {
                    class: 'textAlignCenter',
                    mRender: function (data, type, full)
                    {
                        return 'Billed';
                    }
                },
                {"data": "amt-due"},
                {"data": "qty-ord"},
                {"data": "qty-sold"}
            ]
        });
    },
    reloadtoBePickedOrderTable: function () {
        this.selectorToBePickedOrderTable.DataTable().ajax.reload();
    },
    reloadPickedOrderTable: function () {
        this.selectorPickedOrderTable.DataTable().ajax.reload();
    },
    updateCustomerOrder: function (responce) {
        let cust = getRecordId(responce).split("~")[0];
        let order = getRecordId(responce).split("~")[1];

//        popup = window.open("update-create-order.php?cust=" + cust + "&order=" + order, "_blank", "toolbar=yes, scrollbars=yes, resizable=yes, top=500, left=500, width=400, height=400");
        popup = window.open("order-form.php?customerId=" + cust + "&orderId=" + order, "_blank", "toolbar=yes, scrollbars=yes, resizable=yes, top=500, left=500, width=400, height=400");
        popup.focus();
    },
    reloadBilledOrderTable: function () {
        this.selectorBilledOrderTable.DataTable().ajax.reload();
    },
    checktoBePickedColumnPermission: function () {
        if (this.selectorGreterthanorEqualtoThree.val() != 1) {
            this.selectorToBePickedOrderTable.DataTable().column(5).visible(false);
        }
    },
    checkPickedColumnPermission: function () {
        if (this.selectorGreterthanorEqualtoThree.val() != 1) {
            this.selectorPickedOrderTable.DataTable().column(5).visible(false);
        }
    },
    checkBilledColumnPermission: function () {
        if (this.selectorGreterthanorEqualtoThree.val() != 1) {
            this.selectorBilledOrderTable.DataTable().column(5).visible(false);
        }
    },
    customerNewOrder: function (refrence) {
        if (refrence.hasAttribute('cust-id')) {
            //var url = "customerOrder.php?cust=" + refrence.getAttribute('cust-id');
            var url = "order-form.php?customerId=" + refrence.getAttribute('cust-id');
        } else {
            //var url = "customerOrder.php";
            var url = "order-form.php";
        }
       // popup = window.open(url, "_blank", "toolbar=yes, scrollbars=yes, resizable=yes, top=500, left=500, width=400, height=400");
        popup = window.open(url, '_blank');
        popup.focus();
    }
};



