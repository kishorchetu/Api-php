$(document).ready(function() {
        $("#changepassmodal").on("shown.bs.modal", function(e) {
            $('#editPasswordFormforuserprofile').bootstrapValidator('resetForm', true);
        })
        $('#editPasswordFormforuserprofile').bootstrapValidator({
            feedbackIcons: {
                valid: 'glyphicon glyphicon-ok',
                invalid: 'glyphicon glyphicon-remove',
                validating: 'glyphicon glyphicon-refresh'
            },
            fields: {
                oldPass:{
                    validators: {
                        notEmpty: {
                            message: 'Password is compulsory'
                        }
                    }
                },
                newPass: {
                    validators: {
                        notEmpty: {
                            message: 'Password is compulsory'
                        },
                        identical: {
                            field: 'confirmPass',
                            message: 'The password and its confirm are not the same'
                        }
                    }
                },
                confirmPass: {
                    validators: {
                        notEmpty: {
                            message: 'Password compulsory'
                        },
                        identical: {
                            field: 'newPass',
                            message: 'The password and its confirm are not the same'
                        }
                    }
                }
            },
            onSuccess: function(e, data) {
                    e.preventDefault();
                    $.ajax({
                        url: apiUrl +'login',
                        type: "POST",
                        data: {
                        oldpassword:$('#oldPass').val(),
                        newpassword:$('#newPass').val(),
                        userid:$('#uid').val(),
                        action: 'changepasswordforuser'
                        },
                        complete: function(xhr, textStatus) {
                            var res = xhr.responseJSON;
                            if(xhr.status==200){
                                if(res['status']==true){
                                    swal({
                                        title: "Password Changed!",
                                        text: res['message'],
                                        icon: "success",
                                        button: 'OK',
                                    });
                                    $('#changepassmodal').modal('hide');
                                }
                                else{
                                    swal({
                                        title: "Error!",
                                        text: res['message'],
                                        icon: "error",
                                        button: 'OK',
                                    });
                                }  
                            }
                            else{
                                swal({
                                        title: "Error!",
                                        text: res['message'],
                                        icon: "error",
                                        button: 'OK',
                                    });
                            }
                            $('#editPasswordFormforuserprofile').bootstrapValidator('resetForm', true);
                        } 
                    });
            }
        });
    });