<?php
	ini_set('display_errors',1);
	ini_set('display_startup_errors',1);
	error_reporting(-1);
	header('Content-Type: text/html; charset=utf-8');
	
	require_once($_SERVER['DOCUMENT_ROOT'] . '/includes.php');

	$owner_id = $_SESSION['ownerid'];
	$rt_order = "rt_orders".$owner_id;
	$rt_orderinfo = "rt_orderinfo".$owner_id;
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<!--<meta http-equiv="refresh" content="300">-->
<title>Drivers Page</title>
<link rel="stylesheet" href="//code.jquery.com/ui/1.11.2/themes/smoothness/jquery-ui.css">
<link href="css/bootstrap.min.css" rel="stylesheet">
<link href="css/bootstrap-theme.min.css" rel="stylesheet">
<style>
body {padding-top: 70px;padding-bottom: 30px;}
.progress{height: 10px !important;margin-top: 5px !important; margin-bottom:0px !important;}
.tab-pane{padding:10px !important;}
</style>
<link href="css/style.css" rel="stylesheet">

 <script src="js/jquery-1.10.2.min.js"></script> 
 <script src="//code.jquery.com/ui/1.11.2/jquery-ui.js"></script>
 <script src="js/bootstrap.min.js"></script>
 <script type="text/javascript">
function customerOrder(cust, order)
	{
		popup = window.open("update-create-order.php?cust="+cust+"&order="+order, "_blank", "toolbar=yes, scrollbars=yes, resizable=yes, top=500, left=500, width=400, height=400");
		popup.focus();
	}
	
	function printOrder(order)
	{
		popup = window.open("print-order.php?order="+order, "_blank", "toolbar=yes, scrollbars=yes, resizable=yes, top=500, left=500, width=400, height=400");
		popup.focus();
	}

	
	
  var simple = {
	onLoad:function(){
				$.ajax({
							type: 'post',
							url: 'rt-backend.php',
							data: {'fetchDriverTab': '1'},
							beforeSend: function(){
								$("#loader").modal({'backdrop': 'static'});
							},
							success:function(html){
								//alert(html);
								$("#loader").modal('hide');
								$("#TabData").prepend(html);
							},
							error:function(a,b,c){
									$("#loader").modal('hide');
									$("#error_modal").find('.col-md-12').text("Something went wrong. Please try again.");
									$("#error_modal").modal('show');
									setTimeout(function(){
										$("#error_modal").modal('hide');
									}, 1500);
							}
					});
	},
	fetchOwnerDetails:function (){
	  var val = $("#selectOwner").val();
	  if(val != 0)
	  {
		  $("#pAmount").val('');
		  $("#date").val('');
		  $("#checkNumber").val('');
		  
		  $.ajax({
						type: 'post',
						url: 'rt-backend.php',
						data: {'fetchOwnerDetails': val},
						dataType: "json",
						beforeSend: function(){
							$("#loader").modal({'backdrop': 'static'});
							//$("#view_edit_Order").find('.modal-body').text('loading...').css('text-align', 'center');
						},
						success:function(html){
							//alert(html);
							$("#loader").modal('hide');
							$("#billingDetails").show();
							$("#countOrder").val(html.orderinfo_detail.number);
							$("#aDue").val(html.orderinfo_detail.payment);
							$("#orderBillingTab").html(html.ans);

						},
						error:function(a,b,c){
							$("#loader").modal('hide');
							$("#error_modal").find('.col-md-12').text("Something went wrong. Please try again.");
								$("#error_modal").modal('show');
								setTimeout(function(){
									$("#error_modal").modal('hide');
								}, 1000)
						}
					})
	  }
  }//fetchOwnerDetails(){
 };
 
 simple.onLoad();
 </script>
</head>
<body>
<?php
	$weeks=3;
	$enddate=time();
	$tf=generate_timeframe($weeks,$enddate);
	//print_r($tf);
?>
<?php require_once($_SERVER['DOCUMENT_ROOT'] . '/templates/navbar.php'); ?>
    <div class="container" role="main">
    
    <div class="modal fade" id="error_modal" style="z-index:10000;">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-body">
          <div class="row">
          	<div class="col-md-12" style="text-align:center;">
            	
            </div>
           </div>
          </div>
        </div><!-- /.modal-content -->
      </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->
           
    <div class="modal fade" id="loader">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-body">
          	<div style="text-align:center;">loading...</div>
          	<div class="progress">
              <div class="progress-bar progress-bar-success progress-bar-striped active" role="progressbar" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100" style="width: 100%">
              </div>
            </div>
          </div>
        </div><!-- /.modal-content -->
      </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->
    
    <div class="modal fade" id="verify_Invoice">
      <div class="modal-dialog modal-lg">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
           <h4 class="modal-title">Verifying Invoice no: <span id="verify_invoice_no"></span></h4>
          </div>
          <div class="modal-body">
          
          </div>
          <div class="modal-footer">
<!--            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>-->
            <button type="button" class="btn btn-primary submitbuton" id=""  payment="" version=""  data-loading-text="Submitting..."  data-complete-text="Submitted!" >Verify & Submit</button>
          </div>
        </div><!-- /.modal-content -->
      </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->
    
<!--        <div class="modal fade" id="view_Invoice">
      <div class="modal-dialog modal-lg">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
            <h4 class="modal-title">Viewing Invoice no: <span id="view_invoice_no"></span></h4>
          </div>
          <div class="modal-body">
          
          </div>
          <div class="modal-footer">
           <button type="button" class="btn btn-primary" id="activateInvoice"  data-loading-text="Activating..."  data-complete-text="Activated!">Activate</button>
          </div>
        </div>
      </div>
    </div>
-->
    
      <div class="alert alert-success">
        <!--<h2>Orders Stats</h2>-->
        <div class="row">
            <div class="col-md-12 table-responsive">
            	<?php
				
				
				$owner = $_SESSION['ownerid'];
				//query to pick Total Orders in current week
					
					$qq = mysql_query("SELECT * from p_orderinfo limit 1") or die(mysql_error()); 
						while($qw = mysql_fetch_assoc($qq))
						{
							echo "<pre>", print_r($qw),"</pre>";
							//print_r($qw);
						}
						
				/*	$qq = mysql_query("SHOW COLUMNS FROM $rt_orderinfo"); 
						while($qw = mysql_fetch_assoc($qq))
						{
							echo "aa<pre>", print_r($qw),"</pre>";
							//print_r($qw);
						}*/
				//mysql_query("DELETE FROM $rt_order") or die(mysql_error());
				//mysql_query("DELETE FROM $rt_orderinfo") or die(mysql_error());
					//$query = "SELECT T1.* from orderinfo as T1 LEFT JOIN $rt_orderinfo on T1.ordnum=$rt_orderinfo.wh_ordnum WHERE T1.owner_id='$owner' AND T1.ordnum >= ".$tf['current_start']." AND T1.ordnum <= ".$tf['current_end'];
					$query = "SELECT T1.* from orderinfo as T1 WHERE T1.owner_id='$owner' AND T1.ordnum >= ".$tf['current_start']." AND T1.ordnum <= ".$tf['current_end'];				
					$result = mysql_query($query) or die(mysql_error());
					$row = mysql_fetch_assoc($result);
				//	echo "<pre>", print_r($row),"</pre>";
					$num = mysql_num_rows($result);

				// query to pick Total Orders in past two weeks
					//$query1 = "SELECT T1.* from orderinfo as T1 LEFT JOIN $rt_orderinfo on T1.ordnum=$rt_orderinfo.wh_ordnum WHERE T1.owner_id='$owner' AND T1.ordnum >= ".$tf['w1_start']." AND T1.ordnum <= ".$tf['w3_end'];
					$query1 = "SELECT T1.* from orderinfo as T1 WHERE T1.owner_id='$owner' AND T1.ordnum >= ".$tf['w1_start']." AND T1.ordnum <= ".$tf['w3_end'];
					$result1 = mysql_query($query1) or die(mysql_error());
					$num1 = mysql_num_rows($result1);
					
				//query to pick Total Orders NEEDING invoices created
					$query2 = "SELECT DISTINCT T1.* from orderinfo as T1 
					LEFT JOIN $rt_orderinfo on T1.ordnum=$rt_orderinfo.wh_ordnum 
					WHERE T1.owner_id='$owner' AND T1.inv_create='0'";
					$result2 = mysql_query($query2) or die(mysql_error());
					$num2 = mysql_num_rows($result2);

				//query to pick Total Orders NEEDING verification
					$query3 = "SELECT DISTINCT T1.* from orderinfo as T1
					LEFT JOIN $rt_orderinfo as T4 on T1.ordnum=T4.wh_ordnum 					
					WHERE T1.owner_id='$owner' AND T4.collected = '1' AND T4.verification_lock != '1' AND (T1.inv_create != 0 AND T1.owner_verified='0')";
					$result3 = mysql_query($query3) or die(mysql_error());
					$num3 = mysql_num_rows($result3);

					?>
            
                <table class="table table-bordered" style="margin-bottom:0px;">
                     <tr>
                        <th style="text-align:center;">Total Orders in current week</th>
					    <th style="text-align:center;">Total Orders in past two weeks</th>
						<th style="text-align:center;">Total Orders NEEDING Invoices created</th>
						<th style="text-align:center;">Total Orders NEEDING Verification</th>
                     </tr>
                     <tr>
                        <th style="text-align:center;"><?php echo $num; ?></th>
                        <th style="text-align:center;"><?php echo $num1; ?></th>
						<th style="text-align:center;"><?php echo $num2; ?></th>
						 <th style="text-align:center;"><?php echo $num3; ?></th>
                     </tr>
                </table>
            </div>
        </div>
      </div>

      <div class="row">
        <div class="col-md-12">
        	<ul class="nav manualTabs nav-tabs nav-justified" role="tablist">
              <li class="active"><a href="#orders" role="tab" data-toggle="tab">Orders</a></li>
              <li><a href="#invoices" role="tab" data-toggle="tab">Invoices</a></li>
              <?php if ($_SESSION['role'] == 1 || $_SESSION['role'] == 4){ ?>
              	<li><a href="#verification" role="tab" data-toggle="tab">Owner Verification</a></li>
              <?php } ?>
              	<li><a href="#search" role="tab" data-toggle="tab">Search Invoice</a></li>
            </ul>
            
            <!-- Tab panes -->
            <div class="tab-content" id="TabData">
					
	<!----------------- VERIFICATION TAB STARTS----------->			
              
              <?php if ($_SESSION['role'] == 1 || $_SESSION['role'] == 4){ ?>
                   <div class="tab-pane" id="verification">
                    <div class="panel panel-success">
						<div class="panel-heading">Owner Verification</div>
						<div class="panel-body table-responsive" style="max-height:800px; overflow-y:auto;">
					<?php
					$query2 = "SELECT DISTINCT T1.*,  T3.custname, T3.cash_discount, T2.ord_cases, T2.sold_cases, T4.collected FROM orderinfo AS T1
						   	   LEFT JOIN
							   (
							   		select
										ordnum
										,sum(quantity) as 'sold_cases'
										,sum(ord_qty) as 'ord_cases'
										from orders
										group by ordnum
							   
							   ) AS T2 ON T1.ordnum = T2.ordnum
							   LEFT JOIN customer AS T3 ON T1.customer_id = T3.id 
							   LEFT JOIN $rt_orderinfo AS T4 ON T1.ordnum = T4.wh_ordnum 
							   WHERE T1.owner_id='$owner' AND T4.collected = '1' AND T4.verification_lock != '1' AND (T1.inv_create != 0 AND T1.owner_verified='0')
							   ORDER BY T1.ordnum DESC";
					$result2 = mysql_query($query2) or die(mysql_error());
					$num2 = mysql_num_rows($result2);
						if($num2)
						{
						
							$counter = 1;
							while($row2 = mysql_fetch_assoc($result2))
							{
								//echo "<pre>",print_r($row2),"</pre>";
								echo '<table class="table table-bordered">
                            <thead>
								<tr>
									<td colspan="9" align="center"><h3>Order - '.$row2['ordnum'].'</h3></td>
								</tr>
                              <tr class="danger">
                                <th>#</th>
                                <th>Order Number</th>
                                <th>Order Date</th>
                                <th>Customer Name</th>
                                <th>Comments</th>
                                <th>Ordered Cases</th>
                                <th>Picked Cases</th>
								<th>Time Picked</th>
								<th>Action</th>
                              </tr>
                            </thead>
                            <tbody>
									<tr class="parentRow" order="'.$row2['ordnum'].'">
									<td>'.$counter.'</td>
									<td>'.$row2['ordnum'].'</td>
									<td>'.date('l, M-d H:i', $row2['ordnum']).'</td>
									<td>'.$row2['custname'].'</td>
									<td>'.$row2['ordcomment'].'</td>
									<td>'.$row2['ord_cases'].'</td>
									<td>'.$row2['sold_cases'].'</td>
									<td>'.date('l@H:i', $row2['ord_pick_time']).'</td>';
							//	if ($row2['inv_create'] != 0){
							//		echo '<td><button class="btn btn-xs btn-danger createInvoice">Invoice Created</button></td>';
							//	}else{
									echo '<td><button class="btn btn-xs btn-block btn-danger createInvoice">Create new Invoice</button></td>';
							//	}
								echo '</tr>';
								echo '</tbody>
                          		  </table>';
								
								$ordnum = $row2['ordnum'];
								
								$query3 = "SELECT T1.*, T3.*, T2.*  FROM $rt_orderinfo AS T1
											LEFT JOIN
										   (
												select
													invnum,
													sum(pick_qty) as 'sold_cases'
													,sum(inv_qty) as 'ord_cases'
													,sum(pick_qty*sale_price) as 'ord_price'
													,sum(inv_qty*inv_price) as 'prt_price'
													,sum(sale_price) as 'sold_price'
													from $rt_order
													group by invnum
										   
										   ) AS T2 ON T1.invnum = T2.invnum
							   LEFT JOIN customer AS T3 ON T1.customer_id = T3.id 
							    WHERE wh_ordnum = '$ordnum' and verification_lock != '1'";
								
								$result3 = mysql_query($query3) or die(mysql_error());
								$num3 = mysql_num_rows($result3);
								if($num3)
								{
									$inv = 0;
									echo '<table class="table table-bordered" style="margin-top:0px; margin-left:auto; margin-right:auto; width:100%;">
                            	<thead>
								<tr>
									<td colspan="14" align="center"><h4>'.$num3.' Invoice(s) found</h4></td>
								</tr>
								<tr class="success">
											<th>#</th>
											<th>Invoice Number</th>
											<th>Invoice Date</th>
											<th>Invoice Version</th>
											<th>Ordered Cases</th>
											<th>Picked Cases</th>
											<th>Payment Terms</th>
											<th>Invoice Cases</th>
											<th>Invoice Total</th>
											<th>Invoice Total Ordered</th>
											<th>Invoice Total Printed</th>
											<th>Customer Credit</th>
											<th>Cash Discount</th>
											<th>Action</th>
										  </tr>
										  </thead>
										  <tbody>';
									while($row3 = mysql_fetch_assoc($result3))
									{
										//print_r($row3);
										$inv++;
										echo '
										  <tr class="invoiceRow" invoice="'.$row3['invnum'].'">
											<td>'.$inv.'</td>
											<td>'.$row3['invnum'].'</td>
											<td>'.date('l, M-d H:i', $row3['invnum']).'</td>
											<td class="version">'.$row3['inv_version'].'</td>
											<td>'.$row2['ord_cases'].'</td>
											<td>'.$row2['sold_cases'].'</td>
											<td>'.$row3['payment_terms'].'</td>
											<td>'.$row3['ord_cases'].'</td>
											<td class="payment">$'.$row2['ordcusttotal'].'</td>
											
											<td>$'.(($row3['ord_price']-$row2['ordcustcredit'])-(($row3['ord_price']-$row2['ordcustcredit'])*$row2['cash_discount'])).'</td>
											<td>$'.(($row3['prt_price']-$row2['ordcustcredit'])-(($row3['prt_price']-$row2['ordcustcredit'])*$row2['cash_discount'])).'</td>

											<td>$'.$row2['ordcustcredit'].'</td>
											<td>$'.$row2['cash_discount'].'</td>';
											
									//	if($row3['deactivated'] == 0)
									//	{
											$dir = 'rtInvoice'.$_SESSION['ownerid'].'/'.$ordnum.'_'.$row3['invnum'].'_'.$row3['inv_version'].'.pdf';
											
											echo '<td><a href="'.$dir.'" target="_blank" class="btn btn-xs btn-primary btn-block printInvoice">Print Invoice</a><button class="btn btn-xs btn-block btn-success verifyInvoice">Verification</button></td>';
									//	}
									//	else
									//		echo '<td></td>';
											echo '</tr>';
										//echo '<tr><td><pre>',print_r($row3),'</pre></td></tr>';
									}
								}
								else
								{
									echo '<h4 style="text-align:center;">No Invoice Found for this order</h4>';
								}
									echo '</tbody>
                          		  </table><hr />';
								  $counter++;
							}//while($row = mysql_fetch_assoc($result))
							?>
                              
                            <?php
						}
						else
						{
							echo "<h3 style=\"text-align:center;\">No records found</h3>";
						}
					?>
                             </div>
                     </div>
                   </div>
                    <?php }	?>
					
	<!----------------- VERIFICATION TAB ENDS----------->			
	<!----------------- SEARCH TAB STARTS----------->		
					
					
	<div class="tab-pane" id="search">
        <div class="panel panel-success">
			<div class="panel-heading">Search</div>
	    	<div class="panel-body table-responsive">
				<form class="form-horizontal" id="searchForm">
                        	<div class="row">
                            	<div class="col-md-6 col-sm-12 col-xs-12 col-md-offset-3">
                                	 <h4>Please Enter the following:</h4>
            		<div class="form-group">
                            <label class="col-sm-4 control-label" for="textinput">Order number</label>
                            <div class="col-sm-8">
                              <input type="text" name="ordnum" id="ordnum" class="form-control">
                            </div>
                     </div>
                            <?php
							$owner = $_SESSION['ownerid'];
							$role = $_SESSION['role'];
							$where = '';
							if(true)//$role == 1 || $role == 2 || $role == 4
							{
								$where .= "WHERE route_owner = '1'";
								$query = "SELECT * FROM owner $where";
								//echo $query;
								$result = mysql_query($query);
								$num = mysql_num_rows($result);
								if($num)
								{
									echo '<div class="form-group">
									<label class="col-sm-4 control-label" for="textinput">Route owner</label>
									<div class="col-sm-8">';

									echo '<select class="form-control" name="routeOwner" id="routeOwner">';
									echo '<option value="All" selected="selected">All</option>';
									while($row = mysql_fetch_assoc($result))
									{
										//echo "<pre>",print_r($row),"</pre>";
										echo '<option value="'.$row['id'].'">'.$row['owner'].'</option>';
									}//while($row = mysql_fetch_assoc($result))
									echo '</select></div></div>';
								}//if($num)
								else
								{
									//echo "Sorry no family exists.";
								}
							}
							elseif($role == 1 || $role == 2)
							{
								echo '<input type="hidden" readonly="readonly" name="routeOwner" id="routeOwner" class="form-control" value="'.$owner.'">';
							}
							//echo $owner;
						?>
                           
                        <?php
							$owner = $_SESSION['ownerid'];
							//echo $owner;
							$where = '';
							if($role == 1 || $role == 2)
							{
								$where .= "WHERE owner_id = '$owner'";
							}
							$query = "SELECT id, custname, custaddress FROM customer $where";
							//echo $query;
							$result = mysql_query($query);
							$num = mysql_num_rows($result);
							if($num)
							{
								echo '<div class="form-group">
									  	<label class="col-sm-4 control-label" for="textinput">Customer</label>
									  <div class="col-sm-8">';
								echo '<select class="form-control" name="selectCustomer" id="selectCustomer">';
								echo '<option value="All" selected="selected">All</option>';
								while($row = mysql_fetch_assoc($result))
								{
									//echo "<pre>",print_r($row),"</pre>";
									echo '<option value="'.$row['id'].'">'.$row['custname'].' - '.$row['custaddress'].'</option>';
								}//while($row = mysql_fetch_assoc($result))
								echo '</select></div></div>';
							}//if($num)
							else
							{
								//echo "Sorry no family exists.";
							}
						?>
                     
                     <div class="form-group">
                        <label class="col-sm-4 control-label" for="textinput">Date</label>
                        <div class="col-sm-8">
                        	<div class="input-group">
                              <input type="text" class="form-control" id="fromDate" name="fromDate" placeholder="From">
                              <span class="input-group-addon">-</span>
                              <input type="text" class="form-control" id="toDate" name="toDate" placeholder="To">
                            </div>
                        </div>
                     </div>
                     
                     <div class="form-group">
                        <label class="col-sm-4 control-label" for="textinput">Family</label>
                        <div class="col-sm-8">
                        <?php
							$query = "SELECT id, family, productname FROM products";
							$result = mysql_query($query);
							$num = mysql_num_rows($result);
							if($num)
							{
								echo '<select class="form-control" name="selectFamily" id="selectFamily">';
								echo '<option value="All" selected="selected">All</option>';
								while($row = mysql_fetch_assoc($result))
								{
									echo '<option value="'.$row['family'].'">'.$row['productname'].'</option>';
								}//while($row = mysql_fetch_assoc($result))
								echo '</select>';
							}//if($num)
							else
							{
								echo "Sorry no family exists.";
							}
							
							/*$query = "SELECT * FROM orderinfo";
							$result = mysql_query($query);
							$num = mysql_num_rows($result);
							echo $num;
							if($num)
							{
								while($row = mysql_fetch_assoc($result))
								{
									echo "<pre>",print_r($row),"</pre>";
								}//while($row = mysql_fetch_assoc($result))
								
							}//if($num)
							else
							{
								echo "Sorry no family exists.";
							}*/
						?>
                        </div>
                     </div>
                     
                      <div class="form-group">
                        <label class="col-sm-4 control-label" for="textinput">Flavor</label>
                        <div class="col-sm-8">
                        <?php
							$query = "SELECT id, model, description FROM flavor";
							$result = mysql_query($query);
							$num = mysql_num_rows($result);
							if($num)
							{
								echo '<select class="form-control" name="selectFlavor" id="selectFlavor">';
								echo '<option value="All" selected="selected">All</option>';
								while($row = mysql_fetch_assoc($result))
								{
									echo '<option value="'.$row['model'].'">'.$row['description'].' ('.$row['model'].')</option>';
								}//while($row = mysql_fetch_assoc($result))
								echo '</select>';
							}//if($num)
							else
							{
								echo "Sorry no Flavor exists.";
							}
						?>
                        </div>
                     </div>
                    
                     <div class="form-group">
                        <label class="col-sm-4 control-label" for="textinput"></label>
                        <div class="col-sm-8">
                          <button type="button" class="btn btn-success" id="searchOrders"><span class="glyphicon glyphicon-search"></span>&nbsp;Search</button>
                        </div>
                     </div>
                     </div>
                     </div>
                     </form>
					 
					  <div class="row">
                                <div class="col-md-12 table-responsive" id="searchData" style="max-height:500px; overflow:auto;">
                                    
                                </div>
                     </div>
            </div>
        </div>
    </div>
					
					
	<!----------------- SEARCH TAB ENDS----------->
                    </div>
              </div>
            </div>
        </div>
      </div>
    </div>

 <script type="text/javascript">
  $(function() {
  /*  $( "#sDate" ).datepicker({
            onSelect: function(dateStr) {     
                  var date = $(this).datepicker('getDate');
                  if (date) {
                        date.setDate(date.getDate() + 1);
                  }
                  $('#eDate').datepicker('option', 'minDate', date);
            }
      });
	  
      $( "#eDate" ).datepicker({
            onSelect: function (selectedDate) {
                  var date = $(this).datepicker('getDate');
                  if (date) {
                        date.setDate(date.getDate() - 1);
                  }
                  $('#sDate').datepicker('option', 'maxDate', date || 0);
            }
      });*/
	  
	   $( "#fromDate" ).datepicker({
            onSelect: function(dateStr) {     
                  var date = $(this).datepicker('getDate');
                  if (date) {
                        date.setDate(date.getDate() + 1);
                  }
                  //$(this).datepicker("option", "dateFormat", 'yy-mm-dd');
				 $('#toDate').datepicker('option', 'minDate', date || 0);
            }
      });
	  
      $( "#toDate" ).datepicker({
            onSelect: function (selectedDate) {
                  var date = $(this).datepicker('getDate');
                  if (date) {
                        date.setDate(date.getDate() - 1);
                  }
                   $('#fromDate').datepicker('option', 'maxDate', date || 0);
            }
      });

  });
  
  
  
  
  	 $(document).on('change', '#selectFamily', function(e){
		 var family = $(this).val();
		 
		 	$.ajax({
							type: 'post',
							url: 'backend.php',
							data: {'fetchFlavorsForFamily': family},
							dataType: "json",
							beforeSend: function(){
								$("#loader").modal({'backdrop': 'static'});
							},
							success:function(html){
								$("#loader").modal('hide');
								if(html.error)
								{
									$("#error_modal").find('.col-md-12').text(html.msg);
									$("#error_modal").modal('show');
									setTimeout(function(){
										$("#error_modal").modal('hide');
									}, 1500);
								}
								else
								{
									var option = '<option value="All" selected="selected">All</option>';
									$.each(html.msg, function(id, flavor){
										option += '<option value="'+id+'">'+flavor+'</option>';
									});
									
									$("#selectFlavor").html(option);
								}
							},
							error:function(a,b,c){
									$("#loader").modal('hide');
									$("#error_modal").find('.col-md-12').text("Something went wrong. Please try again.");
									$("#error_modal").modal('show');
									setTimeout(function(){
										$("#error_modal").modal('hide');
									}, 1500)
							}
					});
	 });

	 $(document).on('click', '#searchOrders', function(e){
		 var serialize = $("#searchForm").serialize();
			 $.ajax({
							type: 'post',
							url: 'rt-backend.php',
							data: serialize+'&searchForm=1',
							//dataType: "json",
							beforeSend: function(){
								$("#loader").modal({'backdrop': 'static'});
							},
							success:function(html){
								$("#loader").modal('hide');
								$("#searchData").html(html);
							},
							error:function(a,b,c){
									$("#loader").modal('hide');
									$("#error_modal").find('.col-md-12').text("Something went wrong. Please try again.");
									$("#error_modal").modal('show');
									setTimeout(function(){
										$("#error_modal").modal('hide');
									}, 1500)
							}
				});
	 });

  
  
 
  $(document).on('change', '#selectOwner', function(e){
	  simple.fetchOwnerDetails();
  });
  
 
 function fetchInvoice(invnum, modalId, buttonID){
	 		$.ajax({
						type: 'post',
						url: 'rt-backend.php',
						data: {'fetchInvoice': invnum, 'modalId':modalId},
						beforeSend: function(){
							$("#"+modalId).find('.modal-body').text('loading...').css('text-align', 'center');
						},
						success:function(html){
							//alert(html);
							$("#"+modalId).find('.modal-body').html(html);
							$(".submitbuton").attr('id', buttonID);
						},
						error:function(a,b,c){
							$("#error_modal").find('.col-md-12').text("Something went wrong. Please try again.");
							$("#error_modal").modal('show');
							setTimeout(function(){
								$("#error_modal").modal('hide');
							}, 1000)
						}
					})
 }//function fetchInvoice(){
 
 
 $(document).on('change', '#routeOwner', function(e){
		 var owner = $(this).val();
		 
		 	$.ajax({
							type: 'post',
							url: 'backend.php',
							data: {'fetchCustomersForOwner': owner},
							dataType: "json",
							beforeSend: function(){
								$("#loader").modal({'backdrop': 'static'});
							},
							success:function(html){
								$("#loader").modal('hide');
								if(html.error)
								{
									$("#error_modal").find('.col-md-12').text(html.msg);
									$("#error_modal").modal('show');
									setTimeout(function(){
										$("#error_modal").modal('hide');
									}, 1500);
								}
								else
								{
									var option = '<option value="All" selected="selected">All</option>';
									$.each(html.msg, function(id, customer){
										option += '<option value="'+id+'">'+customer+'</option>';
									});
									$("#selectCustomer").html(option);
								}
							},
							error:function(a,b,c){
									$("#loader").modal('hide');
									$("#error_modal").find('.col-md-12').text("Something went wrong. Please try again.");
									$("#error_modal").modal('show');
									setTimeout(function(){
										$("#error_modal").modal('hide');
									}, 1500)
							}
					});
	 });

	$(document).on('click', '.createInvoice, .makeNewInvoice', function(e){
		var ordernum = $(this).parents('tr.parentRow').attr('order');
		popup1 = window.open("RTupdateorder.php?order="+ordernum, "_blank", "toolbar=yes, scrollbars=yes, resizable=yes, top=500, left=500, width=400, height=400");
		popup1.focus();
	});
	
	
/*	$(document).on('click', '.viewInvoice', function(){
		var invnum = $(this).parents('tr.parentRow').attr('index');
			$("#view_invoice_no").text(invnum);
			$("#view_Invoice").modal({backdrop: 'static'});
			//window.location.reload();
			fetchInvoice(invnum, 'view_Invoice');
	});
	
	
	$(document).on('click', '.driverVerify', function(){
		var invnum = $(this).parents('tr.parentRow').attr('index');
			$("#verify_invoice_no").text(invnum);
			$("#verify_Invoice").modal({backdrop: 'static'});
			//window.location.reload();
			fetchInvoice(invnum, 'verify_Invoice', 'driverVerify');
	});*/
	
	$(document).on('click', '.verifyInvoice', function(){
		var invnum = $(this).parents('tr.invoiceRow').attr('invoice');
		var payment = ($(this).parents('tr.invoiceRow').find('.payment').text()).replace('$','');
		var version = ($(this).parents('tr.invoiceRow').find('.version').text());
			
		
			$(".submitbuton").attr('payment', payment);
				$(".submitbuton").attr('version', version);
			$("#verify_invoice_no").tex