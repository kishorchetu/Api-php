$(document).ready(function () {
    var objInventoryOrders = new InventoryOrders();
    objInventoryOrders.loadTable();
    objInventoryOrders.loadInventoryStatus();
    $(document).on('click', '#startstopinventory', function () {
        objInventoryOrders.startorstopInventory();
    });
    $(document).on('click', '.all_orders_handler_sec button', function () {
        objInventoryOrders.approveRejectAllOrders(this);
    });
    $(document).on('click', '.actionCol a', function () {
        objInventoryOrders.approveRejectOrder(this);
    });
    $(document).on('click', '.actionCol button', function () {
        objInventoryOrders.editOrder(this);
    });

});
function InventoryOrders() {
    this.refreshSelectors();
}
InventoryOrders.prototype = {
    refreshSelectors: function () {
        this.selectorTable = $('#unprocessordertable');
        this.startstopStatus = $('#state');
        this.startstopStatusdiv = $('#startstopinventory');
        this.selectorLoaderDefault = $('#loader');
    },
    loadTable: function () {
        this.refreshSelectors();
        if (isSet(window.inventoryOrdersTable)) {
            this.reloadTable();
            return;
        }
        window.inventoryOrdersTable = this.selectorTable.DataTable({
            "ajax": {
                "url": apiUrl + 'process-inventory-orders/orders',
                "type": "GET",
                "dataSrc": function (response) {
                    if (!response.status) {
                        return [];
                    }
                    return response.response;
                }
            },
            "columns": [
                {"data": "vendorname"},
                {"data": "orderdate"},
                {"data": "custtotal"},
                {"data": "whtotal"},
                {
                    class: 'textAligCenter actionCol',
                    mRender: function (data, type, full)
                    {
                        return `<center>
                                    <a class="btn btn-danger btn-xs cancel" title="Cancel Order">
                                        <i class="fa fa-trash"></i>
                                    </a>
                                    <a class="btn btn-success btn-xs approve" title="Approve Order">
                                       <i class="fa fa-check"></i>
                                    </a>
                                    <button class="btn btn-warning btn-xs edit" title="Edit Order">
                                        <i class="fa fa-pencil"></i>
                                    </button>
                                </center>`;
                    }
                }
            ],
            createdRow: function (row, data, index) {
                $(row).attr('data-id', data.order_id);
            }
        });
    },
    reloadTable: function () {
        this.selectorTable.DataTable().ajax.reload();
    },
    loadInventoryStatus: function () {
        let thisObj = this;
        var url = apiUrl + 'process-inventory-orders/load-inventory-status';
        ajax(url, 'get').then(function (response) {
            if (!response.status) {
                swal({
                    title: "Error!",
                    text: response.message,
                    icon: "error",
                    button: 'OK',
                });
                return;
            }
            thisObj.startstopStatus.attr('val', response.response.status);
            thisObj.checkState();
        });
    },
    startorstopInventory: function () {
        let thisObj = this;
        var url = apiUrl + 'process-inventory-orders/start-or-stop-inventory';
        ajax(url, 'get').then(function (response) {
            if (!response.status) {
                swal({
                    title: "Error!",
                    text: response.message,
                    icon: "error",
                    button: 'OK',
                });
                return;
            }
            thisObj.startstopStatus.attr('val', response.response.status);
            thisObj.checkState();
        });
    },
    checkState: function () {
        if (this.startstopStatus.attr('val') == 0) {
            this.startstopStatusdiv.removeClass("btn-success");
            this.startstopStatusdiv.addClass("btn-danger");
            this.startstopStatus.attr('val', 1);
            this.startstopStatus.html('Stop Inventory Process');
        } else {
            this.startstopStatusdiv.removeClass("btn-danger");
            this.startstopStatusdiv.addClass("btn-success");
            this.startstopStatus.attr('val', 0);
            this.startstopStatus.html('Start Inventory Process');
        }
    },
    approveRejectAllOrders: function (reference) {
        let thisObj = this;
        if (window.inventoryOrdersTable.rows().data().length === 0) {
            swal({
                title: "Error!",
                text: "There are no record in Table",
                icon: "error",
                button: 'OK',
            });
            return;
        }
        var orderId = [];
        for (var i = 0; window.inventoryOrdersTable.rows().data().length > i; i++) {
            orderId[i] = window.inventoryOrdersTable.rows().data()[i]['order_id'];
        }
        var payload = {orderids: JSON.stringify(orderId)};
        var url = apiUrl + 'process-inventory-orders/' + ($(reference).hasClass('btn-info') ? 'approve-order' : 'cancel-order');
        ajax(url, 'post', payload).then(function (response) {
            console.log(response);
            swal({
                title: response.status ? response.response.title : "Error",
                text: response.status ? response.response.message : new Array(response.message, ...response.response).join('\n'),
                icon: response.status ? "success" : "error",
                button: "OK"
            }).then(function () {
                thisObj.loadTable();
            });
        });

    },
    approveRejectOrder: function (reference) {
        var orderId = [];
        orderId[0] = parseInt(getRecordId(reference));
        var payload = {orderids: JSON.stringify(orderId)};
        let thisObj = this;
        var url = apiUrl + 'process-inventory-orders/' + ($(reference).hasClass('cancel') ? 'cancel-order' : 'approve-order');
        ajax(url, 'post', payload).then(function (response) {
            console.log(response);
            swal({
                title: response.status ? response.response.title : "Error",
                text: response.status ? response.response.message : new Array(response.message, ...response.response).join('\n'),
                icon: response.status ? "success" : "error",
                button: "OK"
            }).then(function () {
                thisObj.loadTable();
            });
        });
    },
    editOrder: function (reference){
        var orderId = parseInt(getRecordId(reference));
        var win = window.open(baseUrl+'order-form.php?orderId='+orderId, '_blank');
        if (win) {
            win.focus();
        } 
    }
};



