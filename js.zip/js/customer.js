$(document).ready(function () {
    var objCustomers = new Customers();
    objCustomers.checkForAdminLogin();
    objCustomers.checkForAdminLoginedit();
    $(document).on('change', '#selectAllCustomers', function (e) {
        objCustomers.checkUncheckAllCustomers(this);
    });

    $(document).on('click', '.addcustUpCharge', function (e) {
        var val = $(this).val();
        if (val == 'Yes')
        {
            $("#UpChargePerDiv").show(200);
        } else if (val == 'No')
        {
            $("#UpChargePerDiv").hide(200);
        }
    });

    $(document).on('click', '.editcustUpCharge', function (e) {
        var val = $(this).val();
        if (val == 'Yes')
        {
            $("#editUpChargePerDiv").show(200);
        } else if (val == 'No')
        {
            $("#editUpChargePerDiv").hide(200);
        }
    });

    $(document).on('change', '#addcustPaymentTerms', function (e) {
        var val = $(this).val();
        if (val == 'Cash Discount')
        {
            $("#CashDisPerDiv").show(200);
        } else
        {
            $("#CashDisPerDiv").hide(200);
        }
    });

    $(document).on('change', '#editcustPaymentTerms', function (e) {
        var val = $(this).val();
        if (val == 'Cash Discount')
        {
            $("#editCashDisPerDiv").show(200);
        } else
        {
            $("#editCashDisPerDiv").hide(200);
        }
    });

    $(document).on('click', '#addcustCopyPricing', function (e) {
        var x = this.checked;

        if (x)
        {
            $("#copyPricingDiv").show(200);
        } else
        {
            $("#copyPricingDiv").hide(200);
        }
    });

    $(document).on('click', '#editCustomerBut', function (e) {
        objCustomers.editCustomer();
    });

    $(document).on('click', '#addCustomerBut', function (e) {
        objCustomers.addCustomer();
    });

    $(document).on('click', '.reactBut', function (e) {
        var activateArr = new Array();
        activateArr.push($(this).attr('fid'));
        objCustomers.activateCustomer(activateArr);
    });

    $(document).on('click', '.deactBut', function (e) {
        var deactivateArr = new Array();
        deactivateArr.push($(this).attr('fid'));
        objCustomers.deActivateCustomer(deactivateArr);
    });

    $(document).on('click', '#actAllBut', function (e) {
        objCustomers.activateAll();
    });
    //add today
    $(document).on('click', '#deactAllBut', function (e) {
        objCustomers.deactivateAll();
    });

    $(document).on('click', '#deactAllBut', function (e) {
        if ($(".selectCustomer:checked").length <= 0)
        {
            // $("#error_modal").find('.col-md-12').text("Please select any row.");
            // $("#error_modal").modal('show');
            setTimeout(function () {
                $("#error_modal").modal('hide');
            }, 1500)
        } else
        {
            var deactivateArr = new Array();
            $(".selectCustomer:checked").each(function (index, element) {
                deactivateArr.push($(this).attr('custnum'));
            });
            // console.log(deactivateArr);
            objCustomers.deActivateCustomer(deactivateArr);
        }//else ($(".checkRow:checked").length <= 0)
    });

    $(document).on('click', '.editBut', function (e) {
        objCustomers.editModal(this);
        objCustomers.checkForAdminLoginedit();
    });

    $(document).on('click', '#addNewCust', function (e) {
        $("#addCustomerModal").modal({'backdrop': 'static'});
        objCustomers.checkForAdminLogin();
    });

    $(document).on('click', '#refreshList', function (e) {
        objCustomers.fetchCustomers();
    });
    objCustomers.fetchCustomers();
});
function Customers() {}
Customers.prototype = {
    checkUncheckAllCustomers: function (ref) {
        var checked = $(ref).prop('checked');
        $(".selectCustomer").each(function () {
            $(this).prop('checked', checked);
        });
    },
    editCustomer: function () {
        $("#editcompany").prop('disabled', false);
        $("#editcompany").prop('selected', true);
        $("#editcompany").prop('readonly', false);
        var serialize = $("#editCustomerForm").serializeArray();
        var error = false;
        $.each(serialize, function (key, val) {
            //console.log(val);
            var check = false;
            if (val.name != 'editcustID')
            {
                if (val.name == 'editcustCashDisPer')
                {
                    if ($("#editcustPaymentTerms").val() == 'Cash Discount')
                    {
                        check = true;
                    }
                } else if (val.name == 'editcustUpChargePer')
                {
                    if ($(".editcustUpCharge:checked").val() == 'Yes')
                    {
                        check = true;
                    }
                } else
                {
                    check = true;
                }

                if (check)
                {
                    if ($.trim(val.value) == '')
                    {
                        error = true;
                        $("#" + val.name).parent().addClass('has-error');
                    } else
                    {
                        $("#" + val.name).parent().removeClass('has-error');
                    }
                } else
                {
                    $("#" + val.name).parent().removeClass('has-error');
                }
            }
        });


        if (!error)
        {
            // var btn = $(this);
            //  btn.button('loading');
            ajax(apiUrl + 'customer/update', 'post', $("#editCustomerForm").serialize()).then(function (response) {
                if (!response.status) {
                    swal({
                        title: "Error",
                        text: response.response.length ? response.response.join('\n') : response.message,
                        icon: "error",
                        button: "OK"
                    });
                    return;
                }
                swal({
                    title: "Success",
                    text: response.message,
                    icon: "success",
                    button: "OK"
                }).then(function () {
                    redirect(getUrl());
                });
            });
            var objCustomers = this;
              objCustomers.checkForAdminLoginedit();
        } else{
            var objCustomers = this;
            objCustomers.checkForAdminLoginedit();
        }
    },
    addCustomer: function () {
        $("#addcompany").prop('disabled', false);
        $("#addcompany").prop('selected', true);
        $("#addcompany").prop('readonly', false);
        var serialize = $("#addCustomerForm").serializeArray();
        var error = false;
        //console.log(serialize);
        $.each(serialize, function (key, val) {
//                    console.log('test',val);
            var check = false;
            if (val.name == 'addcustCashDisPer')
            {
                if ($("#addcustPaymentTerms").val() == 'Cash Discount')
                {
                    check = true;
                }
            } else if (val.name == 'addcustUpChargePer')
            {
                if ($(".addcustUpCharge:checked").val() == 'Yes')
                {
                    check = true;
                }
            } else
            {
                check = true;
            }

            if (check)
            {
                if ($.trim(val.value) == '')
                {
                    error = true;
                    $("#" + val.name).parent().addClass('has-error');
                } else
                {
                    $("#" + val.name).parent().removeClass('has-error');
                }
            } else
            {
                $("#" + val.name).parent().removeClass('has-error');
            }
        });
        
       
        if (!error)
        {
//                    var btn = $(this);
            // console.log(btn.button);
//                    btn.button('loading');
            ajax(apiUrl + 'customer/add', 'post', $("#addCustomerForm").serialize()).then(function (response) {
                if (!response.status) {
                    swal({
                        title: "Error",
                        text: response.response.length ? response.response.join('\n') : response.message,
                        icon: "error",
                        button: "OK"
                    });
                    return;
                }
                swal({
                    title: "Success",
                    text: response.message,
                    icon: "success",
                    button: "OK"
                }).then(function () {
                    redirect(getUrl());
                });
            });
            
            
              var objCustomers = this;
              objCustomers.checkForAdminLogin();
            
        }else{
            var objCustomers = this;
            objCustomers.checkForAdminLogin();
        }
    },
    editModal: function (ref) {
        var fid = $(ref).attr('fid');
        ajax(apiUrl + 'customer/read', 'get', {id: fid}).then(function (response) {
            if (!response.status) {
                swal({
                    title: "Error",
                    text: response.response.join('<br>'),
                    icon: "error",
                    button: "OK"
                });
                return;
            }

            var customer = response.response;
            $("#editcustID").val(customer.id);
            $("#editcustName").val(customer.custname);
            $("#editcustAddress").val(customer.custaddress);
            $("#editcustCity").val(customer.custcity);
            $("#editcustState").val(customer.custstate);
            $("#editcustZip").val(customer.custzip);
            $("#editcustContactName").val(customer.contact_name);
            $("#editcustContactPhone").val(customer.phone);
            $("#editcompany").find('option:selected').prop('selected', false);
            $("#editcompany").find('option').each(function (index, element) {

                var val = $(this).val();

                if (val == customer.company_id)
                {
                    $(this).prop('selected', "selected");
                }
            });

            $("#editcustPaymentTerms").find('option:selected').prop('selected', false);
            $("#editcustPaymentTerms").find('option').each(function (index, element) {
                var val = $(this).val();
                if (val == customer.payment_terms)
                {
                    $(this).prop('selected', 'selected');
                }
            });

            if (customer.payment_terms === 'Cash Discount')
            {
                $("#editCashDisPerDiv").show();
                $("#editcustCashDisPer").val(customer.cash_discount);
            } else
            {
                $("#editCashDisPerDiv").hide();
                $("#editcustCashDisPer").val('');
            }

            //alert(customer.cust_upcharge);
            if (customer.cust_upcharge == '1')
            {
                $(".editcustUpCharge[value=Yes]").prop('checked', true);
                $("#editUpChargePerDiv").show();
                $("#editcustUpChargePer").val(customer.cust_upcharge_amt);
            } else
            {
                $(".editcustUpCharge[value=No]").prop('checked', true);
                $("#editUpChargePerDiv").hide();
                $("#editcustUpChargePer").val('');
            }

            $("#editCustomerModal").modal({'backdrop': 'static'});
        });

    },
    addCustomerModal: function (ref) {
        //var fid = $(ref).attr('fid');
        ajax(apiUrl + 'customer/add', 'post').then(function (response) {
            if (!response.status) {
                swal({
                    title: "Error",
                    text: response.response.join('<br>'),
                    icon: "error",
                    button: "OK"
                });
                return;
            }
            var customer = response.response;
            $("#addcustName").val(customer.custname);
            $("#addcustAddress").val(customer.custaddress);
            $("#addcustCity").val(customer.custcity);
            $("#addcustState").val(customer.custstate);
            $("#addcustZip").val(customer.custzip);
            $("#addcustContactName").val(customer.contact_name);
            $("#addcustContactPhone").val(customer.phone);
            $("#addcompany").find('option:checked').prop('selected', false);
            $("#addcompany").find('option').each(function (index, element) {
                var val = $(this).val();
                if (val === customer.payment_terms)
                {
                   $(this).prop('selected', 'selected');
                }
            });

            $("#addcustPaymentTerms").find('option:checked').prop('selected', false);
            $("#addcustPaymentTerms").find('option').each(function (index, element) {
                var val = $(this).val();
                if (val === customer.payment_terms)
                {
                    $(this).prop('selected', 'selected');
                }
            });

            if (customer.payment_terms === 'Cash Discount')
            {
                $("#addCashDisPerDiv").show();
                $("#addcustCashDisPer").val(customer.cash_discount);
            } else
            {
                $("#addCashDisPerDiv").hide();
                $("#addcustCashDisPer").val('');
            }

            //alert(customer.cust_upcharge);
            if (customer.cust_upcharge === '1')
            {
                $(".addcustUpCharge[value=Yes]").prop('checked', true);
                $("#addUpChargePerDiv").show();
                $("#addcustUpChargePer").val(customer.cust_upcharge_amt);
            } else
            {
                $(".addcustUpCharge[value=No]").prop('checked', true);
                $("#addUpChargePerDiv").hide();
                $("#addcustUpChargePer").val('');
            }

            $("#addCustomerModal").modal({'backdrop': 'static'});
        });

    },
    activateAll: function () {
        var activateArr = [];
        $(".selectCustomer:checked").each(function () {
            activateArr.push($(this).attr('custnum'));
        });
        if (activateArr.length === 0) {
            swal({
                title: "Error",
                text: 'Please select any row',
                icon: "error",
                button: "OK"
            });
            return;
        }
        this.activateCustomer(activateArr);
    },
    //add today
    deactivateAll: function () {
        var deactivateArr = [];
        $(".selectCustomer:checked").each(function () {
            deactivateArr.push($(this).attr('custnum'));
        });
        if (deactivateArr.length === 0) {
            swal({
                title: "Error",
                text: 'Please select any row',
                icon: "error",
                button: "OK"
            });
            return;
        }
        this.deActivateCustomer(deactivateArr);
    },
    deActivateCustomer: function (deactivateArr) {

        ajax(apiUrl + 'customer/deactivate', 'post', {'customer[]': deactivateArr}).then(function (response) {
            swal({
                title: response.status ? "Success" : "Error",
                text: response.status ? response.message : response.response.join('\n'),
                icon: response.status ? "success" : "error",
                button: "OK"
            }).then(function () {
                if (response.status) {
                    redirect(getUrl());
                }
            });

        });

        return;
        $.ajax({
            type: 'post',
            url: 'backend.php',
            data: {'deactivateCustomer[]': deactivateArr},
            dataType: "json",
            beforeSend: function () {
                $("#loader").modal({'backdrop': 'static'});
            },
            success: function (html) {
                //alert(html);
                $("#loader").modal('hide');
                if (html.error)
                {
                    $("#error_modal").find('.col-md-12').html(html.msg);
                    $("#error_modal").modal('show');
                    setTimeout(function () {
                        $("#error_modal").modal('hide');
                    }, 1500)
                } else
                {
                    $("#status").html(html.msg);
                    $("#status").parents('.alert-success').show();
                    setTimeout(function () {
                        $("#status").parents('.alert-success').hide(200);
                    }, 1500);
                    //window.location.reload();

                    $.each(deactivateArr, function (key, val) {
                        $("#parentRow_" + val).addClass('success');
                        $("#parentRow_" + val).find('.deactBut, .reactBut').remove();
                        but = '<button class="btn btn-xs btn-success reactBut" fid="' + val + '" style="margin-top:5px;"><span class="glyphicon glyphicon-ok"></span>&nbsp;</button>';
                        $("#parentRow_" + val).find('td:last').append(but);
                    });
                }
            },
            error: function (a, b, c) {
                $("#loader").modal('hide');
                $("#error_modal").find('.col-md-12').text("Something went wrong. Please try again.");
                $("#error_modal").modal('show');
                setTimeout(function () {
                    $("#error_modal").modal('hide');
                }, 1500)
            }
        })
    },
    fetchCustomers: function () {
        $.ajax({
            type: 'post',
            url: 'backend.php',
            data: {'fetchCustomerDashboard': '1'},
            //dataType: "json",
            beforeSend: function () {
                $("#loader").modal({'backdrop': 'static'});
            },
            success: function (html) {
                //alert(html);
                $("#loader").modal('hide');
                $("#customerData").html(html);
            },
            error: function (a, b, c) {
                $("#loader").modal('hide');
                $("#error_modal").find('.col-md-12').text("Something went wrong. Please try again.");
                $("#error_modal").modal('show');
                setTimeout(function () {
                    $("#error_modal").modal('hide');
                }, 1500)
            }
        })

    },
    activateCustomer: function (activateArr) {
        ajax(apiUrl + 'customer/activate', 'post', {'customer[]': activateArr}).then(function (response) {
            swal({
                title: response.status ? "Success" : "Error",
                text: response.status ? response.message : response.response.join('\n'),
                icon: response.status ? "success" : "error",
                button: "OK"
            }).then(function () {
                if (response.status) {
                    redirect(getUrl());
                }
            });

        });


        return;
        $.ajax({
            type: 'post',
            url: 'backend.php',
            data: {'reactivateCustomer[]': activateArr},
            dataType: "json",
            beforeSend: function () {
                $("#loader").modal({'backdrop': 'static'});
            },
            success: function (html) {
                //alert(html);
                $("#loader").modal('hide');
                if (html.error)
                {
                    $("#error_modal").find('.col-md-12').html(html.msg);
                    $("#error_modal").modal('show');
                    setTimeout(function () {
                        $("#error_modal").modal('hide');
                    }, 1500)
                } else
                {
                    $("#status").html(html.msg);
                    $("#status").parents('.alert-success').show();
                    setTimeout(function () {
                        $("#status").parents('.alert-success').hide(200);
                    }, 1500);
                    $.each(activateArr, function (key, val) {
                        $("#parentRow_" + val).removeClass('success');
                        $("#parentRow_" + val).find('.reactBut, .deactBut').remove();
                        but = '<button class="btn btn-xs btn-danger deactBut" fid="' + val + '" style="margin-top:5px;"><span class="glyphicon glyphicon-remove"></span>&nbsp;</button>';
                        $("#parentRow_" + val).find('td:last').append(but);
                    });
                }
            },
            error: function (a, b, c) {
                $("#loader").modal('hide');
                $("#error_modal").find('.col-md-12').text("Something went wrong. Please try again.");
                $("#error_modal").modal('show');
                setTimeout(function () {
                    $("#error_modal").modal('hide');
                }, 1500)
            }
        })
    },
    checkForAdminLogin: function () {
        if($('input[name="checkstausofadmin"]').val()==0){
            $("#addcompany").prop('disabled', true);
            $("#addcompany").prop('selected', true);
            $("#addcompany").prop('readonly', true);
        }
    },
    
   checkForAdminLoginedit: function () {
        if($('input[name="checkstausofadmin"]').val()==0){
            $("#editcompany").prop('disabled', true);
            $("#editcompany").prop('selected', true);
            $("#editcompany").prop('readonly', true);
        }
    }
};