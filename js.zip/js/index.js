$(document).ready(function () {
    $("#forgotpassmodal").on("shown.bs.modal", function (e) {
        $('#forgotpasswordform').bootstrapValidator('resetForm', true);
    });
    $('#Login').bootstrapValidator({
        excluded: [':disabled'],
        message: 'This value is not valid',
        feedbackIcons: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
        fields: {
            username: {
                validators: {
                    notEmpty: {
                        message: 'Email is compulsory'
                    },
                    emailAddress: {
                        message: 'The value is not a valid email address'
                    }

                }
            },

            Password: {
                validators: {
                    notEmpty: {
                        message: 'Password is compulsory'
                    }
                }
            }
        },
        onSuccess: function (e) {
            e.preventDefault();
            var payload = {
                username: $('#username').val(),
                password: $('#Password').val()
            };
            ajax(apiUrl + 'login', 'post', payload).then(function (response) {
                if (!response.status) {
                    swal({
                        title: "Error",
                        text: response.message,
                        icon: "error",
                        button: "OK"
                    });
                    return;
                }
                var objUpdateCurrentWarehouse = new UpdateCurrentWarehouse();
                var warehouses = response.response.warehousedata;
                if (warehouses.length === 1) {
                    objUpdateCurrentWarehouse.update(warehouses[0].id);
                } else {
                    var modalSelectWarehouse = $('#select_warehouse');
                    modalSelectWarehouse.modal('show');
                    modalSelectWarehouse.find('select').html(generateDropdownHtml(arrayColumns(warehouses, ['id', 'name']), {index: 0, emptyIndex: 'Select Warehouse'}));
                }
            });
            return;
            $.ajax({
                url: apiUrl +'login',
                type: "POST",
                data: {
                    username: $('#username').val(),
                    password: $('#Password').val(),
                    action: 'login'
                },
                beforeSend: function () {
                    $('#loader').modal('show');
                },
                complete: function (xhr, textStatus) {
                    $('#loader').modal('hide');
                    var res = xhr.responseJSON;
                    if (xhr.status == 200) {
                        if (res['status'] == true) {
                            var warehouseelement = res['response']['warehousedata'];
                            len = warehouseelement.length;

//                             console.log("len = warehouseelement", res['response']['warehousedata']);
                            if (len == 1) {
                                Swal.fire({
                                    icon: 'success',
                                    text: "You Login in Warehouse " + res['response']['warehousedata'][0].name,
                                    showConfirmButton: false
                                }).then(() => {
                                    window.location.href = "dashboard.php";
                                });

                            } else {
                                whereHouseData = res['response']['warehousedata'];
                                var arr = [];
                                whereHouseData.map((data) => {
                                    arr[data.id] = data.name;
                                })

                                swal.fire({
                                    title: 'Select Your wharehouse',
                                    input: 'select',
                                    inputOptions: arr,
                                    inputPlaceholder: 'required',
                                    showCancelButton: true,
                                    inputValidator: function (value) {
                                        //console.log("value",value);
                                        return new Promise(function (resolve, reject) {

                                            if (value !== '') {
                                                resolve();
                                            } else {
                                                resolve('You need to select Wharehouse');
                                            }
                                        });
                                    }
                                }).then(function (result) {
                                    //console.log(result);
                                    if (result.value) {
                                        let payload = {
                                            "WHid": result.value,
                                            "action": 'setWarehouseInSession'
                                        };

                                        $.ajax({
                                            url: 'api/Warehouses/all',
                                            type: 'GET',
                                            data: {"WHid": result.value,
                                                "action": 'setWarehouseInSession'},
                                            complete: function (xhr, textStatus) {
                                                var res = xhr.responseJSON;
                                                swal.fire({
                                                    icon: 'success',
                                                    html: 'You selected Login: ' + res.message.name
                                                }).then(() => {
                                                    window.location.href = "dashboard.php";
                                                });
                                            }
                                        });
                                    }
                                });
                            }

                        }
                    } else {
                        swal({
                            title: "Error!",
                            text: res['message'],
                            icon: "error",
                            button: 'OK',
                        });
                    }
//                    $('#Login').bootstrapValidator('resetForm', true);
                }
            });
        }
    });
    $('#forgotpasswordform').bootstrapValidator({
        excluded: [':disabled'],
        message: 'This value is not valid',
        feedbackIcons: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
        fields: {
            email: {
                validators: {
                    notEmpty: {
                        message: 'Email is compulsory'
                    },
                    emailAddress: {
                        message: 'The value is not a valid email address'
                    }
                }
            }
        },
        onSuccess: function (e, data) {
            e.preventDefault();
            $.ajax({
                url: apiUrl+'forgot-password',
                type: "POST",
                data: {
                    username: $('#email').val()
                },
                beforeSend: function () {
                    $('#loader').modal('show');
                },
                complete: function (xhr, textStatus) {
                    $('#loader').modal('hide');
                    var res = xhr.responseJSON;
                    if (xhr.status == 200) {
                        if (res['status'] == true) {
                            swal({
                                title: "Email Sent!",
                                text: res['message'],
                                icon: "success",
                                button: 'OK',
                            });
                            $('#forgotpassmodal').modal('hide');
                        } else {
                            swal({
                                title: "Error!",
                                text: res['message'],
                                icon: "error",
                                button: 'OK',
                            });
                        }
                    } else {
                        swal({
                            title: "Error!",
                            text: res['message'],
                            icon: "error",
                            button: 'OK',
                        });
                    }
                    $('#forgotpasswordform').bootstrapValidator('resetForm', true);
                }
            });
        }
    });
    $(document).on('click', '#select_warehouse button.btn-primary', function () {
        (new UpdateCurrentWarehouse()).update($(this).parents('.modal').find('form select').val());
    });
});
//function Login1() {
//
//}
//Login1.prototype = {
//    updateWarehouse: function (warehouseId) {
//        return new Promise(function (resolve) {
//            var payload = {
//                warehouse_id: warehouseId
//            };
//            ajax(apiUrl + 'users/update-warehouse', 'post', payload).then(function (response) {
//                resolve(response);
//            });
//        });
//    },
//    setWarehouse: function (refernece) {
//        var thisObj = this;
//        var warehouseId = $(refernece).parents('.modal').find('form select').val();
//        this.updateWarehouse(warehouseId).then(function (response) {
//            thisObj.handleWarehouseUpdate(response);
//        });
//    },
//    handleWarehouseUpdate: function (response) {
//        if (!response.status) {
//            swal({
//                title: "Error",
//                text: response.message,
//                icon: "error",
//                button: "OK"
//            });
//            return;
//        }
//        redirect(baseUrl + 'dashboard');
//    }
//};