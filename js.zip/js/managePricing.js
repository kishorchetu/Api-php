// JavaScript Document
function isNumber(evt) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
        return false;
    }
    return true;
}

$(document).on('click', '.Choice', function (e) {
    var val = $(this).val();
    if (val == 1)
    {
        $("#labelfor").text('Copy from');
        $("#copyToDiv").show();
        $("#familyDiv").hide();
        $(".toCustomers").each(function () {
            $(this).prop('checked', false);
        });
    } else if (val == 2)
    {
        $("#labelfor").text('Copy from');
        $("#copyToDiv, #familyDiv").show();
        $(".toCustomers").each(function () {
            $(this).prop('checked', false);
        });
    } else if (val == 3)
    {
        $("#labelfor").text('Select Customer');
        $("#copyToDiv, #familyDiv").hide();
    }
});

$(document).on('change', '#fromCustomer', function (e) {
    $(".toCustomerslabel").show();
    var val = $(this).val();
    $("#checkbox_" + val).hide();
    $("#checkbox_" + val).prop('checked', false);
});

$(document).on('click', '#submit', function (e) {
    $("html, body").animate({scrollTop: 0}, "slow");

    var fromCustomer = $("#fromCustomer").val();
    if (fromCustomer == null)
    {
        $("#fromCustomer").parent('div').addClass('has-error');
        return false;
    } else
        $("#fromCustomer").parent('div').removeClass('has-error');

    var valSelected = $(".Choice:checked").val();
    if (valSelected == 1)
    {
        var toCustomers = new Array();
        $(".toCustomers").each(function (index, element) {
            var x = this.checked;
            if (x)
                toCustomers.push($(this).val());
        });

        if (toCustomers.length == 0)
        {
            var errormessage = 'Please select atleast one Customer to Copy';
            $("#error_modal").find('.col-md-12').text(errormessage);
            $("#error_modal").modal('show');
            setTimeout(function () {
                $("#error_modal").modal('hide');
            }, 1500)
            return false;
        }

        $.ajax({
            type: 'post',
            url: 'manage-pricing-backend.php',
            data: {'TotalCopy': '1', 'fromCustomer': fromCustomer, 'toCustomer[]': toCustomers},
            dataType: "json",
            beforeSend: function () {
                $("#loader").modal({'backdrop': 'static'});
            },
            success: function (html) {
                //alert(html);
                $("#loader").modal('hide');
                if (html.error)
                {
                    $("#error_modal").find('.col-md-12').text(html.msg);
                    $("#error_modal").modal('show');
                    setTimeout(function () {
                        $("#error_modal").modal('hide');
                    }, 4000);
                } else
                {
                    $("#status").html(html.msg);
                    $("#status").parents('.alert-success').show();
                    setTimeout(function () {
                        $("#status").parents('.alert-success').slideUp(200);
                    }, 2500);
                }
            },
            error: function (a, b, c) {
                $("#loader").modal('hide');
                $("#error_modal").find('.col-md-12').text("Something went wrong. Please try again.");
                $("#error_modal").modal('show');
                setTimeout(function () {
                    $("#error_modal").modal('hide');
                }, 1500)
            }
        })
    } else if (valSelected == 2)
    {
        var toCustomers = new Array();
        $(".toCustomers").each(function (index, element) {
            var x = this.checked;
            if (x)
                toCustomers.push($(this).val());
        });

        var selectFamily = $("#selectFamily").val();
        if (selectFamily == null)
        {
            $("#selectFamily").parent('div').addClass('has-error');
            return false;
        } else
            $("#selectFamily").parent('div').removeClass('has-error');

        if (toCustomers.length == 0)
        {
            var errormessage = 'Please select atleast one Customer to Copy';
            $("#error_modal").find('.col-md-12').text(errormessage);
            $("#error_modal").modal('show');
            setTimeout(function () {
                $("#error_modal").modal('hide');
            }, 1500)
            return false;
        }

        $.ajax({
            type: 'post',
            url: 'manage-pricing-backend.php',
            data: {'FamilyCopy': '1', 'family': selectFamily, 'fromCustomer': fromCustomer, 'toCustomer[]': toCustomers},
            dataType: "json",
            beforeSend: function () {
                $("#loader").modal({'backdrop': 'static'});
            },
            success: function (html) {
                //alert(html);
                $("#loader").modal('hide');
                if (html.error)
                {
                    $("#error_modal").find('.col-md-12').text(html.msg);
                    $("#error_modal").modal('show');
                    setTimeout(function () {
                        $("#error_modal").modal('hide');
                    }, 4000);
                } else
                {
                    $("#status").html(html.msg);
                    $("#status").parents('.alert-success').show();
                    setTimeout(function () {
                        $("#status").parents('.alert-success').hide(200);
                    }, 2500);
                }
            },
            error: function (a, b, c) {
                $("#loader").modal('hide');
                $("#error_modal").find('.col-md-12').text("Something went wrong. Please try again.");
                $("#error_modal").modal('show');
                setTimeout(function () {
                    $("#error_modal").modal('hide');
                }, 1500)
            }
        })
    } else if (valSelected == 3)
    {
        popup1 = window.open("CustomerPriceNew.php?customer=" + fromCustomer, "_blank", "toolbar=yes, scrollbars=yes, resizable=yes, top=500, left=500, width=400, height=400");
        popup1.focus();
    }
});
