/// some script

// jquery ready start
$(document).ready(function () {
    // jQuery code
    //////////////////////// Prevent closing from click inside dropdown
    $(document).on('click', '.dropdown-menu', function (e) {
        e.stopPropagation();
    });

    // make it as accordion for smaller screens
    if ($(window).width() < 992) {
        $('.dropdown-menu a').click(function (e) {
            e.preventDefault();
            if ($(this).next('.submenu').length) {
                $(this).next('.submenu').toggle();
            }
            $('.dropdown').on('hide.bs.dropdown', function () {
                $(this).find('.submenu').hide();
            });
        });
    }
    $(document).on('change', '#update_current_warehouse', function () {
        (new UpdateCurrentWarehouse()).update($(this).val(), getUrl());
    });
    $(document).on('click', '#top-link', function (e) {
        e.preventDefault();
        $('html, body').animate({scrollTop: 0}, '300');
    });


});
window.addEventListener('scroll', showScriollToTop);
function showScriollToTop() {
    if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
        $('#top-link').addClass("show");
    } else {
        $('#top-link').removeClass("show");
    }
}
function isNumber(evt) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
        return false;
    }
    return true;
}
function getRecordId(reference) {
    return $(reference).parents('tr').attr('data-id');
}
function getValue(obj, key, defaultValue = '')
{
    var keys = key.split('.').map(function (i)
    {
        return i.trim();
    });
    for (key in keys) {
        if (typeof obj[keys[key]] === 'undefined') {
            return defaultValue;
        }
        obj = obj[keys[key]];
    }
    return obj;
}

function capitalizeEachWord(string, separator = ' ')
{
    var ufFirst = function (word)
    {
        if (!word.length) {
            return word;
        }
        word = word.toLowerCase();
        return word.charAt(0).toUpperCase() + word.slice(1);
    };
    return string.split(separator).map(function (i)
    {
        return ufFirst(i);
    }).join(separator);
}

function ajax(url, method = 'get', data = null, loaderSelector = null)
{
    return new Promise(function (resolve)
    {
        var param = {
            url: url,
            method: method.toUpperCase(),
            async: true,
            cache: false,
            crossDomain: true,
            beforeSend: function ()
            {
                (new Loader()).show(loaderSelector);
            }
        };
        if (data !== null) {
            param['data'] = data;
        }
        $.ajax(param).always(function (a, b, c)
        {
            (new Loader()).hide(loaderSelector);
            var response = b === 'error' ? a : c;
            var refined = typeof response.responseJSON === 'undefined' ? response : response.responseJSON;
            resolve(refined);
        });
    });
}
function Loader() {
    this.enabled = true;
    this.selectorLoaderDefault = $('#loader');
}
Loader.prototype = {
    show: function (selector, config) {
        if (!this.enabled) {
            return;
        }
        this.selector = selector ? $(selector) : this.selectorLoaderDefault;
        switch (valuePick(config, 'type').toLowerCase()) {
            case 'c':
                this.showChild();
                break;
            case 's':
                this.showSibling();
                break;
            default:
                this.showDefault();
        }
    },
    hide: function (selector, config) {
        if (!this.enabled) {
            return;
        }
        this.selector = selector ? $(selector) : this.selectorLoaderDefault;
        switch (valuePick(config, 'type').toLowerCase()) {
            case 'c':
                this.hideChild();
                break;
            case 's':
                this.hideSibling();
                break;
            default:
                this.hideDefault();
        }
    },
    showDefault: function () {
        var dataCount = parseInt(this.selector.attr('data-count'));
        dataCount += 1;
        this.selector.attr('data-count', dataCount);
        if (dataCount > 1) {
            return;
        }
        this.selector.modal('show');
    },
    showChild: function () {},
    showSibling: function () {},

    hideDefault: function () {
        var dataCount = parseInt(this.selector.attr('data-count'));
        dataCount -= 1;
        this.selector.attr('data-count', dataCount);
        if (dataCount > 0) {
            return;
        }
        this.selector.modal('hide');
    },
    hideChild: function () {},
    hideSibling: function () {},
};
function getUrl() {
    let url = '';
    try {
        url = top.location.href;
    } catch (e) {
        url = window.location.href;
    } finally {
        return url;
    }
}
function generateDropdownHtml(data, config = {}){
//    config = {value: '', text: '', index: 0, emptyIndex: 'Select Industry', addNew: false};
    var html = '';
    if (valuePick(config.addNew) === true) {
        data.unshift(['add-new', 'Add New']);
    }
    if (isSet(config.emptyIndex)) {

        data.unshift(['', config.emptyIndex]);
    }
    var selected = '';

    var configIndex = valuePick(config.index, []);
    configIndex = Array.isArray(configIndex) ? configIndex : [configIndex];

    var configValue = valuePick(config.value, []);
    configValue = Array.isArray(configValue) ? configValue : [configValue];
    var configText = valuePick(config.text, []);
    configText = Array.isArray(configText) ? configText : [configText];
    $.each(data, function (index, option) {
//        if (index === valuePick(config.index) || (option[0] && option[0] === valuePick(config.value)) || (option[1] && option[1] === valuePick(config.text))) {
        if (configIndex.indexOf(index) > -1 || (option[0] && configValue.indexOf(option[0]) > -1) || (option[1] && configText.indexOf(option[1]) > -1)) {
            selected = 'selected ';
        } else {
            selected = '';
        }
        html += `<option ${selected}value="${option[0]}">${valuePick(option[1], option[0])}</option>`;
    });
    return html;

}
function arrayColumns(data, columns = [], preserveKeys = false) {
    var trimmedData = [];
    var dataSet = null;
    $.each(data, function (index, value) {
        if (preserveKeys) {
            dataSet = {};
            $.each(columns, function (i2, column) {
                dataSet[column] = valuePick(value[column]);
            });
        } else {
            dataSet = [];
            $.each(columns, function (i2, column) {
                dataSet.push(valuePick(value[column]));
            });
        }
        trimmedData.push(dataSet);
    });
    return trimmedData;
}
function isSet(varName) {
    return typeof varName !== 'undefined';
}
function valuePick(varName, defaultVal = '') {
    return isSet(varName) ? varName : defaultVal;
}
function redirect(url, newTab = false) {
    window.location.href = url;
}

function UpdateCurrentWarehouse() {}
UpdateCurrentWarehouse.prototype = {
    update: function (warehouseId, redirectUrl = '') {
        var payload = {
            warehouse_id: warehouseId
        };
        var thisObj = this;
        ajax(apiUrl + 'users/update-warehouse', 'post', payload).then(function (response) {
            thisObj.handleWarehouseUpdate(response, redirectUrl);
        });
    },
    handleWarehouseUpdate: function (response, redirectUrl = '') {
        if (!response.status) {
            swal({
                title: "Error",
                text: response.message,
                icon: "error",
                button: "OK"
            });
            return;
        }
        redirect(redirectUrl ? redirectUrl : baseUrl + 'dashboard');
    }
};

function initializeDropdown(){
    $('.basic-dropdown').select2();
}

