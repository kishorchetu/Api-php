$(document).ready(function () {
    $('#resetpasswordform').bootstrapValidator({
        feedbackIcons: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
        fields: {
            newPass: {
                validators: {
                    notEmpty: {
                        message: 'Password is compulsory'
                    },
                    identical: {
                        field: 'confirmPass',
                        message: 'The password and its confirm are not the same'
                    }
                }
            },
            confirmPass: {
                validators: {
                    notEmpty: {
                        message: 'Password is compulsory'
                    },
                    identical: {
                        field: 'newPass',
                        message: 'The password and its confirm are not the same'
                    }
                }
            }
        },
        onSuccess: function (e, data) {
            e.preventDefault();
            if (!$('#passhashcode').val()) {
                swal({
                    title: "Error!",
                    text: 'Unauthenticate attempt for password reset',
                    icon: "error",
                    button: 'OK'
                });
            } else {
                $.ajax({
                    url: apiUrl + 'reset-password',
                    type: "POST",
                    data: {
                        newpassword: $('#newPass').val(),
                        passhashcode: $('#passhashcode').val()
                    },
                    complete: function (xhr, textStatus) {
                        var res = xhr.responseJSON;
                        if (xhr.status == 200) {
                            if (res['status'] == true) {
                                swal({title: "Reset Successfull!",
                                    text: res['message'],
                                    icon: "success",
                                    button: 'OK'
                                }).then(function () {
                                    window.location.href = res['response']['redirect_url'];
                                }
                                );
                            } else {
                                swal({
                                    title: "Error!",
                                    text: res['message'],
                                    icon: "error",
                                    button: 'OK'
                                });
                            }
                        } else {
                            swal({
                                title: "Error!",
                                text: res['message'],
                                icon: "error",
                                button: 'OK'
                            });
                        }
                        $('#resetpasswordform').bootstrapValidator('resetForm', true);
                    }
                });
            }
        }
    });
});