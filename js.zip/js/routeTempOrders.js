$(document).ready(function () {
    var objInventoryOrders = new RouteTempOrders();
    $(document).on('click', '#temp', function () {
        objInventoryOrders.loadTable();
    });
    $(document).on('click', '.actionCol button', function () {
        objInventoryOrders.editOrder(this);
    });
    
    $(document).on('click', '.refreshtemp.temp', function () {
        objInventoryOrders.reloadTable();
    });

});
function RouteTempOrders() {
    this.refreshSelectors();
}
RouteTempOrders.prototype = {
    refreshSelectors: function () {
        this.selectorTable = $('#tempordertable');
        this.selectorLoaderDefault = $('#loader');
    },
    loadTable: function () {
        this.refreshSelectors();
        if (isSet(window.inventoryOrdersTable)) {
            this.reloadTable();
            return;
        }
        window.inventoryOrdersTable = this.selectorTable.DataTable({
            "ajax": {
                "url": apiUrl + 'process-inventory-orders/orders',
                "type": "GET",
                "dataSrc": function (response) {
                    if (!response.status) {
                        return [];
                    }
                    return response.response;
                }
            },
            "columns": [
                {"data": "vendorname"},
                {"data": "orderdate"},
                {"data": "custtotal"},
                {"data": "whtotal"},
                {
                    class: 'textAligCenter actionCol',
                    mRender: function (data, type, full)
                    {
                        return `<center>
                                    <button class="btn btn-warning btn-xs edit">
                                       <i class="glyphicon glyphicon-edit"></i>
                                        Edit Order
                                    </button>
                                </center>`;
                    }
                }
            ],
            createdRow: function (row, data, index) {
                $(row).attr('data-id', data.order_id);
            }
        });
    },
    reloadTable: function () {
        this.selectorTable.DataTable().ajax.reload();
    },
    editOrder: function (reference){
        var orderId = parseInt(getRecordId(reference));
        var win = window.open(baseUrl+'order-form.php?orderId='+orderId, '_blank');
        if (win) {
            win.focus();
        } 
    }
};



