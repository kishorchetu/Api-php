$(document).ready(function () {
    $(document).on('change', '.checkbox input[type="checkbox"]', function () {
        (new HandlePermissionChange()).handle(this);
    });

    $('.dropdown-submenu a.test').on("click", function (e) {
        $(this).next('ul').toggle();
        e.stopPropagation();
        e.preventDefault();
    });

    $('#add-role').click(function () {
        $.ajax({
            url: apiUrl + '/api/role',
            type: "POST",
            data: {
                role: $('#role').val(),
                action: 'add'
            },
            success: function (res) {
                if (res['status'] == true && res['response']['reqstatus'] == 'success') {
                    window.location.href = res['response']['redirect_url'];
                }
            }
        });
    });

    $('#update-role').click(function () {
        $.ajax({
            url: apiUrl + '/api/role',
            type: "POST",
            data: {
                role: $('#role').val(),
                role_id: $('#role-id').val(),
                action: 'edit'
            },
            success: function (res) {
                if (res['status'] == true && res['response']['reqstatus'] == 'success') {
                    window.location.href = res['response']['redirect_url'];
                }
            }
        });
    });

    $(".role_delete").click(function () {
        var con = confirm("Are you sure to delete?");
        if (con) {
            var id = $(this).attr("data-id");
            $.ajax({
                url: apiUrl + '/api/role',
                type: 'POST',
                data: {
                    delete_role_id: id,
                    action: 'delete'
                },
                success: function (response) {
                    if (response) {
                        // alert("Role is deleted successfully.");
                        location.reload(true);
                    }
                },
            });
        }
    });

    // side navigation
    $(".custom-nav > li").click(function () {
        $(this).toggleClass("view");
    });

// custom accordion


    $("ul.tree_level > li").click(function () {
        $(this).toggleClass("view");
    });

    $("ul.sub_level_1 > li").click(function () {
        $(this).toggleClass("view");
    });

    $("#save-permission").click(function () {
        var role = $('#select-role').val();
        if ($("#select-role").val() === "") {
            // alert('Please select Role');
            swal({
                title: "Please select Role!",
                text: "Please Select Roles",
                icon: "error",
                button: 'OK',
            });
        }

        var permissions = [];
        $.each($("input[name='permission']:checked"), function () {
            permissions.push($(this).val());
        });
        var section = [];
        $.each($("input[name='sectionname']:checked"), function () {
            section.push($(this).val());
        });
        //console.log(section);

        if (permissions.length === 0) {
            swal({
                title: "Please select Permission!",
                text: "Please Select Permission",
                icon: "error",
                button: 'OK',
            });
        }
//      console.log(permissions.join(','));
//        return;
        $.ajax({
            url: apiUrl + "roles/update-permissions",
            type: 'POST',
            data: {
                role_id: role,
                permissions: permissions.join(','),
                sections: section.join(','),
                action: 'permissions'
            },
            success: function (response) {
                if (response) {
                    swal({
                        title: "updated successfully!",
                        text: response['message'],
                        icon: "success",
                        button: "Ok!",
                    }).then(() => {
                        if (response.status) {
                            location.href = 'userRolePermission'
                        }
                    });
                }
            },

        });
    });
});

function HandlePermissionChange() {

}
HandlePermissionChange.prototype = {
    handle: function (reference) {
        this.reference = $(reference);
        this.currentlyChecked = this.reference.prop('checked');
        if (this.currentlyChecked) {
            this.checkAllParents();
        } else {
//            if (this.reference.hasClass('wow')) {
//                this.uncheckAllParentsForSection();
//            }

            this.uncheckAllChilds();
            this.uncheckAllParents();
        }
    },
    checkAllParents: function () {
        var current = this.reference;
        do {
            current = current.closest('ul').prev().find('input[type="checkbox"]');
            current.prop('checked', true);
        } while (current.closest('ul').length > 0 && current.closest('ul').attr('class').length === 0);
    },
    uncheckAllChilds: function () {
        var getChildren = function (reference) {
            return new Promise(function (resolve) {
                var child = $(reference).closest('li').next();
                if (child.prop('tagName') !== 'UL') {
                    return;
                }
                child = child.find('input[type="checkbox"]');
                if (child.length === 0) {
                    return;
                }
                resolve(child);
            });
        };
        var uncheckChildren = function (children) {
            if (children === null) {
                return;
            }
            children.each(function () {
                $(this).prop('checked', false);
                getChildren($(this));
            });
        };
         var current = this.reference;
        if (current.closest('li').children().find('ul').find('input[type="checkbox"]:checked').hasClass('wow')) {
            current.closest('li').children().find('ul').find('input[type="checkbox"]:checked').prop('checked', false);
        }
        getChildren(current).then(function (children) {
            uncheckChildren(children);
        });

    },
    uncheckAllParents: function () {
        var getParents = function (reference) {
            return new Promise(function (resolve) {
                var parent = $(reference).parents('ul').prev();
                if (parent.prop('tagName') !== 'LI') {
                    return;
                }
                parent = parent.find('input[type="checkbox"]');
                if (parent.length === 0) {
                    return;
                }
                resolve(parent);
            });
        };
        var uncheckParents = function (parent) {
            if (parent === null) {
                return;
            }
            $(parent.get().reverse()).each(function () {
                var checkedChilderen = $(this).closest('li').next().find('input[type="checkbox"]:checked');
                if (checkedChilderen.length === 0) {
                    $(this).prop('checked', false);
                }
                getParents($(this));
            });
        };
        var current = this.reference;
        if (this.reference.hasClass('wow')) {
//           var sectionparent = current.closest('ul').parent().find('input[name="permission"][type="checkbox"]').prop('checked', true);
            var sectionparent = current.closest('ul').closest('li').find('input[type="checkbox"]:checked');
            if ((sectionparent.length - 1) === 0) {
                current = current.closest('ul').parent().find('input[name="permission"][type="checkbox"]');
                current.prop('checked', false);
            }
        }
        getParents(current).then(function (parent) {
            uncheckParents(parent);
        });
    }
};

//call function on change userRolePermission.php select dropdown Role
function updatePermission(val) {
    $.ajax({
        url: apiUrl + "roles/permissions",
        type: "GET",
        data: {role_id: val},

        success: function (res) {
            $("input").prop('checked', false);
            console.log(res.response.permitted);
            $.each(res.response.permitted, function (k, v) {
                $("input[name='permission'][value='" + v.id + "']").prop('checked', true);
                // $("input[value='" + v.parent + "']").prop('checked', true);        
            });
            //add new for section
            $.each(res.response.sectionpermitted, function (sk, sv) {
                $("input[name='sectionname'][value='" + sv.id + "']").prop('checked', true);

            });
        },
        error: function (err) {
            console.log(err);
        }
    });
}


 