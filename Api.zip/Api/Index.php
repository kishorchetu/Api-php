<?php
require_once base_path('Api/functions_api.php');
$className = getClassRelatedToUrl('');
$classObj = new $className();
$classObj->index();
sendApiResponse($classObj);
