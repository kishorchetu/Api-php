<?php

namespace Libraries\OrderForms;

defined('BASEPATH') || die('No direct script access allowed');

use Abstracted\Api;

class UpdateTemproryOrderForm extends Api {

    private $clean_extra_data;
    private $clean_data;
    private $order_Id;

    function __construct() {
        parent::__construct();
    }

    function index() {
        $this->requestType = $this->requestTypePost;
        if (!$this->validateRequestType()) {
            return;
        }
        $this->clean_extra_data = json_decode(str_replace("\\", "", value_post('extraData')), true);
        $this->clean_data = json_decode(str_replace("\\", "", value_post('data')), true);
        $warehouse_id = value_session('warehouses')['selected']['id'];
        $this->order_Id = value_post('order_id');

        if (count($this->clean_extra_data) <= 0 || count($this->clean_data) <= 0 || empty($this->order_Id)) {
            $this->message = 'Data Cannot be Empty';
            $this->statusCode = 403;
            return;
        }

        if (!$this->checkStatusofOrder($this->order_Id)) {
            $this->message = 'Order alreday been processed';
            $this->statusCode = 403;
            return;
        }
        
        $resultid = $this->updateTempInventoryOrder($this->clean_extra_data, $this->clean_data, $this->order_Id);
        if ($resultid === false) {
            $this->message = 'Someting went wrong to save order';
            $this->statusCode = 403;
            return;
        }
        
        $info = $this->responceTempOrders();
        $message = $this->sendMailUpdateOrder($this->clean_extra_data, $this->clean_data, $info);
        if ($message != true) {
            $this->message = 'Mail Failed For Updated Order';
            $this->statusCode = 403;
            return;
        }
        $this->response = [
            'title' => "Tempororry Order Updated",
            'response' => value_pick($info, 'confirm_order_info')
        ];
        return;
    }

    private function checkStatusofOrder($order_Id) {
        return dbGetCell(dbGetConnection()->where('id', $order_Id)->where('created_at', NULL, 'IS NOT')->where('commit_at', NULL, 'is')->get('temporory_orders', 1, 'id'));
    }

    private function updateTempInventoryOrder($clean_extra_data, $clean_data, $order_Id) {

        $custp = $whp = 0;
        foreach ($clean_data as $id => $price) {
            $custp += ($clean_data[$id]['custprice'] * $clean_data[$id]['qty']);
            $whp += ($clean_data[$id]['WHPrice'] * $clean_data[$id]['qty']);
        }

        $orders = array(
            'extraData' => $clean_extra_data,
            'data' => $clean_data,
            'customer_id' => $clean_extra_data['customer'],
            'warehouse_id' => value_session('warehouses')['selected']['id'],
            'total_customer_price' => number_format($custp, 2),
            'total_warehouse_price' => number_format($whp, 2)
        );

        $data = array(
            'warehouse_id' => value_session('warehouses')['selected']['id'],
            'orderinfo' => json_encode($orders),
            'created_at' => date("Y-m-d H:i:s", time())
        );
        return dbGetConnection()
                ->where('id', $order_Id)
                ->update('temporory_orders', $data);
    }

    private function responceTempOrders() {

        $customerId = $this->clean_extra_data['customer'];
        $comment = clean($this->clean_extra_data['comment']);

        $emailSubject = "Order Saved in Queue";

        $ownerInfo = $this->getOwnerOfCustomer($customerId);
        $ownerId = $ownerInfo['owner_id'];
        $emailTo = $ownerInfo['email'];
        $emailFrom = $ownerInfo['email'];

        $confirm_order_info = '';
        $message = "ordered by: " . $emailTo . "\n";
        $message .= "***Comment*** " . $comment . " ***Comment*** \n";

        $total = 0;
        $tqty = 0;

        $ids = '';

        foreach ($this->clean_data as $id => $price) {
            if ($price['qty'] > 0) {
                $ids .= "flavor.id=$id OR ";
            }
        }

        $ids = rtrim($ids, "OR ");

        $results = $this->selectFlavorsFamily($ids);

        if (count($results)) {

            $subTot = 0;
            $invSubTot = 0;
            $x = 1;
            $subQty = 0;
            $ofam = "";
            foreach ($results as $key => $row) {

                if ($ofam == "") {
                    $ofam = $row['pfamily'];
                    $prod = $row['productname'];
                } elseif ($ofam !== $row['pfamily']) {

                    if ($subTot > 0) {
                        $subMess = "Subtotal for " . $prod . " section is $" . number_format($subTot, 2) . " for " . $subQty . " units \n";
                        $qtyMess = "Subtotal is " . $subQty . " cases\n";

                        $message = $message . $subMess;
                        $confirm_order_info .= $subMess;
                    }

                    $total = $total + $subTot;
                    $subTot = 0;
                    $subQty = 0;
                    $ofam = $row['pfamily'];
                    $x = 1;
                    $prod = $row['productname'];
                }

                $pfamily = $row['pfamily'];
                $model = $row['model'];
                $desc = $row['description'];
                $id = $row['id'];
                $custPrice = $this->clean_data[$id]['custprice'];
                $cost = $this->clean_data[$id]['saleprice'];
                $whCost = $this->clean_data[$id]['WHPrice'];


                if ($customerId == 57 || $customerId == 58) {
                    $whCost = number_format(($whCost * .95), 2);
                    $cost = number_format($whCost, 2);
                }
                $str = "quantity";
                $qty = $this->clean_data[$id]['qty'];

                $invSubTot = $invSubTot + ($cost * $qty);

                if ($x == 1) {
                    $message = $message . " \n" . $prod . "\n";
                }

                $lineTot = $qty * $whCost;

                $out = " " . $desc . " quantity ordered=" . $qty . " @$" . number_format($whCost, 2) . "=$" . number_format($lineTot, 2) . "\n";
                $confirm_order_info .= $out;
                $subQty = $subQty + $qty;
                $specialId = substr($model, -4);
                $whOut = "    " . $qty . "cs        " . $specialId . "    " . $desc . " ";

                $message = $message . $out;



                $subTot = $subTot + $lineTot;
                $tqty = $tqty + $qty;

                $x++;
            }

            if ($subTot > 0) {
                $subMess = "Subtotal for " . $prod . " section is $" . number_format($subTot, 2) . " for " . $subQty . " units \n";
                $qtyMess = "Subtotal is " . $subQty . " cases\n";

                $message = $message . $subMess;
                $confirm_order_info .= $subMess;
            }

            $total = $total + $subTot;
            $subTot = 0;
        }

        $data_credit = $this->clean_extra_data['ccredit'];
        if ($data_credit == "") {
            $data_credit = 0;
        }
        $confirm_order_info .= "\n\nTotal Quantity of cases ordered is " . $tqty . "\n";
        $confirm_order_info .= "Warehouse Charge for Order is $" . number_format($total, 2) . "\n";
        $confirm_order_info .= "Credit for order is $" . ($data_credit) . "\n";
        $confirm_order_info .= "Total (Customer Price - Credit) for Order is $" . number_format(($invSubTot - $data_credit), 2) . "\n";

        $emailData = array();



        if ($customerId == 57 || $customerId == 58) {
            $emailFrom = "Expired-Damaged.Orders@GreenlandDairy.com";
            $CC = "steven.tarantola@gmail.com, richmangino@gmail.com, jthaci@gmail.com, jetmirjata@gmail.com, AA.royale@gmail.com, greenland.dairy@gmail.com, jjrojaso24@me.com";
            $emailData['from'] = $emailFrom;
            $emailData['reply_to'] = $emailFrom;
            $emailData['email_cc'] = $CC;
            $emailTo = $this->attachPartnerEmailAddress(); // as per recommended for companies in application
        } else {
            $emailFrom = "Orders@GreenlandDairy.com";
            $CC = "steven.tarantola@gmail.com";
            $emailData['from'] = $emailFrom;
            $emailData['reply_to'] = $emailFrom;
            $emailData['email_cc'] = $CC;
            $emailTo = $this->attachUserEmailAddress($ownerId, $emailTo);
        }

        $emailData['email_to'] = $emailTo;
        $emailData['emailSubject'] = $emailSubject;
        $emailData['message'] = $message;
        $emailData['confirm_order_info'] = $confirm_order_info;

        return $emailData;
    }

    private function attachUserEmailAddress($q, $email) {
        $user_email = "";
        $query = "select email from user where owner_id=?";
        $results = dbGetResultArray(dbGetConnection()->rawQuery($query, [$q]));
        if ($results === false) {
            return;
        }
        if (count($results) > 0) {
            foreach ($results as $mail) {
                $user_email .= $mail . ",";
            }
        }

        $user_email .= $email;
        return $user_email;
    }

    private function selectFlavorsFamily($ids) {

        $sql_single = "Select flavor.pfamily, flavor.model, flavor.description, flavor.id, flavor.price, products.family, products.productname from flavor INNER JOIN products on flavor.pfamily=products.family where ($ids) Order By flavor.pfamily, flavor.priority asc";

        $result = dbGetResultArray(dbGetConnection()->rawQuery($sql_single));
        if ($result === false) {
            return;
        }
        return $result;
    }

    private function getOwnerOfCustomer($customerId) {
        $sql = 'Select * from customer as t1 join owner as t2 on t1.owner_id=t2.id where t1.id=?';
        $result = dbGetRow(dbGetConnection()->rawQuery($sql, [$customerId]));
        if ($result === false) {
            return;
        }

        return $result;
    }

    private function attachPartnerEmailAddress() {
        $user_email = "";
        $query = "SELECT t1.email as email FROM `owner` as t1 WHERE t1.`partner`=?";
        $results = dbGetResultArray(dbGetConnection()->rawQuery($query, [1]));
        if ($results === false) {
            return;
        }
        if (count($results) > 0) {
            foreach ($results as $mail) {
                $user_email .= $mail . ",";
            }
        }
        return $user_email;
    }

    private function sendMailUpdateOrder($clean_extra_data, $clean_data, $mailInfo, $orderNumber = NULL) {

        $ids = '';
        foreach ($clean_data as $id => $price) {
            if ($price['qty'] > 0) {
                $ids .= "flavor.id=$id OR ";
            }
        }
        $ids = rtrim($ids, "OR ");
        $results = $this->selectFlavorsFamily($ids);
        $customerId = $clean_extra_data['customer'];
        $customerInfo = dbGetRow(dbGetConnection()->where('id', $customerId)->get('customer', 1));
        if ($customerInfo === false) {
            $this->message = 'Invaild Customer Selection';
            $this->statusCode = 403;
            return;
        }
        
        $message = view('formats.order_email_template', ['customerInfo' => $customerInfo,'clean_extra_data' => $clean_extra_data, 'productsInfo' => $results, 'clean_data' => $clean_data, 'customerId' => $customerId, 'orderNumber' => $orderNumber]);
        $emailData = array();
        $emailData['from'] = value_pick($mailInfo, 'from');
        $emailData['reply_to']= value_pick($mailInfo, 'reply_to');//not working
        $emailData['email_cc']= value_pick($mailInfo, 'email_cc');
        $emailData['email_to']= value_pick($mailInfo, 'emailTo');
//        $emailData['email_to'] = 'mayurg@chetu.com';
        $emailData['subject'] = value_pick($mailInfo, 'emailSubject');
        $emailData['body'] = $message;
//        return $message = sendingMail($emailData);
    }

}
