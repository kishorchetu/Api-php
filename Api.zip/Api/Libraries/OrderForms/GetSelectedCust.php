<?php

namespace Libraries\OrderForms;

defined('BASEPATH') || die('No direct script access allowed');

use Abstracted\Api;

class GetSelectedCust extends Api {

    private $errors = [];
    private $customer_id;

    function __construct() {
        parent::__construct();
    }

    function index() {

        $this->requestType = $this->requestTypeGet;
        if (!$this->validateRequestType()) {
            return;
        }
        $this->customer_id = value_get('customerId');
        $order = $this->getCustomerDetails($this->customer_id);

        $this->response = [
            'companyinfo' => value_pick($order, 'companyinfo'),
            'customerinfo' => value_pick($order, 'customerinfo')
        ];
    }

    private function getCustomerDetails($customer_id) {
        $responceArray = [];
        $responceArray['companyinfo'] = dbGetConnection()->join("customer c", "c.owner_id=o.id", "Inner")->where('c.id', $customer_id)->get('owner o', null, 'c.owner_id,c.manager , o.o_company as company');
        $responceArray['customerinfo'] = dbGetResultArray(dbGetConnection()->where('id', $customer_id)->get('customer'));
        if(!empty($responceArray['companyinfo']) || $responceArray['customerinfo']){
          
          return $responceArray;
                
        }
        
        $this->message = 'No records found in company and customer';
          $this->statusCode = 403;
          return; 
        
    }

}

?>