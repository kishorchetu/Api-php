<?php

namespace Libraries\OrderForms;

defined('BASEPATH') || die('No direct script access allowed');

use Abstracted\Api;

class LoadPartners extends Api {

    private $owner_id;

    function __construct() {
        parent::__construct();
    }

    function index() {
        $this->requestType = $this->requestTypeGet;
        if (!$this->validateRequestType()) {
            return;
        }
        $this->owner_id = value_get('ownerId');
        if($this->owner_id){
            
            $query='SELECT `owner_id`,`manager`,o_company as company,count(*) occurrences FROM `customer` as t1 join owner as t2 on t1.owner_id=t2.id GROUP BY `owner_id`';
            $info = dbGetResultArray(dbGetConnection()->rawQuery($query));

            if ($info === false) {
                $this->message = 'You are not authorized to access !!!';
                $this->statusCode = 403;
                return;
            }
            foreach ($info as $key => $value) {
                if($this->owner_id == $value['owner_id']){
                    $data[]=array(
                       'owner_id' => $value['owner_id'],
                        'manager' => $value['manager'],
                        'company' => $value['company']
                    );
                }
            }
            if(isset($data)){
                
                if(checkPermissionForSection('Show ALL Company')){
                    $this->response =$info;
                    return; 
                }
                else{
                    $this->response =$data;
                    return;
                }
            }
            else{
                $this->response =$info;
                return;
            }
            
            
        }else {
            $this->statusCode = 400;
            $this->message = "Your request is not process";
            return;
        }
        
        
        
    }
}
    
?>