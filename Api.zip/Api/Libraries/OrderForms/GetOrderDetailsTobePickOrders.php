<?php

namespace Libraries\OrderForms;

defined('BASEPATH') || die('No direct script access allowed');

use Abstracted\Api;

class GetOrderDetailsTobePickOrders extends Api {

    private $errors = [];
    private $order_id;
    private $customer_id;

    function __construct() {
        parent::__construct();
    }

    function index() {
        $this->requestType = $this->requestTypeGet;
        if (!$this->validateRequestType()) {
            return;
        }
        $this->order_id = value_get('orderId');
        $this->customer_id = value_get('CustomerId');
        if (empty($this->order_id) || empty($this->customer_id) || $this->validateFormData() === true) {
            $this->message = 'No Order found For the Customer';
            $this->statusCode = 403;
            return;
        }
        $order = $this->getOrderDetails($this->order_id, $this->customer_id);

        $this->response = [
            'companyinfo' => value_pick($order, 'companyinfo'),
            'customerinfo' => value_pick($order, 'customerinfo'),
            'comment' => value_pick($order, 'comment'),
            'ccredit' => value_pick($order, 'ccredit'),
            'producttable' => value_pick($order, 'producttable'),
            'tabs' => value_pick($order, 'tabs')
        ];
        return;
    }

    private function validateFormData() {
        if (empty($this->order_id) || dbGetCell(dbGetConnection()->where('ordnum', $this->order_id)->get('orderinfo', 1, 'id')) === false) {
            $error = true;
        }
        return isset($error) ? true : false;
    }

    private function getOrderDetails($orderId, $customer_id) {
        $responceArray = array();
        $responceArray['companyinfo'] = dbGetConnection()->join("customer c", "c.owner_id=o.id", "Inner")->where('c.id', $customer_id)->get('owner o', null, 'c.owner_id,c.manager , o.o_company as company');
        $responceArray['customerinfo'] = dbGetResultArray(dbGetConnection()->where('id', $customer_id)->get('customer'));
        $cleanExtraData = dbGetRow(dbGetConnection()->where('ordnum', $orderId)->get('orderinfo', null, 'ordcustcredit,ordcomment'));
        if (!$cleanExtraData) {
            $this->message = 'Order Information Not Found';
            $this->statusCode = 403;
            return;
        }
        $responceArray['comment'] = $cleanExtraData['ordcomment'];
        if ($cleanExtraData['ordcustcredit'] == "") {
            $cleanExtraData['ordcustcredit'] = 0;
        }
        $responceArray['ccredit'] = $cleanExtraData['ordcustcredit'];
        $responceArray['purchase_order'] = '';

        $products = dbGetResultArray(dbGetConnection()->rawQuery($this->existing_query_to_load($this->customer_id, $this->order_id)));
        if (empty(count($products))) {
            $this->message = 'No records in Products';
            $this->statusCode = 403;
            return;
        }
        $responceArray['products'] = $products;
        $responceArray['producttable'] = view('formats.order_form', ['customerInfo' => value_pick($responceArray, 'customerinfo')[0], 'products' => $products]);
        $responceArray['tabs'] = array_values(array_map(function($item) {
                    return str_replace(' ', '-', $item);
                }, array_unique(array_column($products, 'type'))));
        return $responceArray;
    }

    private function existing_query_to_load($cust_id, $ordnum) {
        return "SELECT t1.id
	,t1.type
	,t1.productname
	,t1.pfamily
	,t1.model
        ,t1.upc
	,t1.description
	,t1.price
        ,t1.weight
	,t8.quantity
	,t8.ord_qty
	,t8.invoice_price
	,IFNULL(t3.cust_price, 00.00) AS 'c_price'
	,(IFNULL(t5.qty_inventory, 0) + IFNULL(t2.sumP, 0)) AS 'Inv_tot'
	,IFNULL(t4.sumM, 0) AS 'Sold'
	,(IFNULL(t5.qty_inventory, 0) + IFNULL(t2.sumP, 0) - IFNULL(t4.sumM, 0)) AS 'QOH'
	,IFNULL(t7.sumInc, 0) AS 'OnOrder'
        ,IFNULL(t80.Expired,0) AS 'Expired'
        ,IFNULL(t80.Damaged,0) AS 'Damaged'
FROM (
	(
		SELECT flavor.id
			,flavor.pfamily
			,flavor.model
			,flavor.description
			,flavor.price
                        ,flavor.upc
			,flavor.weight
			,products.productname
			,products.type
		FROM flavor
		LEFT JOIN products ON flavor.pfamily = products.family
		WHERE active_flavor = '1'
		ORDER BY family ASC
			,priority ASC
		) t1 LEFT JOIN (
		SELECT p_orders.f_id
			,sum(p_orders.qty_rcvd) AS 'sumP'
		FROM p_orders
		LEFT JOIN inventory ON p_orders.f_id = inventory.f_id
		WHERE u_date_rcvd > IFNULL(inventory.inventorynum,'0000000000')
		GROUP BY inventory.f_id
		) t2 ON t1.id = t2.f_id
	LEFT JOIN (
		SELECT product_id
			,cust_price
		FROM price
		WHERE price.customer_id = '" . $cust_id . "'
		) t3 ON t1.id = t3.product_id
	LEFT JOIN (
		SELECT inventory.f_id
			,orders.quantity
			,orders.ord_qty	
			,orders.invoice_price	
		FROM orders
		LEFT JOIN inventory ON orders.f_id = inventory.f_id
		WHERE orders.ordnum = '$ordnum'
		GROUP BY inventory.f_id
		) t8 ON t1.id = t8.f_id
	LEFT JOIN (
		SELECT inventory.f_id
			,sum(orders.quantity) AS 'sumM'	
		FROM orders
		LEFT JOIN inventory ON orders.f_id = inventory.f_id
		WHERE orders.ordnum > IFNULL(inventory.inventorynum,'0000000000')
		GROUP BY inventory.f_id
		) t4 ON t1.id = t4.f_id
	LEFT JOIN (
		SELECT inventory.f_id, inventory.qty_inventory
	        FROM inventory				
		) t5 ON t1.id = t5.f_id
        LEFT JOIN (
                SELECT p_orders.f_id
                        ,sum(p_orders.quantity) AS 'sumInc'
                FROM p_orders
                LEFT JOIN inventory ON p_orders.f_id = inventory.f_id
                        WHERE date_rcvd = '00-00-0000'
                GROUP BY f_id
                ) t7 ON t1.id = t7.f_id
                LEFT JOIN (
                SELECT orders.f_id
					,sum(CASE WHEN customer_id='57' THEN orders.quantity END) AS 'Expired'  
					,sum(CASE WHEN customer_id='58' THEN orders.quantity END) AS 'Damaged'
                FROM orders
				WHERE ordnum >= '1577836801'
                GROUP BY f_id
                ) t80 ON t1.id = t80.f_id
	)";
//        return "SELECT t1.id
//	,t1.type
//	,t1.productname
//	,t1.pfamily
//	,t1.model
//	,t1.description
//	,t1.price
//	,t8.quantity
//	,t8.ord_qty
//	,t8.invoice_price
//	,IFNULL(t3.cust_price, 00.00) AS 'c_price'
//	,(IFNULL(t5.qty_inventory, 0) + IFNULL(t2.sumP, 0)) AS 'Inv_tot'
//	,IFNULL(t4.sumM, 0) AS 'Sold'
//	,(IFNULL(t5.qty_inventory, 0) + IFNULL(t2.sumP, 0) - IFNULL(t4.sumM, 0)) AS 'QOH'
//	,IFNULL(t7.sumInc, 0) AS 'OnOrder'
//FROM (
//	(
//		SELECT flavor.id
//			,flavor.pfamily
//			,flavor.model
//			,flavor.description
//			,flavor.price
//			,products.productname
//			,products.type
//		FROM flavor
//		LEFT JOIN products ON flavor.pfamily = products.family
//		WHERE active_flavor = '1'
//		ORDER BY family ASC
//			,priority ASC
//		) t1 LEFT JOIN (
//		SELECT p_orders.f_id
//			,sum(p_orders.qty_rcvd) AS 'sumP'
//		FROM p_orders
//		LEFT JOIN inventory ON p_orders.f_id = inventory.f_id
//		WHERE u_date_rcvd > IFNULL(inventory.inventorynum,'0000000000')
//		GROUP BY inventory.f_id
//		) t2 ON t1.id = t2.f_id
//	LEFT JOIN (
//		SELECT product_id
//			,cust_price
//		FROM price
//		WHERE price.customer_id = '" . $cust_id . "'
//		) t3 ON t1.id = t3.product_id
//	LEFT JOIN (
//		SELECT inventory.f_id
//			,orders.quantity
//			,orders.ord_qty	
//			,orders.invoice_price	
//		FROM orders
//		LEFT JOIN inventory ON orders.f_id = inventory.f_id
//		WHERE orders.ordnum = '$ordnum'
//		GROUP BY inventory.f_id
//		) t8 ON t1.id = t8.f_id
//	LEFT JOIN (
//		SELECT inventory.f_id
//			,sum(orders.quantity) AS 'sumM'	
//		FROM orders
//		LEFT JOIN inventory ON orders.f_id = inventory.f_id
//		WHERE orders.ordnum > IFNULL(inventory.inventorynum,'0000000000')
//		GROUP BY inventory.f_id
//		) t4 ON t1.id = t4.f_id
//	LEFT JOIN (
//		SELECT inventory.f_id, inventory.qty_inventory
//	        FROM inventory				
//		) t5 ON t1.id = t5.f_id
//        LEFT JOIN (
//                SELECT p_orders.f_id
//                        ,sum(p_orders.quantity) AS 'sumInc'
//                FROM p_orders
//                LEFT JOIN inventory ON p_orders.f_id = inventory.f_id
//                        WHERE date_rcvd = '00-00-0000'
//                GROUP BY f_id
//                ) t7 ON t1.id = t7.f_id
//	)";
    }

}

?>