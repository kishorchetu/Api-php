<?php

namespace Libraries\OrderForms;

defined('BASEPATH') || die('No direct script access allowed');

use Abstracted\Api;

class UpdateTobePickOrder extends Api {

    private $clean_extra_data;
    private $clean_data;
    private $order_Id;
    private $customer_Id;

    function __construct() {
        parent::__construct();
    }

    function index() {
        $this->requestType = $this->requestTypePost;
        if (!$this->validateRequestType()) {
            return;
        }
        $this->clean_extra_data = json_decode(str_replace("\\", "", value_post('extraData')), true);
        $this->clean_data = json_decode(str_replace("\\", "", value_post('data')), true);
        $warehouse_id = value_session('warehouses')['selected']['id'];
        $this->order_Id = value_post('order_id');
        $this->customer_Id = value_post('CustomerId');

        if (empty($this->clean_extra_data) || empty($this->clean_data) || empty($this->order_Id)) {
            $this->message = 'Data Cannot be Empty';
            $this->statusCode = 403;
            return;
        }

        if ($this->checkStatusofOrder($this->order_Id)) {
            $this->message = 'Order alreday been processed';
            $this->statusCode = 403;
            return;
        }

        if (!$this->updateTobePickedOrderInfo($this->clean_data, $this->order_Id, $this->customer_Id, $warehouse_id)) {
            $this->message = 'Order Update Failure';
            $this->statusCode = 403;
            return;
        }
        if (!$this->updateTobePickedOrderDetailsInfo($this->clean_extra_data, $this->clean_data, $this->order_Id, $this->customer_Id, $warehouse_id)) {
            $this->message = 'Order Details Update Failure';
            $this->statusCode = 403;
            return;
        }

        $info = $this->rsponceOfUpdateOrder($this->order_Id);

        $mail_responce = $this->sendMailUpdateOrder($this->clean_extra_data, $this->clean_data, $info, $this->order_Id);
        if (!$mail_responce) {
            $this->statusCode = 400;
            $this->message = "Email Faild to Send";
            return;
        }

        $this->response = [
            'title' => "Order Updated",
            'response' => value_pick($info, 'confirm_order_info')
        ];
        return;
    }

    private function checkStatusofOrder($orderid) {
        $result = dbGetRow(dbGetConnection()->where('ordnum', $orderid)->get('orderinfo', null, 'ord_pick, pick_start'));
        if (empty($result)) {
            $this->message = 'order not found';
            $this->statusCode = 403;
            return;
        }
        if ($result['ord_pick'] == 1 && $result['pick_start'] == 1) {
            $this->message = 'Sorry this order has already been picked and picking has been completed';
            $this->statusCode = 403;
            return;
        }
        if ($result['ord_pick'] == 0 && $result['pick_start'] == 1) {
            $this->message = 'Order is in the process of being picked, no changes can be processed.';
            $this->statusCode = 403;
            return;
        }
    }

    private function updateTobePickedOrderInfo($data, $orderid, $custid, $warehouse_id) {
        $ownerInfo = $this->getOwnerOfCustomer($custid);
        $newflovr_ids = array_keys($this->clean_data);
        $modelinfo = dbGetResultArray(dbGetConnection()->where('id', $newflovr_ids, 'IN')->get('flavor', null, 'id,model'));
        $existflovr_ids = dbGetResultArray(dbGetConnection()->where('ordnum', $orderid)->get('orders', null, 'f_id'));
        $updatearray = $insertarray = array();
        foreach ($data as $key => $value) {
            if (in_array($key, $existflovr_ids)) {
                $updatearray = array(
                    'warehouse_id' => $warehouse_id,
                    'quantity' => $value['qty'],
                    'ord_qty' => $value['qty'],
                    'invoice_price' => $value['saleprice'],
                    'cust_price' => $value['custprice']
                );
                $result = dbGetConnection()
                        ->where('f_id', $key)
                        ->where('ordnum', $orderid)
                        ->update('orders', $updatearray);
            } else {
                //insert multi
                $insertarray[] = array(
                    'customer_id' => $custid,
                    'owner_id' => $ownerInfo['owner_id'],
                    'warehouse_id' => $warehouse_id,
                    'ordnum' => $orderid,
                    'orddate' => date('ymd'),
                    'buyer' => $ownerInfo['email'],
                    'model' => $modelinfo[$key],
                    'f_id' => $key,
                    'ord_qty' => $value['qty'],
                    'quantity' => $value['qty'],
                    'wh_price' => $value['WHPrice'],
                    'cust_price' => $value['custprice'],
                    'invoice_price' => $value['saleprice']
                );
            }
        }
        if (!empty($insertarray)) {
            $insertids = dbGetConnection()->insertMulti('orders', $insertarray);
            if (!$insertids) {
                $this->message = 'Something went wrong When insert' . dbGetConnection()->getLastError();
                $this->statusCode = 403;
                return;
            }
        }

        return true;
    }

    private function updateTobePickedOrderDetailsInfo($extraData, $orderdata, $orderid, $custid, $warehouse_id) {

        $ownerInfo = $this->getOwnerOfCustomer($custid);

        $custp = $whp = $weightTotal = $qtyTotal = 0;
        foreach ($orderdata as $id => $price) {
            $custp += ($orderdata[$id]['custprice'] * $orderdata[$id]['qty']);
            $whp += ($orderdata[$id]['WHPrice'] * $orderdata[$id]['qty']);
            $weightTotal += ($orderdata[$id]['Weight'] * $orderdata[$id]['qty']);
            $qtyTotal += $orderdata[$id]['qty'];
        }

        $cust_total = $custp - (($extraData['ccredit'] == '') ? 0 : $extraData['ccredit']);


        $data = array(
            'customer_id' => $custid,
            'owner_id' => $ownerInfo['owner_id'],
            'warehouse_id' => $warehouse_id,
            'ordwhtotal' => number_format($whp, 2),
            'ordcustsubtotal' => number_format($custp, 2),
            'ordcusttotal' => $cust_total,
            'ord_update' => '1',
            'ord_update_time' => time(),
            'payment_due' => number_format($whp, 2),
            'ordcustcredit' => (($extraData['ccredit'] == '') ? 0 : $extraData['ccredit']),
            'ordcomment' => $extraData['comment'],
            'weight_total' => $weightTotal,
            'case_total' => $qtyTotal
        );

        $resultId = dbGetConnection()
                ->where('ordnum', $orderid)
                ->update('orderinfo', $data);
        if (!$resultId) {
            $this->message = 'Something went wrong When Update OrderDetails';
            $this->statusCode = 403;
            return;
        }

        return true;
    }

    private function sendMailUpdateOrder($clean_extra_data, $clean_data, $emailData, $orderNumber = null) {
        $ids = '';
        foreach ($clean_data as $id => $price) {
            if ($price['qty'] > 0) {
                $ids .= "flavor.id=$id OR ";
            }
        }
        $ids = rtrim($ids, "OR ");
        $results = $this->selectFlavorsFamily($ids);
        $customerId = $clean_extra_data['customer'];
        $customerInfo = dbGetRow(dbGetConnection()->where('id', $customerId)->get('customer', 1));
        if ($customerInfo === false) {
            $this->message = 'Invaild Customer Selection';
            $this->statusCode = 403;
            return;
        }
        $message = view('formats.order_email_template', ['customerInfo' => $customerInfo, 'clean_extra_data' => $clean_extra_data, 'productsInfo' => $results, 'clean_data' => $clean_data, 'customerId' => $customerId, 'orderNumber' => $orderNumber]);

        $emailinfo = [];
        $emailinfo['from'] = value_pick($emailData, 'from');
        $emailinfo['reply_to'] = value_pick($emailData, 'reply_to'); //not work
        $emailinfo['email_cc'] = value_pick($emailData, 'email_cc');         
        $emailinfo['email_to']= value_pick($emailData, 'emailTo');
//        $emailinfo['reply_to'] = 'kishork@chetu.com';
//        $emailinfo['email_to'] = 'mayurg@chetu.com'; //remove on production     
        $emailinfo['subject'] = value_pick($emailData, 'emailSubject');
        $emailinfo['body'] = $message;
        //pre($emailinfo);  
//        return $message = sendingMail($emailinfo);
    }

    private function getOwnerOfCustomer($customerId) {
        $sql = 'Select * from customer as t1 join owner as t2 on t1.owner_id=t2.id where t1.id=?';
        $result = dbGetRow(dbGetConnection()->rawQuery($sql, [$customerId]));
        if ($result === false) {
            return;
        }

        return $result;
    }

    private function rsponceOfUpdateOrder($ordnum) {

        $customerId = $this->clean_extra_data['customer'];
        $comment = clean($this->clean_extra_data['comment']);

        $emailSubject = 'Update for Order Number ' . $ordnum;

        $ownerInfo = $this->getOwnerOfCustomer($customerId);
        $ownerId = $ownerInfo['owner_id'];
        $emailTo = $ownerInfo['email'];
        $emailFrom = $ownerInfo['email'];

        $confirm_order_info = '';
        $message = "ordered by: " . $emailTo . "\n";
        $message .= "***Comment*** " . $comment . " ***Comment*** \n";

        $total = 0;
        $tqty = 0;

        $ids = '';

        foreach ($this->clean_data as $id => $price) {
            if ($price['qty'] > 0) {
                $ids .= "flavor.id=$id OR ";
            }
        }

        $ids = rtrim($ids, "OR ");

        $results = $this->selectFlavorsFamily($ids);

        if (count($results)) {

            $subTot = 0;
            $invSubTot = 0;
            $x = 1;
            $subQty = 0;
            $ofam = "";
            foreach ($results as $key => $row) {

                if ($ofam == "") {
                    $ofam = $row['pfamily'];
                    $prod = $row['productname'];
                } elseif ($ofam !== $row['pfamily']) {

                    if ($subTot > 0) {
                        $subMess = "Subtotal for " . $prod . " section is $" . number_format($subTot, 2) . " for " . $subQty . " units \n";
                        $qtyMess = "Subtotal is " . $subQty . " cases\n";

                        $message = $message . $subMess;
                        $confirm_order_info .= $subMess;
                    }

                    $total = $total + $subTot;
                    $subTot = 0;
                    $subQty = 0;
                    $ofam = $row['pfamily'];
                    $x = 1;
                    $prod = $row['productname'];
                }

                $pfamily = $row['pfamily'];
                $model = $row['model'];
                $desc = $row['description'];
                $id = $row['id'];
                $custPrice = $this->clean_data[$id]['custprice'];
                $cost = $this->clean_data[$id]['saleprice'];
                $whCost = $this->clean_data[$id]['WHPrice'];


                if ($customerId == 57 || $customerId == 58) {
                    $whCost = number_format(($whCost * .95), 2);
                    $cost = number_format($whCost, 2);
                }
                $str = "quantity";
                $qty = $this->clean_data[$id]['qty'];

                $invSubTot = $invSubTot + ($cost * $qty);

                if ($x == 1) {
                    $message = $message . " \r\n" . $prod . "\n";
                }

                $lineTot = $qty * $whCost;

                $out = " " . $desc . " quantity ordered=" . $qty . " @$" . number_format($whCost, 2) . "=$" . number_format($lineTot, 2) . "\n";
                $confirm_order_info .= $out;
                $subQty = $subQty + $qty;
                $specialId = substr($model, -4);
                $whOut = "    " . $qty . "cs        " . $specialId . "    " . $desc . " ";

                $message = $message . $out;



                $subTot = $subTot + $lineTot;
                $tqty = $tqty + $qty;

                $x++;
            }

            if ($subTot > 0) {
                $subMess = "Subtotal for " . $prod . " section is $" . number_format($subTot, 2) . " for " . $subQty . " units \n";
                $qtyMess = "Subtotal is " . $subQty . " cases\n";

                $message = $message . $subMess;
                $confirm_order_info .= $subMess;
            }

            $total = $total + $subTot;
            $subTot = 0;
        }

        $data_credit = $this->clean_extra_data['ccredit'];
        if ($data_credit == "") {
            $data_credit = 0;
        }
        $confirm_order_info .= "\n\nTotal Quantity of cases ordered is " . $tqty . "\n";
        $confirm_order_info .= "Warehouse Charge for Order is $" . number_format($total, 2) . "\n";
        $confirm_order_info .= "Credit for order is $" . ($data_credit) . "\n";
        $confirm_order_info .= "Total (Customer Price - Credit) for Order is $" . number_format(($invSubTot - $data_credit), 2) . "\n";

        $emailData = array();



        if ($customerId == 57 || $customerId == 58) {
            $emailFrom = "Expired-Damaged.Orders@GreenlandDairy.com";
            $emailTo = $this->attachPartnerEmailAddress(); // as per recommended for companies in application
        } else {
            $emailFrom = "Orders@GreenlandDairy.com";
            $CC = "steven.tarantola@gmail.com";
            $emailData['email_cc'] = $this->attachUserEmailAddress($ownerId, $CC); // as per recommended
        }

        $emailData['from'] = $emailFrom;
        $emailData['reply_to'] = $emailFrom;
        $emailData['emailTo'] = $emailTo;
        $emailData['emailSubject'] = $emailSubject;
        $emailData['confirm_order_info'] = $confirm_order_info;


        return $emailData;
    }

    private function attachPartnerEmailAddress() {
        $user_email = "";
        $query = "SELECT t1.email as email FROM `owner` as t1 WHERE t1.`partner`=?";
        $results = dbGetResultArray(dbGetConnection()->rawQuery($query, [1]));
        if ($results === false) {
            return;
        }
        if (count($results) > 0) {
            foreach ($results as $mail) {
                $user_email .= $mail . ",";
            }
        }
        return $user_email;
    }

    private function attachUserEmailAddress($q, $email) {
        $user_email = "";
        $query = "select email from user where owner_id=?";
        $results = dbGetResultArray(dbGetConnection()->rawQuery($query, [$q]));
        if ($results === false) {
            return;
        }
        if (count($results) > 0) {
            foreach ($results as $mail) {
                $user_email .= $mail . ",";
            }
        }

        $user_email .= $email;
        return $user_email;
    }

    private function selectFlavorsFamily($ids) {

        $sql_single = "Select flavor.pfamily, flavor.model, flavor.description, flavor.id, flavor.price, products.family, products.productname from flavor INNER JOIN products on flavor.pfamily=products.family where ($ids) Order By flavor.pfamily, flavor.priority asc";

        $result = dbGetResultArray(dbGetConnection()->rawQuery($sql_single));
        if ($result === false) {
            return;
        }
        return $result;
    }

}
