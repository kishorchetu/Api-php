<?php

namespace Libraries\OrderForms;

defined('BASEPATH') || die('No direct script access allowed');

use Abstracted\Api;

class LoadCustomers extends Api {

    private $owner_id;

    function __construct() {
        parent::__construct();
    }

    function index() {
        $this->requestType = $this->requestTypeGet;
        if (!$this->validateRequestType()) {
            return;
        }
        $this->owner_id = value_get('ownerId');
        if($this->owner_id){
            $query="SELECT DISTINCT (id),(custname), (custaddress) FROM customer WHERE owner_id=? AND active_cust=?";
            $info = dbGetResultArray(dbGetConnection()->rawQuery($query, [$this->owner_id, '1']));
            if(count($info) === 0){
                $this->message = 'Dont have any active customers';
                $this->statusCode = 403;
                return;
            }
            $this->response =$info;
            return;
        }else {
            $this->statusCode = 400;
            $this->message = "Your request is not process";
            return;
        }
         
    }
}
    
?>