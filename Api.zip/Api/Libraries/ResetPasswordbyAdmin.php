<?php

namespace Libraries;

defined('BASEPATH') || die('No direct script access allowed');

use Abstracted\Api;

class ResetPasswordbyAdmin extends Api {

    private $token;
    private $password;
    private $confirmPassword;

    function __construct() {
        parent::__construct();
    }

    function index() {
        $this->requestType = $this->requestTypePost;
        if (!$this->validateRequestType()) {
            return;
        }
        if (value_post('userid')) {
            $this->userid = value_post('userid');
        } else {
            $this->statusCode = 400;
            $this->message = "Please select User";
            return;
        }
        
        $query = "SELECT * FROM `user` WHERE `id`=?";
        $info = dbGetRow(dbGetConnection()->rawQuery($query, [$this->userid]));
        
        if ($info === false) {
            $this->message = 'Invalid User';
            $this->statusCode = 403;
            return;
        }

        $email = $info['email'];
        $firstname = $info['firstname'];
        $lastname = $info['lastname'];

        $password = $this->generatePassword(8);
        $password_crypt = password_hash($password, PASSWORD_DEFAULT);

        $data = array(
            'password' => "$password_crypt",
            'is_lock' => '0'
        );
        
        $updateresult = dbGetConnection()
                ->where('id',$this->userid)
                ->update('user', $data);
        
        if ($updateresult === false) {
            $this->message = 'Not Execute update Command';
            $this->statusCode = 403;
            return;
        }

        $message = $this->email_reset_password_template_for_admin($password, $firstname, $lastname, $email);
        $email_data = array();
        $email_data['from'] = "GreenlandOnAWS";
        $email_data['fromName'] = "Greenland AWS";
        $email_data['subject'] = "Password Reset Activation Mail";
        $email_data['body'] = $message;
        $email_data['email_to']=$info['email'];
//        $email_data['email_to'] = 'mayurg@chetu.com';
//        $message = sendingMail($email_data);
        $response = $message;

        $this->statusCode = 200;
        $this->message = 'Password reset email sent';
        return;
    }

    private function generatePassword($n) {
        $generated_string = "";

        $domain = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";

        $len = strlen($domain);

        for ($i = 0; $i < $n; $i++) {
            $index = rand(0, $len - 1);
            $generated_string = $generated_string . $domain[$index];
        }

        return $generated_string;
    }

    private function email_reset_password_template_for_admin($password, $fname, $lname, $email) {
        $template = '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
            <html xmlns="http://www.w3.org/1999/xhtml">
            <head>
                <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
                <title>Forgot Password</title>
                <style>
                    body {
                        background-color: #FFFFFF; padding: 0; margin: 0;
                    }
                </style>
            </head>
            <body style="background-color: #FFFFFF; padding: 0; margin: 0;">
            <table border="0" cellpadding="0" cellspacing="10" height="100%" bgcolor="#FFFFFF" width="100%" style="max-width: 650px;" id="bodyTable">
                <tr>
                    <td align="center" valign="top">
                        <table border="0" cellpadding="0" cellspacing="0" width="100%" id="emailContainer" style="font-family:Arial; color: #333333;">
                            <!-- Logo -->
                            <tr>
                                <td align="left" valign="top" colspan="2" style="border-bottom: 1px solid #CCCCCC; padding-bottom: 10px;">
                                    <img alt="' . base_url() . '" border="0" src="' . base_url('dannon.jpg') . '" title="' . base_url() . '" class="sitelogo" width="60%" style="max-width:250px;" />
                                </td>
                            </tr>
                            <!-- Title -->
                            <tr>
                                <td align="left" valign="top" colspan="2" style="border-bottom: 1px solid #CCCCCC; padding: 20px 0 10px 0;">
                                    <span style="font-size: 18px; font-weight: normal;">Password Reset By Admin</span>
                                </td>
                            </tr>
                            <!-- Messages -->
                            <tr>
                                <td align="left" valign="top" colspan="2" style="padding-top: 10px;">
                                    <span style="font-size: 12px; line-height: 1.5; color: #333333;">
                                        Hi ' . $fname . ' ' . $lname . '
                                        <br/><br/>
                                        We have sent you this email in response to your password on ' . base_url() . '. has been reset by Admin. you can reset your password we recommend to make it unique and not predictable.
                                        <br/><br/>
                                        To Login your account for <a href="' . base_url() . '">' . base_url() . '</a>, please follow the link below:
                                        <br /> Email : ' . $email . '
                                        <br /> password : ' . $password . '
                                        <br/><br/>
                                        We recommend that you keep your password secure and not share it with anyone.If you feel your password has been compromised, you can change it by going to your My Account Page and clicking on the "Change Password" button.
                                        <br/><br/>
                                        If you need help, or you have any other questions, feel free to email steven.tarantola@gmail.com, or call (973) 837-6798 or fax at (973) 837-6799.
                                        <br/><br/>
                                        GREENLAND DAIRY
                                    </span>
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
            </table>
            </body>
            </html>';
        return $template;
    }

}
