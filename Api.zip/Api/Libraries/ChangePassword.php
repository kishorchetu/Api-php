<?php

namespace Libraries;

defined('BASEPATH') || die('No direct script access allowed');

use Abstracted\Api;

class ChangePassword extends Api {

    private $password;
    private $confirmPassword;

    function __construct() {
        parent::__construct();
    }

    function index() {
        $this->requestType = $this->requestTypePost;
        if (!$this->validateRequestType()) {
            return;
        }
        if(value_post('oldpassword') && value_post('newpassword') && value_post('userid')){
            $this->oldpassword = value_post('oldpassword');
            $this->newpassword = value_post('newpassword');
            $this->userid = value_post('userid');
        }else{
            $this->statusCode = 400;
            $this->message = 'Password cannot be empty';
            return;
        }
        
        $query ="SELECT * FROM `user` WHERE `id`=?";
        $info = dbGetRow(dbGetConnection()->rawQuery($query, [$this->userid]));
        if ($info === false) {
            $this->message = 'Invalid User';
            $this->statusCode = 403;
            return;
        }
        
        if (password_verify($this->oldpassword, $info['password'])) {
            $new_pass_cypt = password_hash($this->newpassword, PASSWORD_DEFAULT);
            $sql = "UPDATE `user` SET `password`='".$new_pass_cypt."',`is_lock`='0' WHERE `id`=".$this->userid."";
            
            $data = array(
                'password' => "$new_pass_cypt",
                'is_lock' => '0'
            );

            $updateresult = dbGetConnection()
                    ->where('id', $this->userid)
                    ->update('user', $data);
            if ($updateresult === false) {
                $this->message = 'Not Execute update Command';
                $this->statusCode = 403;
                return;
            }
            $this->statusCode = 200;
            $this->message = "Password changed successfully";
            return;
        }
        else{
            $this->statusCode = 400;
            $this->message = "Password is not match";
            return;
        }
    }
}
