<?php

namespace Libraries;

defined('BASEPATH') || die('No direct script access allowed');

use Abstracted\Api;

class Test extends Api {

    function __construct() {
        parent::__construct();
    }

    function index() {
        $this->requestType = $this->requestTypeGet;
        if (!$this->validateRequestType()) {
            return;
        }
        sleep(2);
        $this->message='for url: '. value_get('cu');
    }

}
