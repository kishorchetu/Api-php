<?php
namespace Libraries\Roles;
defined('BASEPATH') || die('No direct script access allowed');
use Abstracted\Api;

class Add extends Api {

    private $errors = [];
    private $roleName;

    function __construct() {
        parent::__construct();
    }

    function index() {
        $this->requestType = $this->requestTypePost;
        if(!$this->validateRequestType()) {
            return;
        }
        if(!$this->validateFormData()) {
            $this->message = 'Invalid form data';
            $this->statusCode = 400;
            $this->response = $this->errors;
            return;
        }
       $this->saveRole();
    }

    private function setFormData() {

        $this->roleName = value_post('rolename');
    }

    private function validateFormData() {
        $this->setFormData();

        if (empty($this->roleName)) {
            $this->errors[] = 'Role name is required';
        }
        
        if(!preg_match("/^[a-zA-Z ]*$/", $this->roleName)) {
            $this->errors[] = 'Role name must be alphabetic';
        }

        return count($this->errors) === 0;
    }

    private function saveRole() {

        $roleData = [
            'name' => $this->roleName,
            'modified_at' => date(DATE_FORMAT_TIME_STAMP),
            'created_at' => date(DATE_FORMAT_TIME_STAMP)
        ];

        if (!is_numeric(dbInsert('roles', $roleData))) {
            $this->statusCode = 500;
            $this->message = 'Somthing went wrong while added new Role';
            return;
        }
        $this->message = 'New role added successfuly';
    }

}
