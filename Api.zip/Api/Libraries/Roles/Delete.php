<?php

namespace Libraries\Roles;

defined('BASEPATH') || die('No direct script access allowed');

use Abstracted\Api;

class Delete extends Api {

    private $roleId;
    private $error = [];

    function __construct() {
        parent::__construct();
    }

    function index() {
        $this->requestType = $this->requestTypePost;
        if (!$this->validateRequestType()) {
            return;
        }
        if (!$this->validateFormData()) {
            $this->statusCode = 400;
            $this->response = $this->error;
            return;
        }
        $this->updateRole();
    }

    private function setFormData() {
        $this->roleId = value_post('role_id');
        $this->delete = intval(value_post('delete', '1')) === 1; //1:delete, 2:retrieve
    }
    
    private function validateFormData() {
        $this->setFormData();
        if (!is_numeric($this->roleId) || dbGetCell(dbGetConnection()->where('id', $this->roleId)->get('roles')) === false) {
            $this->error[] = 'Invalid role selected to delete';
        }
        return count($this->error) === 0;
    }

    private function updateRole() {
        $update = [
            'deleted_at' => $this->delete ? date(DATE_FORMAT_TIME_STAMP) : null,
            'modified_at' => date(DATE_FORMAT_TIME_STAMP)
        ];
        if (!dbGetConnection()->where('id', $this->roleId)->update('roles', $update)) {
            $this->statusCode = 503;
            $this->message = 'Somthing went wrong with database while ' . ($this->delete ? 'deleting' : 'retrieving') . ' role\s account';
            return;
        }
        $this->message = 'Role\'s account ' . ($this->delete ? 'deleted' : 'retrieved') . ' successfully';
    }

}
