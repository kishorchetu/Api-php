<?php

namespace Libraries\Roles;


use Abstracted\Api;


class Permissions extends Api {


    function __construct() {
        parent::__construct();
    }

    function index() {
        $this->requestType = $this->requestTypeGet;
        if (!$this->validateRequestType()) {
            return;
        }
        $this->response = [
            'all' => $this->getAllPermissions(),
            'permitted' => $this->getPermittedPermissions(),
            'sectionpermitted' => $this->getAllSection()
        ];
    }

    private function getAllPermissions() {
        return load('NavigationBar')->getNavArray();
    }

    private function getPermittedPermissions() {
        $roleId = intval(value_get('role_id'));
        $query = 'SELECT menu.id, menu.label, menu.link, menu.parent from menu 
                INNER JOIN roles ON FIND_IN_SET(menu.id, roles.url_permissions) <> 0 
                WHERE roles.id = ? 
                ORDER BY menu.id';
        return dbGetResultArray(dbGetConnection()->rawQuery($query, [$roleId]));
    }
    
    private function getAllSection() {
        $roleId = intval(value_get('role_id'));
        $query = 'SELECT section.id, section.name, section.page_permission from section 
                INNER JOIN roles ON FIND_IN_SET(section.id, roles.section_permissions) <> 0 
                WHERE roles.id = ? 
                ORDER BY section.id';
         return dbGetResultArray(dbGetConnection()->rawQuery($query, [$roleId]));
    }

}
