<?php

namespace Libraries\Roles;

defined('BASEPATH') || die('No direct script access allowed');

use Abstracted\Api;

class Update extends Api {

    private $errors = [];
    private $roleId;
    private $roleName;

    function __construct() {
        parent::__construct();
    }

    function index() {
        $this->requestType = $this->requestTypePost;
        if (!$this->validateRequestType()) {
            return;
        }
        if (!$this->validateFormData()) {
            $this->message = 'Invalid form data';
            $this->statusCode = 400;
            $this->response = $this->errors;
            return;
        }
        $this->editRole();
    }

    private function setFormData() {
        $this->roleId = intval(value_post('roleid'));
        $this->roleName = value_post('rolename');
    }

    private function validateFormData() {
        $this->setFormData();
        if (empty($this->roleName)) {
            $this->errors[] = 'Role name is required';
        }
       if(!preg_match("/^[a-zA-Z ]*$/", $this->roleName)) {
            $this->errors[] = 'Role name must be alphabetic';
        }

        return count($this->errors) === 0;
    }

    private function editRole() {
        $roleData = [
            'name' => $this->roleName,
            'modified_at' => date(DATE_FORMAT_TIME_STAMP)
        ];
        if (!dbGetConnection()->where('id', $this->roleId)->update('roles', $roleData)) {
            $this->statusCode = 500;
            $this->message = 'Somthing went wrong while updating role';
            return;
        }
        $this->message = 'Role updated successfuly';
    }

}
