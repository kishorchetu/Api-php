<?php

namespace Libraries\Roles;

use Abstracted\Api;

class UpdatePermissions extends Api {

    private $roleId;
    private $permissions;
    private $sectionname;
    private $errors = [];

    function __construct() {
        parent::__construct();
    }

    function index() {
        $this->requestType = $this->requestTypePost;
        if (!$this->validateRequestType()) {
            return;
        }
        $this->roleId = intval(value_post('role_id'));
        $this->setRequestdata();
        $this->setSectiondata();
        if (!$this->validateRequestData()) {
            $this->statusCode = 400;
            $this->response = $this->errors;
            return;
        }
        $this->updatePermission();
    }

    private function setRequestdata() {
        $this->permissions = remove_array_values(array_map(function($item) {
                    return intval(trim($item));
                }, explode(',', value_post('permissions'))), 0, true);
        sort($this->permissions);
    }

    private function setSectiondata() {
        $this->sectionname = remove_array_values(array_map(function($item) {
                    return intval(trim($item));
                }, explode(',', value_post('sections'))), 0, true);
        sort($this->sectionname);
    }

    private function validateRequestData() {
        if ($this->roleId === 0) {
            $this->errors[] = 'Please select a valid role';
        }
        if (count($this->permissions) === 0) {
            $this->errors[] = 'Please select some permissions';
        }

        return count($this->errors) === 0;
    }

    private function updatePermission() {
        $data = [
            'url_permissions' => join(',', $this->permissions),
            'section_permissions' => join(',', $this->sectionname),
            'modified_at' => date(DATE_FORMAT_TIME_STAMP)
        ];
        $roleName = dbGetCell(dbGetConnection()->where('id', $this->roleId)->get('roles', null, 'name'));
        if (!dbGetConnection()->where('id', $this->roleId)->update('roles', $data)) {
            $this->statusCode = 400;
            $this->message = 'Somthing went wrong while updating permissions for role: ' . $roleName;
            return;
        }
        $this->message = 'New permissions updated for role: ' . $roleName;
    }

}
