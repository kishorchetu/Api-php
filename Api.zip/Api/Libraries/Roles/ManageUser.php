<?php

namespace Libraries\Roles;

defined('BASEPATH') || die('No direct script access allowed');

use Abstracted\Api;

class ManageUser extends Api {


    function __construct() {
        parent::__construct();
    }

    function index() {
        $this->requestType = $this->requestTypePost;
        if (!$this->validateRequestType()) {
            return;
        }
        $query="SELECT user.*, owner.*, user.email as userEmail, user.id as userid, roles.name as rolename
				  FROM user
				  LEFT JOIN owner ON user.owner_id=owner.id 
                                  join roles on user.role=roles.id";
        $users= dbGetResultArray(dbGetConnection()->rawQuery($query));
        if(count($users)===0){ 
            $this->statusCode=403;
            $this->message='There is no User in system';
            return;
        }
        $data=array();
        $data['data']=$users;
        $this->message=$data;
        return;
    }

}
