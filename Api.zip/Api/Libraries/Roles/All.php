<?php

namespace Libraries\Roles;

defined('BASEPATH') || die('No direct script access allowed');

use Abstracted\Api;

class All extends Api {

    function __construct() {
        parent::__construct();
    }

    function index() {
        $this->requestType = $this->requestTypeGet;
        if (!$this->validateRequestType()) {
            return;
        }
        $db = dbGetConnection();
        $role_id = value_get('role_id');
        if ($role_id) {
            $db->where('id', $role_id);
        }
        $roles = dbGetResultArray($db->where("deleted_at", null, "is")->orderBy("name", "asc")->get('roles', null, 'id, name, modified_at as last_modified'));
        if (count($roles) === 0) {
            $this->statusCode = 403;
            $this->message = 'There is no roles in system';
            return;
        }

        $this->response = $roles;
    }

}
