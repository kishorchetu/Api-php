<?php

namespace Libraries;

defined('BASEPATH') || die('No direct script access allowed');

use Abstracted\Api;

class Login extends Api {

    private $username;
    private $password;

    function __construct() {
        parent::__construct();
    }

    function index() {
        $this->requestType = $this->requestTypePost;
        if (!$this->validateRequestType()) {
            return;
        }
        $this->setFormData();
        $query = "SELECT user.*,owner.`owner`, owner.`email`, owner.`o_company`, "
                . "owner.`o_address1`, owner.`o_address2`, owner.`o_phone`, owner.`o_fax`, "
                . "owner.`route_owner`, owner.`route_upcharge`, owner.`partner`, owner.`priority`, "
                . "owner.`partner_sale_assoc` "
                . "FROM user "
                . "left join owner on owner.id=user.owner_id "
                . "WHERE user.email=?";
        $info = dbGetRow(dbGetConnection()->rawQuery($query, [$this->username]));

        if ($info === false) {
            $this->message = 'Please check username and password again !!!';
            $this->statusCode = 403;
            return;
        }

        if (password_verify($this->password, $info['password'])) {
            $access = $info['role'];
            $wherehouse = $info['warehouse'];
            $row = $info['firstname']; //need to change this depends on dependancy in project
            $email = $info['email'];
            $ownerid = $info['owner_id'];
            $route_upcharge = $info['route_upcharge'];
            $route_owner = $info['route_owner'];
            $partner = $info['partner'];
            $partnersaleassoc = $info['partner_sale_assoc'];
            $uid = $info['id'];
            $lock = $info['is_lock'];

            if ($lock == 1) {
                $this->statusCode = 400;
                $this->message = "Your Account is Lock please check your email";
                return;
            }
            
            $_SESSION['signed_in'] = true;
            $_SESSION['username'] = $row;
            $_SESSION['role'] = $access;
            $_SESSION['email'] = $email;
            $_SESSION['ownerid'] = $ownerid;
            $_SESSION['route_upcharge'] = $route_upcharge;
            $_SESSION['route_owner'] = $route_owner;
            $_SESSION['partner'] = $partner;
            $_SESSION['partner_sale_assoc'] = $partnersaleassoc;
            $_SESSION['uid'] = $uid;

            $data = array(
                'user_id' => $_SESSION['uid'],
                'login_status' => '1',
                'created_at' => date("Y-m-d H:i:s", time())
            );

            $resultid = dbInsert('login_history', $data);
            if (!$resultid) {
                $this->statusCode = 400;
                $this->message = "Something Went Wrong Please Try Again";
                return;
            }
            $cond='';
            $i=0;
            $wherehouse= explode(',', $wherehouse);
            foreach($wherehouse as $val){
                if($i>0){
                    $cond .=' or warehouse.id ='.$val;
                }
                else{
                    $cond .='warehouse.id ='.$val;
                }
                $i++;
            }
            //chenge query here
           $query22 = "SELECT warehouse.id,warehouse.name, warehouse.address
          FROM warehouse where $cond";

            $info = dbGetResultArray(dbGetConnection()->rawQuery($query22));

            if ($info === false) {
                $this->message = 'warehouse not access';
                $this->statusCode = 403;
                return;
            }

            $_SESSION['warehouses'] = [
                'all'=>$info,
                'selected'=>[]
            ];
            $this->statusCode = 200;
            $this->message = $this->username . ' authenticated successfully';
            $this->response = [
//              'redirect_url' => base_url('dashboard.php')
                'warehousedata' => $info
            ];
            return;
        } else {

            $uid = $info['id'];
            $lock = $info['is_lock'];

            $query = "select b.`id` from `login_history` as b WHERE b.`user_id`=? and b.`login_status`='1' ORDER BY b.`id` DESC LIMIT 1";
            $result = dbGetRow(dbGetConnection()->rawQuery($query, [$uid]));
            if ($result === false) {
                $query = "SELECT count(*) as count_attempt FROM `login_history` as a WHERE a.`user_id`=? and a.`login_status`='0' ";
                $result = dbGetRow(dbGetConnection()->rawQuery($query, [$uid]));
            } else {
                $subquery = $query;
                $query = "SELECT count(*) as count_attempt FROM `login_history` as a WHERE a.`user_id`=? and a.`login_status`='0' and a.`id` > (" . $subquery . ")";
                $result = dbGetRow(dbGetConnection()->rawQuery($query, [$uid, $uid]));
            }

            $count_attempt = $result['count_attempt'];
            $login_attempt_try = 3; //attempt for try to login

            if ($count_attempt >= ($login_attempt_try - 1)) {
                if ($lock === 0) {
                    $data = array(
                        'is_lock' => '1'
                    );

                    $cond = array(
                        'id' => $uid,
                    );
                    $updateresult = dbGetConnection()
                            ->where('id', $uid)
                            ->update('user', $data);
                    if ($updateresult === false) {
                        $this->message = 'Please check username and password again !!!';
                        $this->statusCode = 403;
                        return;
                    }

                    $passhashcode = getRandomId(false,true);
                    $data = array(
                        'user_id' => $uid,
                        'token' => $passhashcode,
                        'created_at' => date("Y-m-d H:i:s", time()),
                        'visited' => '0',
                        'password_reset_link_age' => '24'
                    );
                    $resultid = dbInsert('reset_password_history', $data);
                    if (!$resultid) {
                        $this->statusCode = 500;
                        $this->message = "Something went worong please try again";
                        return;
                    }
                    $link = "<a href='" . base_url() . "reset-password.php?passhashcode=" . $passhashcode . "'>" . base_url() . "reset-password.php?passhashcode=" . $passhashcode . "</a><br>";
                    $message = $this->email_reset_password_template($link);
                    $email_data = array();
                    $email_data['from'] = "GreenlandOnAWS";
                    $email_data['fromName'] = "Greenland AWS";
                    $email_data['subject'] = "Account lock Activation Mail";
                    $email_data['body'] = $message;
                    $email_data['email_to']=$this->username;
//                    $email_data['email_to'] = 'mayurg@chetu.com';
//                    $message = sendingMail($email_data);
                    $response = $message;
                }
                $this->statusCode = 400;
                $this->message = 'Your Account is Lock please check your email' ;
                return;
            } else {
                $count_attempt = $count_attempt + 1;
                $data = array(
                    'user_id' => $uid,
                    'login_status' => '0',
                    'created_at' => date("Y-m-d H:i:s", time())
                );
                $resultid = dbInsert('login_history', $data);
                if (!$resultid) {
                    $this->statusCode = 400;
                    $this->message = "Something Went Wrong Please Try Again";
                    return;
                }
                $remaining_attempt = $login_attempt_try - $count_attempt;
                $this->statusCode = 500;
                $this->message = 'Wrong credentials Remaining attempt ' . $remaining_attempt;
                return;
            }

            $this->statusCode = 400;
            $this->message = 'Your password is incorrect';
            return;
        }
    }

    private function setFormData() {
        if (value_post('username') && value_post('password')) {
            $this->username = value_post('username');
            $this->password = value_post('password');
        } else {
            $this->statusCode = 400;
            $this->message = "Please enter email and password";
            return;
        }
    }

    private function email_reset_password_template($link) {
        $template = '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
            <html xmlns="http://www.w3.org/1999/xhtml">
            <head>
                <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
                <title>Forgot Password</title>
                <style>
                    body {
                        background-color: #FFFFFF; padding: 0; margin: 0;
                    }
                </style>
            </head>
            <body style="background-color: #FFFFFF; padding: 0; margin: 0;">
            <table border="0" cellpadding="0" cellspacing="10" height="100%" bgcolor="#FFFFFF" width="100%" style="max-width: 650px;" id="bodyTable">
                <tr>
                    <td align="center" valign="top">
                        <table border="0" cellpadding="0" cellspacing="0" width="100%" id="emailContainer" style="font-family:Arial; color: #333333;">
                            <!-- Logo -->
                            <tr>
                                <td align="left" valign="top" colspan="2" style="border-bottom: 1px solid #CCCCCC; padding-bottom: 10px;">
                                    <img alt="' . base_url() . '" border="0" src="' . base_url('dannon.jpg') . '" title="' . base_url() . '" class="sitelogo" width="60%" style="max-width:250px;" />
                                </td>
                            </tr>
                            <!-- Title -->
                            <tr>
                                <td align="left" valign="top" colspan="2" style="border-bottom: 1px solid #CCCCCC; padding: 20px 0 10px 0;">
                                    <span style="font-size: 18px; font-weight: normal;">FORGOT PASSWORD</span>
                                </td>
                            </tr>
                            <!-- Messages -->
                            <tr>
                                <td align="left" valign="top" colspan="2" style="padding-top: 10px;">
                                    <span style="font-size: 12px; line-height: 1.5; color: #333333;">
                                        We have sent you this email in response to your request to reset your password on ' . base_url() . '. After you reset your password we recommend to make it unique and not predictable.
                                        <br/><br/>
                                        To reset your password for <a href="' . base_url() . '">' . base_url() . '</a>, please follow the link below:
                                        <br/> Link : ' . $link . '
                                        <br/><br/>
                                        We recommend that you keep your password secure and not share it with anyone.If you feel your password has been compromised, you can change it by going to your My Account Page and clicking on the "Change Password" button.
                                        <br/><br/>
                                        If you need help, or you have any other questions, feel free to email steven.tarantola@gmail.com, or call (973) 837-6798 or fax at (973) 837-6799.
                                        <br/><br/>
                                        GREENLAND DAIRY
                                    </span>
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
            </table>
            </body>
            </html>';
        return $template;
    }

}
