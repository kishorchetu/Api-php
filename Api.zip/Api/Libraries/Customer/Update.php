<?php

namespace Libraries\Customer;

defined('BASEPATH') || die('No direct script access allowed');

use Abstracted\Api;

class Update extends Api {

    private $errors = [];
    private $customerId;
    private $editcustName;
    private $editcustAddress;
    private $editcustCity;
    private $editcustState;
    private $editcustZip;
    private $editcustContactName;
    private $editcustContactPhone;
    private $editcompany;
    private $editcustPaymentTerms;
    private $editcustCashDisPer;
    private $editcustUpCharge;
    private $editcustUpChargePer;

    function __construct() {
        parent::__construct();
    }

    function index() {
        $this->requestType = $this->requestTypePost;
        if (!$this->validateRequestType()) {
            return;
        }
        if (!$this->validateFormData()) {
            $this->message = 'Invalid form data';
            $this->statusCode = 400;
            $this->response = $this->errors;
            return;
        }
        $this->editCustomer();
    }

    private function setFormData() {
        $this->customerId = int_val(value_post('editcustID'));
        $this->editcustName = value_post('editcustName');
        $this->editcustAddress = value_post('editcustAddress');
        $this->editcustCity = value_post('editcustCity');
        $this->editcustState = value_post('editcustState');
        $this->editcustZip = int_val(value_post('editcustZip'));
        $this->editcustContactName = value_post('editcustContactName');
        $this->editcustContactPhone = value_post('editcustContactPhone');
        $this->editcompany = int_val(value_post('editcompany'));
        $this->editcustPaymentTerms = value_post('editcustPaymentTerms');
        $this->editcustCashDisPer = value_post('editcustCashDisPer');
       // dump_var(value_post('editcustCashDisPer'));
        $this->editcustUpCharge = strtolower(value_post('editcustUpCharge')) === 'no' ? 0 : 1;
        $this->editcustUpChargePer = value_post('editcustUpChargePer');

        if (!$this->editcustUpCharge) {
            $this->editcustUpChargePer = '0.00';
        } else {
            $this->editcustUpChargePer = floatval($this->editcustUpChargePer) / 100;
        }
        if ($this->editcustPaymentTerms !== 'Cash Discount') {
            $this->editcustCashDisPer = '0.00';
        } else {
            $this->editcustCashDisPer = floatval($this->editcustCashDisPer) / 100;
        }
    }

    private function validateFormData() {
        $this->setFormData();

        if (empty($this->customerId) || dbGetCell(dbGetConnection()->where('id', $this->customerId)->get('customer', 1, 'id')) === false) {
            $this->errors[] = 'Please select any valid customer id';
        }
        if (empty($this->editcustName)) {
            $this->errors[] = 'Name is required';
        }
        if (!preg_match("/^[a-zA-Z ]*$/", $this->editcustName)) {
            $this->errors[] = 'Customer name must be alphabetic';
        }
        if (empty($this->editcustAddress)) {
            $this->errors[] = 'Address is required';
        }
        if (empty($this->editcustCity)) {
            $this->errors[] = 'City is required';
        }
        if (!preg_match("/^[a-zA-Z ]*$/", $this->editcustCity)) {
            $this->errors[] = 'City name must be alphabetic';
        }
        if (empty($this->editcustState)) {
            $this->errors[] = 'State is required';
        }
        if (!preg_match("/^[a-zA-Z ]*$/", $this->editcustState)) {
            $this->errors[] = 'State name must be alphabetic';
        }
        if (empty($this->editcustZip)) {
            $this->errors[] = 'Zip code is required';
        }
        //        if ( !preg_match("/^([0-9]{5})(-[0-9]{4})?$/i", $this->editcustZip) ){
        //             $this->errors[] = 'Please enter a valid zip code';
        //       }

        if (empty($this->editcustContactName)) {
            $this->errors[] = 'Contact name is required';
        }
        if (!preg_match("/^[a-zA-Z ]*$/", $this->editcustContactName)) {
            $this->errors[] = 'Contact name must be alphabetic';
        }
        if (empty($this->editcustContactPhone)) {
            $this->errors[] = 'Contact phone is required';
        }

        //    if( !preg_match("/^([0-1]-)?[0-9]{3}-[0-9]{3}-[0-9]{4}$/i", $this->editcustContactPhone) ) {
        //          $this->errors[] = 'Contact phone  is valid formate';
        //      }
        if (empty($this->editcompany)) {
            $this->errors[] = 'Company is required';
        }
        if (empty($this->editcustPaymentTerms)) {
            $this->errors[] = 'Payment term is required';
        }
        if (empty($this->editcustCashDisPer)) {
            $this->errors[] = 'Customer up-charge is required';
        }
        return count($this->errors) === 0;
    }

    private function editCustomer() {
        $customerData = [
            'custname' => $this->editcustName,
            'custaddress' => $this->editcustAddress,
            'custcity' => $this->editcustCity,
            'custstate' => $this->editcustState,
            'custzip' => $this->editcustZip,
            'contact_name' => $this->editcustContactName,
            'phone' => $this->editcustContactPhone,
            'company_id' => $this->editcompany,
            'payment_terms' => $this->editcustPaymentTerms,
            'cash_discount' => $this->editcustCashDisPer,
            'cust_upcharge' => $this->editcustUpCharge,
            'cust_upcharge_amt' => $this->editcustUpChargePer
        ];

        $updated = dbGetConnection()->where('id', $this->customerId)->update('customer', $customerData);
        if (!$updated) {
            $this->statusCode = 500;
            $this->message = 'Somthing went wrong while updating customer';
            return;
        }
        $this->message = 'customer updated successfuly';
    }

}
