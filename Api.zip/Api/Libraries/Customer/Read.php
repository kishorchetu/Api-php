<?php

namespace Libraries\Customer;

defined('BASEPATH') || die('No direct script access allowed');

use Abstracted\Api;

class Read extends Api {

    private $errors = [];
    private $customerId;

    function __construct() {
        parent::__construct();
    }

    function index() {
        $this->requestType = $this->requestTypeGet;
        if (!$this->validateRequestType()) {
            return;
        }
        if (!$this->validateFormData()) {
            $this->message = 'Invalid data';
            $this->response = $this->errors;
            $this->statusCode = 400;
            return;
        }
        $this->readCustomer();
    }

    private function setFormData() {
        $this->customerId = int_val(value_get('id'));
    }

    private function validateFormData() {
        $this->setFormData();
        if ($this->customerId === '0') {
            $this->errors[] = 'Invalid customer selected';
        }
         return count($this->errors) === 0;
    }

    private function readCustomer() {
        $customer = dbGetRow(dbGetConnection()->where('id', $this->customerId)->get('customer'));
        if ($customer === false) {
            $this->message = 'No customer was found associated with this id: ' . $this->customerId;
            $this->statusCode = 400;
            return;
        }
        
    if ($customer['cash_discount']!==0.000){
        $customer['cash_discount'] = floatval($customer['cash_discount'])*100; 
 
    }
      if ($customer['cust_upcharge_amt']!=='0.000'){
          $customer['cust_upcharge_amt'] = floatval($customer['cust_upcharge_amt']) * 100;
    }
       $this->response=$customer;
    }

}
