<?php

namespace Libraries\Customer;

defined('BASEPATH') || die('No direct script access allowed');

use Abstracted\Api;

class Add extends Api {

    private $errors = [];
    private $addcustName;
    private $addcustAddress;
    private $addcustCity;
    private $addcustState;
    private $addcustZip;
    private $addcustContactName;
    private $addcustContactPhone;
    private $addcompany;
    private $addcustPaymentTerms;
    private $addcustCashDisPer;
    private $addcustUpCharge;
    private $addcustUpChargePer;

    function __construct() {
        parent::__construct();
    }

    function index() {
        $this->requestType = $this->requestTypePost;
        if (!$this->validateRequestType()) {
            return;
        }
        $this->validateFormData();
        if (count($this->errors) > 0) {
            $this->message = 'Invalid form data';
            $this->statusCode = 400;
            $this->response = $this->errors;
            return;
        }
        $this->saveCustomer();
    }

    private function setFormData() {

        $this->addcustName = value_post('addcustName');
        $this->addcustAddress = value_post('addcustAddress');
        $this->addcustCity = value_post('addcustCity');
        $this->addcustState = value_post('addcustState');
        $this->addcustZip = value_post('addcustZip');
        $this->addcustContactName = value_post('addcustContactName');
        $this->addcustContactPhone = value_post('addcustContactPhone');
        $this->addcompany = value_post('addcompany');
        $this->addcustPaymentTerms = value_post('addcustPaymentTerms');
        $this->addcustCashDisPer = value_post('addcustCashDisPer');
        $this->addcustUpCharge = value_post('addcustUpCharge');
        $this->addcustUpChargePer = value_post('addcustUpChargePer');
        $this->addcustCopyPricing = value_post('addcustCopyPricing');
        $this->addcustPricingFrom = value_post('addcustPricingFrom');      

        $this->addcustUpCharge = strtolower($this->addcustUpCharge) === 'no' ? 0 : 1;
        if (!$this->addcustUpCharge) {
            $this->addcustUpChargePer = '0.00';
        } else {
            $this->addcustUpChargePer = floatval($this->addcustUpChargePer) / 100;
        }
        if ($this->addcustPaymentTerms !== 'Cash Discount') {
            $this->addcustCashDisPer = '0.00';
        } else {
            $this->addcustCashDisPer = floatval($this->addcustCashDisPer) / 100;
        }
    }

    private function validateFormData() {
        $this->setFormData();
        if (empty($this->addcustName)) {
            $this->errors[] = 'Customer name is required';
        }
        if (!preg_match("/^[a-zA-Z ]*$/", $this->addcustName)) {
            $this->errors[] = 'Customer name must be alphabetic';
        }
        if (empty($this->addcustAddress)) {
            $this->errors[] = 'Address is required';
        }
        if (empty($this->addcustCity)) {
            $this->errors[] = 'City is required';
        }
        if (!preg_match("/^[a-zA-Z ]*$/", $this->addcustCity)) {
            $this->errors[] = 'City name must be alphabetic';
        }
        if (empty($this->addcustState)) {
            $this->errors[] = 'State is required';
        }
        if (!preg_match("/^[a-zA-Z ]*$/", $this->addcustState)) {
            $this->errors[] = 'State name must be alphabetic';
        }

        if (empty($this->addcustZip)) {
            $this->errors[] = 'Zip code is required';
        }

//        if ( !preg_match("/^([0-9]{5})(-[0-9]{4})?$/i", $this->addcustZip) ){
//             $this->errors[] = 'Please enter a valid zip code';
//       }
        if (empty($this->addcustContactName)) {
            $this->errors[] = 'Contact name  is required';
        }
        if (!preg_match("/^[a-zA-Z ]*$/", $this->addcustContactName)) {
            $this->errors[] = 'Contact name must be alphabetic';
        }
        if (empty($this->addcustContactPhone)) {
            $this->errors[] = 'Contact phone  is required';
        }

//        if( !preg_match("/^([0-1]-)?[0-9]{3}-[0-9]{3}-[0-9]{4}$/i", $this->addcustContactPhone) ) {
//          $this->errors[] = 'Contact phone  is valid formate';
//      }

        if (empty($this->addcompany)) {
            $this->errors[] = 'Please select some valid company';
        }
        if (empty($this->addcustPaymentTerms)) {
            $this->errors[] = 'Please select payment term';
        }
        if (empty($this->addcustCashDisPer)) {
            $this->errors[] = 'Please select CustCashDisPer';
        }
    }

    private function saveCustomer() {
        $ownerid = value_session('ownerid');
        $info = $this->getOwnerEmailandManager($this->getOwnerId($this->addcompany));
//        $manager = value_session('username');
//        $email = value_session('email');
        $manager = $info['owner'];
        $email = $info['email'];

        $customerData = [
            'custname' => $this->addcustName,
            'custaddress' => $this->addcustAddress,
            'custcity' => $this->addcustCity,
            'custstate' => $this->addcustState,
            'custzip' => $this->addcustZip,
            'contact_name' => $this->addcustContactName,
            'phone' => $this->addcustContactPhone,
            'owner_id' =>$this->getOwnerId($this->addcompany),
            'manager' => $manager,
            'o_email' => $email,
            'company_id' => $this->addcompany,
            'payment_terms' => $this->addcustPaymentTerms,
            'cash_discount' => $this->addcustCashDisPer,
            'cust_upcharge' => $this->addcustUpCharge,
            'cust_upcharge_amt' => $this->addcustUpChargePer,
            'active_cust' => '1'
        ];
//        pre($customerData);
        $insertID = dbInsert('customer', $customerData);
        if (!is_numeric($insertID)) {
            $this->statusCode = 500;
            $this->message = 'Somthing went wrong while added new Customer'.$insertID;
            return;
        }
        // print_r($customerData);

        if (isset($this->addcustCopyPricing) && isset($this->addcustPricingFrom)) {
            $this->addcustPricingFrom = (trim(urldecode($this->addcustPricingFrom)));
            $sql = "SELECT * FROM price WHERE customer_id =?";
            $result = dbGetResultArray(dbGetConnection()->rawQuery($sql, [$this->addcustPricingFrom]));

            if ($result === false) {
                $this->message = 'Somthing went wrong while added new Customer';
                $this->statusCode = 403;
                return;
            }

            if (count($result)) {
                foreach ($result as $key => $row) {

                    $data = array(
                        'product_id' => $row['product_id'],
                        'cust_price' => $row['cust_price'],
                        'customer_id' => $insertID
                    );

                    $insertprice = dbInsert('price', $data);
                    if (!is_numeric($insertprice)) {
                        $this->statusCode = 500;
                        $this->message = 'Somthing went wrong while added new price for customer';
                        return;
                    }
                }
            }
        }


        $message = "New customer created with following details: <br /><br />";
        $message .= "<strong>Name: </strong>" . $this->addcustName . "<br />";
        $message .= "<strong>Address: </strong>" . $this->addcustAddress . "<br />";
        $message .= "<strong>City: </strong>" . $this->addcustCity . "<br />";
        $message .= "<strong>State: </strong>" . $this->addcustState . "<br />";
        $message .= "<strong>Zip: </strong>" . $this->addcustZip . "<br />";
        $message .= "<strong>Contact Name: </strong>" . $this->addcustContactName . "<br />";
        $message .= "<strong>phone: </strong>" . $this->addcustContactPhone . "<br />";
        $message .= "<br /><br />";

        $message .= "Created by: " . value_session('email');

        $this->message = 'New customer added successfuly';

        $email_data = [
            'from' => 'Customer@greenlanddairy.net',
            'fromName' => 'Greenland AWS',
            'subject' => "New Customer Created Named: " . $this->addcustName,
            'body' => $message,
            'email_to' => $email
                //          'email_to' => 'kishork@chetu.com'
        ];
//            sendingMail($email_data);
    }
    
    private function getOwnerId($companyid) {
        $ownerid = dbGetCell(dbGetConnection()->where('id',$companyid )->get('company', 1, 'owner_id'));
        if (!$ownerid) {
            $this->statusCode = 500;
            $this->message = 'Orner Not found of Company';
            return;
        }
        return $ownerid;
    }
    
    private function getOwnerEmailandManager($owner_id){
        $info = dbGetRow(dbGetConnection()->where('id', $owner_id)->get('owner'));
        if (!$info) {
            $this->statusCode = 500;
            $this->message = 'Orner Not found of Company';
            return;
        }
        
        return $info;
    }

}
