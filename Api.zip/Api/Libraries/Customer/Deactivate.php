<?php

namespace Libraries\Customer;

defined('BASEPATH') || die('No direct script access allowed');

use Abstracted\Api;

class Deactivate extends Api {

    private $errors = [];
    private $customers = [];

    function __construct() {
        parent::__construct();
    }

    function index() {
        $this->requestType = $this->requestTypePost;
        if (!$this->validateRequestType()) {
            return;
        }
        if (!$this->validateFormData()) {
            $this->response = $this->errors;
            $this->statusCode = 400;
            return;
        }
           $this->update();
    }

    private function setFormData() {
        $this->customers = array_map('int_val', value_post('customer'));
    }

    private function validateFormData() {
        $this->setFormData();
        if (!checkPermissionForSection('Deactivate Customer')) {
            $this->errors[] = 'You are not allowed to Deactivate customers';
        }
        if (count($this->customers) === 0) {
            $this->errors[] = 'Please select some customers';
        }
        if (count($this->customers) !== count(remove_array_values($this->customers, '0'))) {
            $this->errors[] = 'There are some invalid customers';
        }
        return count($this->errors) === 0;
    }

    private function update() {
        $updated = dbGetConnection()->where('id', $this->customers, 'IN')->update('customer', ['active_cust' => '0']);
        if (!$updated) {
            $this->message = 'Somthing went wrong while activating customers';
            $this->statusCode = 500;
            return;
        }
        $customerInfo = dbGetResultArray(dbGetConnection()->where('id', $this->customers, 'IN')->get('customer'));
        $message = "";
        foreach ($customerInfo as $info) {
            $O_id = $info['id'];
            $custname = $info['custname'];
            $custaddress = $info['custaddress'];
            $message .= "Customer Id #" . $O_id . " Deactivate successfully<br />";
            $message .= "Deactivate of Customer: " . $custname . "-" . $custaddress . "<br />";
            $message .= "Customer: " . $custname . " was deactivate by " . $_SESSION['email'] . "<br /><br />";
        }
        $email_to = $_SESSION['email'] . ',steven.tarantola@gmail.com';
//        $email_to = 'kishork@chetu.com';
        $email_data = [
            'from' => 'DB.update@greenlanddairy.net',
            'fromName' => 'Greenland AWS',
            'subject' => "Deactivate of Customer id(s)#: " . join(', ', $this->customers),
            'body' => $message,
            'email_to' => $email_to
        ];
//        sendingMail($email_data);
        $this->message='Total '.count($this->customers).' customer(s) have be deactivate';
    }

}
