<?php

namespace Libraries\Warehouses;

defined('BASEPATH') || die('No direct script access allowed');

use Abstracted\Api;

class All extends Api {


    function __construct() {
        parent::__construct();
    }

    function index() {
        $this->requestType = $this->requestTypeGet;
        if (!$this->validateRequestType()) {
            return;
        }
        $roles= dbGetResultArray(dbGetConnection()->orderBy("name","asc")->get('warehouse',null,'id, name'));
        if(count($roles)===0){ 
            $this->statusCode=403;
            $this->message='There is no roles in system';
            return;
        }
        $this->response=$roles;
        
    }

}
