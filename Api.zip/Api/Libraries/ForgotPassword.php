<?php

namespace Libraries;

defined('BASEPATH') || die('No direct script access allowed');

use Abstracted\Api;

class ForgotPassword extends Api {

    private $token;
    private $password;
    private $confirmPassword;

    function __construct() {
        parent::__construct();
    }

    function index() {
        $this->requestType = $this->requestTypePost;
        if (!$this->validateRequestType()) {
            return;
        }
        if (value_post('username')) {
            $this->email = value_post('username');
        } else {
            $this->statusCode = 400;
            $this->message = "Email cannot be empty";
            return;
        }

        $query = "SELECT * FROM `user` WHERE `email`=?";
        $info = dbGetRow(dbGetConnection()->rawQuery($query, [$this->email]));

        if ($info === false) {
            $this->message = 'Unauthenticate email address !!!';
            $this->statusCode = 403;
            return;
        }

        $uid = $info['id'];
        $passhashcode = getRandomId(false, true);

        $data = array(
            'user_id' => $uid,
            'token' => $passhashcode,
            'created_at' => date("Y-m-d H:i:s", time()),
            'visited' => '0',
            'password_reset_link_age' => '24'
        );

        $resultid = dbInsert('reset_password_history', $data);
        if (!$resultid) {
            $this->statusCode = 500;
            $this->message = "Not Execute Audit Command";
            return;
        }

        $data = array(
            'is_lock' => '1'
        );

        $cond = array(
            'id' => $uid,
        );
        $updateresult = dbGetConnection()
                ->where('id', $uid)
                ->update('user', $data);
        if ($updateresult === false) {
            $this->message = 'Not Execute update Command';
            $this->statusCode = 403;
            return;
        }
        $link = "<a href='" . base_url() . "reset-password.php?passhashcode=" . $passhashcode . "'>" . base_url() . "resetpassword.php?passhashcode=" . $passhashcode . "</a><br>";
        $message = $this->email_reset_password_template($link);
        $email_data = array();
        $email_data['from'] = "GreenlandOnAWS";
        $email_data['fromName'] = "Greenland AWS";
        $email_data['subject'] = "Account lock Activation Mail";
        $email_data['body'] = $message;
        $email_data['email_to']=$info['email'];
//        $email_data['email_to'] = 'mayurg@chetu.com';
//        $message = sendingMail($email_data);
        $response = $message;

        $this->statusCode = 200;
        $this->message = 'Please check your email';
        return;
    }

//end index

    private function email_reset_password_template($link) {
        $template = '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
            <html xmlns="http://www.w3.org/1999/xhtml">
            <head>
                <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
                <title>Forgot Password</title>
                <style>
                    body {
                        background-color: #FFFFFF; padding: 0; margin: 0;
                    }
                </style>
            </head>
            <body style="background-color: #FFFFFF; padding: 0; margin: 0;">
            <table border="0" cellpadding="0" cellspacing="10" height="100%" bgcolor="#FFFFFF" width="100%" style="max-width: 650px;" id="bodyTable">
                <tr>
                    <td align="center" valign="top">
                        <table border="0" cellpadding="0" cellspacing="0" width="100%" id="emailContainer" style="font-family:Arial; color: #333333;">
                            <!-- Logo -->
                            <tr>
                                <td align="left" valign="top" colspan="2" style="border-bottom: 1px solid #CCCCCC; padding-bottom: 10px;">
                                    <img alt="' . base_url() . '" border="0" src="' . base_url('dannon.jpg') . '" title="' . base_url() . '" class="sitelogo" width="60%" style="max-width:250px;" />
                                </td>
                            </tr>
                            <!-- Title -->
                            <tr>
                                <td align="left" valign="top" colspan="2" style="border-bottom: 1px solid #CCCCCC; padding: 20px 0 10px 0;">
                                    <span style="font-size: 18px; font-weight: normal;">FORGOT PASSWORD</span>
                                </td>
                            </tr>
                            <!-- Messages -->
                            <tr>
                                <td align="left" valign="top" colspan="2" style="padding-top: 10px;">
                                    <span style="font-size: 12px; line-height: 1.5; color: #333333;">
                                        We have sent you this email in response to your request to reset your password on ' . base_url() . '. After you reset your password we recommend to make it unique and not predictable.
                                        <br/><br/>
                                        To reset your password for <a href="' . base_url() . '">' . base_url() . '</a>, please follow the link below:
                                        <br/> Link : ' . $link . '
                                        <br/><br/>
                                        We recommend that you keep your password secure and not share it with anyone.If you feel your password has been compromised, you can change it by going to your My Account Page and clicking on the "Change Password" button.
                                        <br/><br/>
                                        If you need help, or you have any other questions, feel free to email steven.tarantola@gmail.com, or call (973) 837-6798 or fax at (973) 837-6799.
                                        <br/><br/>
                                        GREENLAND DAIRY
                                    </span>
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
            </table>
            </body>
            </html>';
        return $template;
    }

}
