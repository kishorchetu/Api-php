<?php
namespace Libraries;

defined('BASEPATH') || die('No direct script access allowed');

use Abstracted\Api;

class _404 extends Api
{

    function __construct()
    {
        parent::__construct();
    }

    function index()
    {
        $this->statusCode = 404;
        $this->message = 'Requested url was not found';
        $this->response = [];
    }
}
