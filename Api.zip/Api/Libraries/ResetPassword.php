<?php

namespace Libraries;

defined('BASEPATH') || die('No direct script access allowed');

use Abstracted\Api;

class ResetPassword extends Api {

    private $token;
    private $password;
    private $confirmPassword;

    function __construct() {
        parent::__construct();
    }

    function index() {
        $this->requestType = $this->requestTypePost;
        if (!$this->validateRequestType()) {
            return;
        }
        if (value_post('newpassword') && value_post('passhashcode')) {
            $this->newpassword = value_post('newpassword');
            $this->passhashcode = value_post('passhashcode');
        } else {
            $this->statusCode = 400;
            $this->message = "Password cannot be empty";
            return;
        }

        $query = "SELECT * FROM `reset_password_history` WHERE `token`=?";

        $info = dbGetRow(dbGetConnection()->rawQuery($query, [$this->passhashcode]));

        if ($info === false) {
            $this->message = 'Invalid Token';
            $this->statusCode = 403;
            return;
        }

        $uid = $info['user_id'];
        $created_date = $info['created_at'];
        $visited = $info['visited'];
        $expirey_duration = $info['password_reset_link_age'];
        $timestamp1 = strtotime($created_date);
        $timestamp2 = time();
        $hour = abs($timestamp2 - $timestamp1) / (60 * 60);

        if ($visited == 1) {
            $this->statusCode = 400;
            $this->message = "Token has already used";
            return;
        } else if ($hour > $expirey_duration) {
            $this->statusCode = 400;
            $this->message = "Your token has Expired";
            return;
        } else {
            $query = "SELECT * FROM user WHERE  user.id=?";
            $info = dbGetRow(dbGetConnection()->rawQuery($query, [$uid]));
            if ($info === false) {
                $this->message = 'User Not found';
                $this->statusCode = 403;
                return;
            }
            $lock = $info['is_lock'];
            if ($lock == 1) {

                $data = array(
                    'visited' => '1'
                );

                $updateresult = dbGetConnection()
                        ->where('token', $this->passhashcode)
                        ->update('reset_password_history', $data);
                if ($updateresult === false) {
                    $this->message = 'Not Execute update Command';
                    $this->statusCode = 403;
                    return;
                }

                $new_pass = $this->newpassword;
                $new_pass_cypt = password_hash($new_pass, PASSWORD_DEFAULT);

                $data = array(
                    'password' => $new_pass_cypt,
                    'is_lock' => '0'
                );
                $updateresult = dbGetConnection()
                        ->where('id', $uid)
                        ->update('user', $data);
                if ($updateresult === false) {
                    $this->message = 'Not Execute update Command';
                    $this->statusCode = 403;
                    return;
                }

                $this->statusCode = 200;
                $this->message = "Please login again with new password";
                $this->response = [
                    'redirect_url' => base_url('index.php')
                ];
                return;
            } else {
                $this->statusCode = 400;
                $this->message = "Your account is not lock";
                return;
            }
        }
    }

}
