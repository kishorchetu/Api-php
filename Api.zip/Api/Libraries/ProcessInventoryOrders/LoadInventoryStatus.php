<?php

namespace Libraries\ProcessInventoryOrders;

defined('BASEPATH') || die('No direct script access allowed');

use Abstracted\Api;

class LoadInventoryStatus extends Api {

    function __construct() {
        parent::__construct();
    }

    function index() {
        $this->requestType = $this->requestTypeGet;
        if (!$this->validateRequestType()) {
            return;
        }
        $this->loadInventoryStatus();
    }

    private function loadInventoryStatus() {
        $sql="SELECT * FROM `inventory_process` ORDER BY `id` DESC LIMIT 1";
        
        $info = dbGetResultArray(dbGetConnection()->rawQuery($sql));
            if ($info === false) {
                $this->message = 'You are not authorized to access';
                $this->statusCode = 403;
                return;
            }
            
        if (count($info)>0){
            foreach ($info as $value){
                $status=$value['status'];
            }
            if($status==0){
                $msg="Inventory in Process Order Saved in Queue";
            }else{
                $msg="Submit Your Order Below";
            }
        }else{
            $status=1;
            $msg="Submit Your Order Below";
        }
        
        $this->statusCode = 200;
        $this->message = $msg;
        $this->response = [
                'status' => $status
            ];
        return;
    }

}
