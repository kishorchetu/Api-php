<?php

namespace Libraries\ProcessInventoryOrders;

defined('BASEPATH') || die('No direct script access allowed');

use Abstracted\Api;

class ApproveOrder extends Api {

    private $order_ids;
    private $errors = [];

    function __construct() {
        parent::__construct();
    }

    function index() {
        $this->requestType = $this->requestTypePost;
        if (!$this->validateRequestType()) {
            return;
        }
        $this->order_ids = json_decode(value_post('orderids'), true);

        if (!$this->validateFormData()) {
            $this->statusCode = 403;
            $this->message = 'There is some issue in order(s)';
            $this->response = $this->errors;
            return;
        }

        foreach ($this->order_ids as $order_id) {
            $this->processApproveOrder($order_id);
        }
        $this->response = [
            'title' => 'Order Approve In Process',
            'message' => 'Order Submition in process'
        ];
        return;
    }

    private function validateFormData() {
        if (count($this->order_ids) === 0) {
            $this->errors[] = 'Please select Orders';
        }

        if (count($this->order_ids) === 1) {
            $tableids = dbGetResultArray(dbGetConnection()->where('commit_at', NULL, 'IS')->where('status', Null, 'IS')->where('id', $this->order_ids, 'IN')->get('temporory_orders', '1', 'id'));
        }

        if (count($this->order_ids) > 1) {
            $tableids = dbGetResultArray(dbGetConnection()->where('commit_at', NULL, 'IS')->where('status', Null, 'IS')->get('temporory_orders', null, 'id'));
        }

        if (count($tableids) === 0) {
            $this->errors[] = "Orders Not found in Table";
        }

        sort($tableids);
        sort($this->order_ids);

        if ($tableids != $this->order_ids) {
            $this->errors[] = "There are some update in Inventory Table";
        }

        if (checkIfInventoryProcessIsRunning()) {
            $this->errors[] = "Please stop inventory process to approve order";
        }

        return count($this->errors) === 0;
    }

    private function processApproveOrder($order_id) {
        $orderinfo = dbGetCell(dbGetConnection()->where('id', $order_id)->get('temporory_orders', 1, 'orderinfo'));
        if (!$orderinfo) {
            $this->message = 'Order already being Processed';
            $this->statusCode = 403;
            return;
        }
        $order_data = json_decode($orderinfo, true);
        if (!saveQueueJob('process-order', $order_data)) {
            $this->message = 'Order Not approve Please try again';
            $this->statusCode = 403;
            return;
        }

        $this->updateStatusOfApproveOrder($order_id);
    }

    private function updateStatusOfApproveOrder($order_id) {
        $data = array(
            'status' => 'approved',
            'commit_at' => date("Y-m-d H:i:s", time())
        );

        $updateresult = dbGetConnection()
                ->where('id', $order_id)
                ->update('temporory_orders', $data);
        if (!$updateresult) {
            $this->message = 'Order Not approved';
            $this->statusCode = 403;
            return;
        }
    }

}
