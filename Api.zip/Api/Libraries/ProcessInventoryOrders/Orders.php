<?php

namespace Libraries\ProcessInventoryOrders;

defined('BASEPATH') || die('No direct script access allowed');

use Abstracted\Api;

class Orders extends Api {

    function __construct() {
        parent::__construct();
    }

    function index() {
        $this->requestType = $this->requestTypeGet;
        if (!$this->validateRequestType()) {
            return;
        }
        $this->setOrders();
    }

    private function setOrders() {
        $Datainfo = dbGetResultArray(dbGetConnection()->where('commit_at', NULL, 'IS')->get('temporory_orders'));
        $data = array();
        $vendor_names = [];
        foreach ($Datainfo as $key => $val) {

            $json_orderinfo = json_decode($val['orderinfo'], true);
            $customer_id = $json_orderinfo['customer_id'];
            $total_customer_price = $json_orderinfo['total_customer_price'];
            $total_warehouse_price = $json_orderinfo['total_warehouse_price'];
            if (!isset($vendor_names[$customer_id])) {
                $sql = "SELECT o_company as vendorname FROM  customer as t1 join owner as t2 on t2.id=t1.owner_id where t1.id=?";
                $vendor_names[$customer_id] = dbGetCell(dbGetConnection()->rawQuery($sql, [$customer_id]));
            }

            $data[] = array(
                'order_id' => $val['id'],
                'vendorname' => $vendor_names[$customer_id],
                'orderdate' => $val['created_at'],
                'custtotal' => $total_customer_price,
                'whtotal' => $total_warehouse_price
            );
        }
        if (!count($data)) {
            $this->message = 'No order was found';
            return;
        }
        $this->response = $data;
    }

}
