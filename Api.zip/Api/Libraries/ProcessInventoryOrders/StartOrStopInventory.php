<?php

namespace Libraries\ProcessInventoryOrders;

defined('BASEPATH') || die('No direct script access allowed');

use Abstracted\Api;

class StartOrStopInventory extends Api {

    function __construct() {
        parent::__construct();
    }

    function index() {
        $this->requestType = $this->requestTypeGet;
        if (!$this->validateRequestType()) {
            return;
        }
        $this->startOrStopInventory();
    }

    private function startOrStopInventory() {

        $sql = "SELECT * FROM `inventory_process` ORDER BY `id` DESC LIMIT 1";

        $info = dbGetResultArray(dbGetConnection()->rawQuery($sql));
        if ($info === false) {
            $this->message = 'You are not authorized to access';
            $this->statusCode = 403;
            return;
        }

        if (count($info) > 0) {
            foreach ($info as $value) {
                $status = $value['status'];
                $inventory_id = $value['id'];
            }
            if ($status == 0) {
                $data = array(
                    'inventory_end_time' => date("Y-m-d H:i:s", time()),
                    'status' => '1'
                );

                $updateresult = dbGetConnection()
                        ->where('id', $inventory_id)
                        ->update('inventory_process', $data);
                if ($updateresult === false) {
                    $this->message = 'Database error on update';
                    $this->statusCode = 403;
                    return;
                }
            } else {
                $lastordnum = $this->getlastordernumber();
                $data = array(
                    'inventory_start_time' => date("Y-m-d H:i:s", time()),
                    'last_ordnum' => $lastordnum
                );

                $resultid = dbInsert('inventory_process', $data);
                if (!$resultid) {
                    $this->statusCode = 500;
                    $this->message = 'Database error on insert';
                    return;
                }
            }
        } else {
            //need to insert
            $lastordnum = $this->getlastordernumber();
            $data = array(
                'inventory_start_time' => date("Y-m-d H:i:s", time()),
                'last_ordnum' => $lastordnum
            );

            $resultid = dbInsert('inventory_process', $data);
            if (!$resultid) {
                $this->statusCode = 500;
                $this->message = 'Database error on insert';
                return;
            }
        }

        $this->loadInventorystatus();
    }

    private function loadInventoryStatus() {
        $sql = "SELECT * FROM `inventory_process` ORDER BY `id` DESC LIMIT 1";

        $info = dbGetResultArray(dbGetConnection()->rawQuery($sql));
        if ($info === false) {
            $this->message = 'You are not authorized to access';
            $this->statusCode = 403;
            return;
        }

        if (count($info) > 0) {
            foreach ($info as $value) {
                $status = $value['status'];
            }
            if ($status == 0) {
                $msg = "Inventory in Process Order Saved in Queue";
            } else {
                $msg = "Submit Your Order Below";
            }
        } else {
            $status = 1;
            $msg = "Submit Your Order Below";
        }

        $this->statusCode = 200;
        $this->message = $msg;
        $this->response = [
            'status' => $status
        ];
        return;
    }

    private function getlastordernumber() {

        $sql = "SELECT ordnum FROM `orderinfo` ORDER BY `id` DESC LIMIT 1";

        $info = dbGetRow(dbGetConnection()->rawQuery($sql));
        if ($info === false) {
            $this->message = 'You are not authorized to access';
            $this->statusCode = 403;
            return;
        }

        return $info['ordnum'];
    }

}
