<?php

namespace Libraries\ProcessInventoryOrders;

defined('BASEPATH') || die('No direct script access allowed');

use Abstracted\Api;

class ApproveAllOrder extends Api {
    private $cleanExtraData;
    private $cleanData;
    function __construct() {
        parent::__construct();
    }

    function index() {
        $this->requestType = $this->requestTypePost;
        if (!$this->validateRequestType()) {
            return;
        }
                
        $status=$this->loadInventoryStatus();
        if($status==0){
                $this->statusCode = 403;
                $this->message = "Please stop inventory process to approve orders";
                return;
        }
            
        $this->approveAllOrders();
            
        
    }

    private function approveAllOrders(){
       
        $dataInfo = dbGetResultArray(dbGetConnection()->where('commit_at',NULL, 'IS')->where('status',Null,'IS')->get('temporory_orders'));
        foreach ($dataInfo as $key => $val) {

            $orderId = $val['id'];  
            $sql="select warehouse_id,orderinfo from temporory_orders where id=?";    
            $orderInfo = dbGetRow(dbGetConnection()->rawQuery($sql,[$orderId]));
                if ($orderInfo === false) {
                    $this->message = 'Database error occured';
                    $this->statusCode = 403;
                    return;
                }
            $orders = json_decode($orderInfo['orderinfo'],true);
            $warehouse_id = json_decode($orderInfo['warehouse_id'],true);
            $this->cleanData = $orders['data'];
            $this->cleanExtraData = $orders['extraData'];

//            $orderNumber = getUniqueOrderNumber();//Change logic recommended by client
//            load('ProcessOrderRequest')->submitOrders($this->cleanExtraData,$this->cleanData,$orderNumber,$warehouse_id);

            $this->updateStatusOfApproveOrder($orderId);
            
        }
        
        $this->response = [
            'message' => 'All Orders Approved and Emails Sent'
        ];
        return;
        
    }
    
    private function loadInventoryStatus(){
        
        $sql="SELECT * FROM `inventory_process` ORDER BY `id` DESC LIMIT 1";
        
        $info = dbGetResultArray(dbGetConnection()->rawQuery($sql));
            if ($info === false) {
                $this->message = 'You are not authorized to access';
                $this->statusCode = 403;
                return;
            }
            
        if (count($info)>0){
            foreach ($info as $value){
                $status=$value['status'];
            }
        }else{
            $status=1;
        }
        
        return $status;
    }
    
    private function updateStatusOfApproveOrder($custInfoId){
        $data=array(
            'status' => 'approved',
            'commit_at'=>date("Y-m-d H:i:s", time())
        );
        
        $updateresult = dbGetConnection()
                                    ->where('id', $custInfoId)
                                    ->update('temporory_orders', $data);
            if ($updateresult === false) {
                $this->message = 'Database error occured';
                $this->statusCode = 403;
                return;
            }
    }

}
