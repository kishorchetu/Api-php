<?php

namespace Libraries\ProcessInventoryOrders;

defined('BASEPATH') || die('No direct script access allowed');

use Abstracted\Api;

class CancelALLOrder extends Api {
    function __construct() {
        parent::__construct();
    }

    function index() {
        $this->requestType = $this->requestTypePost;
        if (!$this->validateRequestType()) {
            return;
        }
            $this->cancelAllOrders();
    }

    private function cancelAllOrders(){
        $dataInfo = dbGetResultArray(dbGetConnection()->where('commit_at',NULL, 'IS')->where('status',Null,'IS')->get('temporory_orders'));
        foreach ($dataInfo as $key => $val) {

        $orderId = $val['id'];      
                
        $data=array(
            'status'=>'rejected',
            'commit_at'=>date("Y-m-d H:i:s", time())
        );
        
        $updateresult = dbGetConnection()
                                    ->where('id', $orderId)
                                    ->update('temporory_orders', $data);
            if ($updateresult === false) {
                $this->message = 'Database error occured';
                $this->statusCode = 403;
                return;
            }
        }
        
        $this->response = [
            'message' => 'Cancel All Orders'
        ];
        return;    
    }

}
