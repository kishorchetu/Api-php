<?php

namespace Libraries\Users;

defined('BASEPATH') || die('No direct script access allowed');

use Abstracted\Api;

class Suspend extends Api {

    private $userId;
    private $suspend;
    private $error = [];

    function __construct() {
        parent::__construct();
    }

    function index() {
        $this->requestType = $this->requestTypePost;
        if (!$this->validateRequestType()) {
            return;
        }
        if (!$this->validateFormData()) {
            $this->statusCode = 400;
            $this->response = $this->error;
            return;
        }
        $this->updateUser();
    }

    private function setFormData() {
        $this->userId = value_post('user_id');
        $this->suspend = intval(value_post('suspend'));
    }

    private function validateFormData() {
        $this->setFormData();
        if (!is_numeric($this->userId) || dbGetCell(dbGetConnection()->where('id', $this->userId)->get('user')) === false) {
            $this->error[] = 'Invalid user selected to ' . ($this->suspend === 1 ? 'suspend' : 'unsuspend');
        }
        return count($this->error) === 0;
    }

    private function updateUser() {
        $update = [
            'is_suspend' => $this->suspend,
            'modified_at' => date(DATE_FORMAT_TIME_STAMP)
        ];
        if (!dbGetConnection()->where('id', $this->userId)->update('user', $update)) {
            $this->statusCode = 503;
            $this->message = 'Somthing went wrong with database while ' . ($this->suspend === 1 ? 'suspending' : 'unsuspending') . ' user\s account';
            return;
        }
        $this->message = 'User\'s account ' . ($this->suspend === 1 ? 'suspended' : 'unsuspended') . ' successfully';
    }

}
