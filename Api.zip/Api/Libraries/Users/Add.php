<?php

namespace Libraries\Users;

defined('BASEPATH') || die('No direct script access allowed');

use Abstracted\Api;

class Add extends Api {

    private $errors = [];
    private $role;
    private $userName;
    private $firstName;
    private $lastName;
    private $email;
    private $warehouese;
    private $company;

    function __construct() {
        parent::__construct();
    }

    function index() {
        $this->requestType = $this->requestTypePost;
        if (!$this->validateRequestType()) {
            return;
        }
        if (!$this->validateFormData()) {
            $this->message = 'Invalid form data';
            $this->statusCode = 400;
            $this->response = $this->errors;
            return;
        }
        $this->saveUser();
    }

    private function setFormData() {

        $this->role = value_post('role');
        $this->userName = value_post('username');
        $this->firstName = value_post('firstname');
        $this->lastName = value_post('lastname');
        $this->email = value_post('email');
        $this->warehouese = value_post('wharehouse');
        $this->company = intval(value_post('company'));
    }

    private function validateFormData() {
        $this->setFormData();
        if (empty($this->role)) {
            $this->errors[] = 'Role is required';
        }
        if (empty($this->warehouese)) {
            $this->errors[] = 'Please select some valid warehouse';
        }
        if (empty($this->company)) {
            $this->errors[] = 'Please select some valid company';
        }
        if (empty($this->userName)) {
            $this->errors[] = 'User name is required';
        } elseif (!preg_match("/^[a-zA-Z ]*$/", $this->userName)) {
            $this->errors[] = 'User name must be alphabetic';
        }
        if (empty($this->firstName)) {
            $this->errors[] = 'First name is required';
        } elseif (!preg_match("/^[a-zA-Z ]*$/", $this->firstName)) {
            $this->errors[] = 'First name must be alphabetic';
        }
        if (!empty($this->lastName) && !preg_match("/^[a-zA-Z ]*$/", $this->lastName)) {
            $this->errors[] = 'Last name must be alphabetic';
        }
        if (empty($this->email)) {
            $this->errors[] = 'Email is required';
        } elseif (!empty($this->email) && !filter_var($this->email, FILTER_VALIDATE_EMAIL)) {
            $this->errors[] = 'Email format is not valid';
        }

        if (!empty($this->email) && dbGetCell(dbGetConnection()->where('email', $this->email)->get('user', 1, 'id')) !== false) {
            $this->errors[] = 'This email is already exists';
        }

        return count($this->errors) === 0;
    }

    private function saveUser() {
        $password = generatePassword(12);

        $userData = [
            'username' => $this->userName,
            'firstname' => $this->firstName,
            'lastname' => $this->lastName,
            'password' => password_hash($password, PASSWORD_DEFAULT),
            'email' => $this->email,
            'role' => $this->role,
            'warehouse' => $this->warehouese,
            'company' => $this->company,
            'owner_id' => $this->getOwnerId($this->company),
            'is_lock' => 0,
            'is_suspend' => 0,
            'deleted_at' => null,
            'modified_at' => date(DATE_FORMAT_TIME_STAMP),
            'created_at' => date(DATE_FORMAT_TIME_STAMP)
        ];

        $inserted = dbInsert('user', $userData);

        if (!is_numeric($inserted)) {
            $this->statusCode = 500;
            $this->message = 'Somthing went wrong while added new user' . $inserted;
            return;
        }
        $this->message = 'New user added successfuly';
        $email_data = [
            'from' => 'GreenlandOnAWS',
            'fromName' => 'Greenland AWS',
            'subject' => 'Your account created successfuly',
            'body' => $password,
            'email_to' => $this->email
        ];
//        sendingMail($email_data);
    }

    private function getOwnerId($companyid) {
        $ownerid = dbGetCell(dbGetConnection()->where('id', $companyid)->get('company', 1, 'owner_id'));
        if (!$ownerid) {
            $this->statusCode = 500;
            $this->message = 'Orner Not found of Company';
            return;
        }
        return $ownerid;
    }

}
