<?php

namespace Libraries\Users;

defined('BASEPATH') || die('No direct script access allowed');

use Abstracted\Api;

class Update extends Api {

    private $errors = [];
    private $userId;
    private $warehouese;
    private $company;
    private $role;
    private $userName;
    private $firstName;
    private $lastName;
    private $email;

    function __construct() {
        parent::__construct();
    }

    function index() {
        $this->requestType = $this->requestTypePost;
        if (!$this->validateRequestType()) {
            return;
        }
        if (!$this->validateFormData()) {
            $this->message = 'Invalid form data';
            $this->statusCode = 400;
            $this->response = $this->errors;
            return;
        }
        $this->editUser();
    }

    private function setFormData() {
        $this->userId = intval(value_post('userid'));
        $this->warehouese = join(',', remove_array_values(array_map(function($item) {
                            return intval(trim($item));
                        }, explode(',', value_post('wharehouse'))), 0));
        $this->company = intval(value_post('company'));
        $this->role = join(',', remove_array_values(array_map(function($item) {
                            return intval(trim($item));
                        }, explode(',', value_post('role'))), 0));
        $this->userName = value_post('username');
        $this->firstName = value_post('firstname');
        $this->lastName = value_post('lastname');
        $this->email = value_post('email');
    }

    private function validateFormData() {
        $this->setFormData();
        if (empty($this->userId) || dbGetCell(dbGetConnection()->where('id', $this->userId)->get('user', 1, 'id')) === false) {
            $this->errors[] = 'Please select any valid user';
        }
        if (empty($this->role)) {
            $this->errors[] = 'Role is required';
        }
        if (empty($this->warehouese)) {
            $this->errors[] = 'Please select some valid warehouse';
        }
        if (empty($this->company)) {
            $this->errors[] = 'Please select some valid company';
        }
        if (empty($this->userName)) {
            $this->errors[] = 'User name is required';
        } elseif (!preg_match("/^[a-zA-Z ]*$/", $this->userName)) {
            $this->errors[] = 'User name must be alphabetic';
        }
        if (empty($this->firstName)) {
            $this->errors[] = 'First name is required';
        } elseif (!preg_match("/^[a-zA-Z ]*$/", $this->firstName)) {
            $this->errors[] = 'First name must be alphabetic';
        }
        if (!empty($this->lastName) && !preg_match("/^[a-zA-Z ]*$/", $this->lastName)) {
            $this->errors[] = 'Last name must be alphabetic';
        }
        if (empty($this->email)) {
            $this->errors[] = 'Email is required';
        } elseif (!empty($this->email) && !filter_var($this->email, FILTER_VALIDATE_EMAIL)) {
            $this->errors[] = 'Email format is not valid';
        } else {
            $db = dbGetConnection()
                    ->where('email', $this->email)
                    ->where('id', $this->userId, '<>')
                    ->get('user', 1, 'id');
            $userId = intval(dbGetCell($db));
            if ($userId !== 0) {
                $this->errors[] = 'This email is already exists';
            }
        }
        return count($this->errors) === 0;
    }

    private function editUser() {
        $userData = [
            'username' => $this->userName,
            'firstname' => $this->firstName,
            'lastname' => $this->lastName,
            'email' => $this->email,
            'role' => $this->role,
            'warehouse' => $this->warehouese,
            'company' => $this->company,
            'modified_at' => date(DATE_FORMAT_TIME_STAMP)
        ];
        if (!dbGetConnection()->where('id', $this->userId)->update('user', $userData)) {
            $this->statusCode = 500;
            $this->message = 'Somthing went wrong while updating user';
            return;
        }
        $this->message = 'User updated successfuly';
    }

}
