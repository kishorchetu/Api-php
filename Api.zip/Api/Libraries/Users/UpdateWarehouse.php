<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace Libraries\Users;

defined('BASEPATH') || die('No direct script access allowed');

use Abstracted\Api;

class UpdateWarehouse extends Api {

    private $errors = [];
    private $userId;
    private $warehoueseId;

    function __construct() {
        parent::__construct();
    }

    function index() {
        $this->requestType = $this->requestTypePost;
        if (!$this->validateRequestType()) {
            return;
        }
        if (!$this->validateFormData()) {
            $this->message = 'Invalid data in request';
            $this->statusCode = 400;
            $this->response = $this->errors;
            return;
        }
        $updated = load('UpdateUserWarehouse')->update($this->warehoueseId, $this->userId);
        if (!is_array($updated)) {
            $this->message = $updated;
            $this->statusCode = 400;
            return;
        }
        $this->message = 'Warehouse updated to ' . $updated['name'];
    }

    private function setFormData() {
        $this->warehoueseId = intval(value_post('warehouse_id'));
        $this->userId = intval(value_post('user_id', value_session('uid')));
    }

    private function validateFormData() {
        $this->setFormData();
        if (empty($this->userId) || dbGetCell(dbGetConnection()->where('id', $this->userId)->get('user', 1, 'id')) === false) {
            $this->errors[] = 'Invalid user id provided';
        }
        $query = 'SELECT id FROM user '
                . 'WHERE id=? '
                . 'AND FIND_IN_SET(?, warehouse) <> 0';
        if (empty($this->warehoueseId) || dbGetCell(dbGetConnection()->rawQuery($query, [$this->userId, $this->warehoueseId])) === false) {
            $this->errors[] = 'Invalid warehouse id provided';
        }
        return count($this->errors) === 0;
    }

}
