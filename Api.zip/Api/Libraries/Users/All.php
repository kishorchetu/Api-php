<?php

namespace Libraries\Users;

defined('BASEPATH') || die('No direct script access allowed');

use Abstracted\Api;

class All extends Api {

    function __construct() {
        parent::__construct();
    }

    function index() {
        $this->requestType = $this->requestTypeGet;
        if (!$this->validateRequestType()) {
            return;
        }
        $payload = null;
        $user_id = intval(value_get('user_id'));


        $roleQuery = 'SELECT user.id, user.username,user.firstname,'
                . 'user.lastname, user.email, '
                . 'user.role as roleIds, '
                . 'GROUP_CONCAT(roles.name separator ",") as roleNames,'
                . 'user.is_lock as locked,'
                . 'user.is_suspend as suspended,warehouse,company '
                . 'FROM user '
                . 'INNER JOIN roles ON FIND_IN_SET(roles.id, user.role) <> 0 '
                . 'WHERE user.deleted_at is NULL ';
        if ($user_id !== 0) {
            $payload = [$user_id];
            $roleQuery .= 'AND user.id = ?';
        }
        if ($user_id === 0) {
            $roleQuery .= ' GROUP BY user.id';
        }
        
        $users = dbGetResultArray(dbGetConnection()->rawQuery($roleQuery, $payload));
        if (count($users) === 0) {
            $this->statusCode = 403;
            $this->message = 'There is no user in system';
            return;
        }
        $explode = function($user, $key) {
            return $user[$key] ? explode(',', $user[$key]) : [];
        };
        foreach ($users as $index => $user) {
            $users[$index]['roleIds'] = $explode($user, 'roleIds');
            $users[$index]['roleNames'] = $explode($user, 'roleNames');
            $users[$index]['warehouse'] = $explode($user, 'warehouse');
        }
        $this->response = $users;
    }

}
