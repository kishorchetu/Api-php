<?php

namespace Libraries\Users;

defined('BASEPATH') || die('No direct script access allowed');

use Abstracted\Api;

class Lock extends Api {

    private $userId;
    private $lock;
    private $error = [];

    function __construct() {
        parent::__construct();
    }

    function index() {
        $this->requestType = $this->requestTypePost;
        if (!$this->validateRequestType()) {
            return;
        }
        if (!$this->validateFormData()) {
            $this->statusCode = 400;
            $this->response = $this->error;
            return;
        }
        $this->updateUser();
    }

    private function setFormData() {
        $this->userId = value_post('user_id');
        $this->lock = intval(value_post('lock'));
    }

    private function validateFormData() {
        $this->setFormData();
        if (!is_numeric($this->userId) || dbGetCell(dbGetConnection()->where('id', $this->userId)->get('user')) === false) {
            $this->error[] = 'Invalid user selected to ' . ($this->lock === 1 ? 'lock' : 'unlock');
        }
        return count($this->error) === 0;
    }

    private function updateUser() {
        $update=[
            'is_lock' => $this->lock,
            'modified_at'=>date(DATE_FORMAT_TIME_STAMP)
                ];
        if (!dbGetConnection()->where('id', $this->userId)->update('user', $update)) {
            $this->statusCode = 503;
            $this->message = 'Somthing went wrong with database while ' . ($this->lock === 1 ? 'locking' : 'unlocking') . ' user\s account';
            return;
        }
        $this->message = 'User\'s account ' . ($this->lock === 1 ? 'locked' : 'unlocked') . ' successfully';
    }

}
