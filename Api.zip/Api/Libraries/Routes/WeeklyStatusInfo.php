<?php

namespace Libraries\Routes;

defined('BASEPATH') || die('No direct script access allowed');

use Abstracted\Api;

class WeeklyStatusInfo extends Api {

    function __construct() {
        parent::__construct();
    }

    function index() {
        $this->requestType = $this->requestTypeGet;
        if (!$this->validateRequestType()) {
            return;
        }
        if (!value_session('ownerid')) {
            $this->message = 'Not Authorized To Access Weekly Status';
            $this->statusCode = 403;
            return;
        }
        $this->getWeeklyStatusTable();
    }

    private function getWeeklyStatusTable() {
        $ownid = value_session('ownerid');
        $gqoh = $this->getQuantityOnHand();
        if (empty($gqoh)) {
            $this->message = 'Not Found In Quantity On Hand';
            $this->statusCode = 403;
            return;
        }
        $currentTime = time();
        $week = 1;
        $timeFrame = generate_timeframe($week); //predefind function for client
        $weekStart = $timeFrame['current_start'];
        $string = '';
        $tm = localtime($currentTime, TRUE);
        $dow = $tm['tm_wday'];
        $dayStart = $weekStart;
        $dayEnd = $weekStart + ($dow * 86400) + 86400;
//        $dayStart = 1380639577; //tetsing
//        $dayEnd = 1610369770; //testing

        $check_order = $this->checkOrderinfoForOwner($dayStart, $dayEnd, $ownid);
        if (empty($check_order)) {
            $this->message = 'Not Found any order for owner';
            $this->statusCode = 403;
            return;
        }

        $results = $this->getOrderCasesandSoldCases($dayStart, $dayEnd, $ownid);
        if (empty($results)) {
            $this->message = 'Not Found any order or sold Cases for owner';
            $this->statusCode = 403;
            return;
        }

        foreach ($results as $val) {
            $string .= "'" . $val['customer_id'] . "',";
        }
        $string = rtrim($string, ',');

        $query1 = "SELECT DISTINCT (id),(custname), (custaddress) FROM customer
                    WHERE owner_id='$ownid' 
                    AND active_cust='1' 
                    AND id not in($string)";
        $customers = dbGetResultArray(dbGetConnection()->rawQuery($query1));

        $this->response = [
            'weeklytable' => view('formats.weekly_table', ['customers' => $customers, 'gqoh' => $gqoh, 'check_order' => $check_order, 'results' => $results])
        ];
    }

    private function getQuantityOnHand() {
        $sql = "SELECT t1.id
		,(IFNULL(t5.qty_inventory, 0) + IFNULL(t2.sumP, 0) - IFNULL(t4.sumM, 0)) AS 'QOH'
		FROM
		(
			(
				SELECT flavor.id
				FROM flavor
				LEFT JOIN products ON flavor.pfamily = products.family
				WHERE active_flavor = '1' or active_flavor='0'
				ORDER BY family ASC, priority ASC
			) t1
			LEFT JOIN
			(
				SELECT p_orders.f_id, sum(p_orders.qty_rcvd) AS 'sumP'
				FROM p_orders
				LEFT JOIN inventory ON p_orders.f_id = inventory.f_id
				WHERE u_date_rcvd > IFNULL(inventory.inventorynum,'0000000000')
				GROUP BY inventory.f_id
			) t2
			ON t1.id = t2.f_id
			LEFT JOIN
			(
				SELECT inventory.f_id, sum(orders.quantity) AS 'sumM'
				FROM orders
				LEFT JOIN inventory ON orders.f_id = inventory.f_id
				WHERE orders.ordnum > IFNULL(inventory.inventorynum,'0000000000')
				GROUP BY inventory.f_id
			) t4
			ON t1.id = t4.f_id
			LEFT JOIN
			(
				SELECT inventory.f_id, inventory.qty_inventory
				FROM inventory				
			) t5
			ON t1.id = t5.f_id
		)";


        return dbGetResultArray(dbGetConnection()->rawQuery($sql));
    }

    private function checkOrderinfoForOwner($dayStart, $dayEnd, $ownid) {

        $sql = " select count(*) as co 
        from orderinfo 
        where 
                (orderinfo.ordnum between $dayStart	
                and $dayEnd)
        AND orderinfo.owner_id ='$ownid'"
        ;

        return dbGetResultArray(dbGetConnection()->rawQuery($sql));
    }

    private function getOrderCasesandSoldCases($dayStart, $dayEnd, $ownid) {
        $sql = "Select 
		T1.*
		,T2.ord_cases
		,T2.sold_cases
		from
		(
			(
				Select
				orderinfo.customer_id
				,custname
				,custaddress
				,orderinfo.owner_id
				,ordnum
				,orddate	
				,ordwhtotal
				,ord_pick
				,ord_pick_time
				,ord_update
				,ord_update_time
				  ,case 
					when ordcomment is null or ordcomment = '' 
					then 'None Provided' 
					else ordcomment end as ordcomment      
				,owner.owner 	
				from orderinfo 
				left join owner on orderinfo.owner_id=owner.id
				left join customer on orderinfo.customer_id=customer.id
				where 
					(orderinfo.ordnum between $dayStart	
					and $dayEnd)
				AND orderinfo.owner_id =" . $ownid . "
				order by owner_id asc, orddate desc,ordnum desc
			) T1
		
			left join
			(
				select
				orders.ordnum
				,sum(quantity) as 'sold_cases'
				,sum(ord_qty) as 'ord_cases'
				from orders
				left join orderinfo on orders.ordnum=orderinfo.ordnum
				where (orderinfo.ordnum between $dayStart	
					and $dayEnd)
				group by orders.ordnum
			)T2
			on T1.ordnum=T2.ordnum
		)";

        return dbGetResultArray(dbGetConnection()->rawQuery($sql));
    }

}
