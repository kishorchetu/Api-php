<?php

namespace Libraries\Routes;

defined('BASEPATH') || die('No direct script access allowed');

use Abstracted\Api;

class OrdersBilled extends Api {

    function __construct() {
        parent::__construct();
    }

    function index() {
        $this->requestType = $this->requestTypeGet;
        if (!$this->validateRequestType()) {
            return;
        }
        $this->getBilledTable();
    }

    private function getBilledTable() {
        $ownid = value_session('ownerid');
        $data = array();

        $query = "Select T1.*, T2.ord_cases, T2.sold_cases, T3.owner from orderinfo AS T1
                    left join owner AS T3 on T1.owner_id = T3.id
                    left join 
                    (
                            SELECT
                            ordnum
                            ,sum(quantity) as 'sold_cases'
                            ,sum(ord_qty) as 'ord_cases'
                            FROM orders
                            group by ordnum
                    ) AS T2
                     on T1.ordnum = T2.ordnum
                    WHERE billing_lock='1'
                    AND T1.ordcomment NOT LIKE 'RMA ITEM%'
                    AND T1.owner_id = '" . $ownid . "'
                    AND T1.orddate>='171231'
                    ORDER BY T1.id DESC";


        $results = dbGetResultArray(dbGetConnection()->rawQuery($query));
        if (empty($results)) {
            $this->message = 'Not Found Orders Picked';
            return;
        }

        foreach ($results as $val) {
            $data[] = array(
                'time-ordered' => date('l, M-d H:i', $val['ordnum']),
                'ordnum' => $val['ordnum'],
                'owner-name' => $val['owner'],
                'comments' => $val['ordcomment'],
                'amt-due' => number_format($val['ordwhtotal'], 2),
                'qty-ord' => $val['ord_cases'],
                'qty-sold' => $val['sold_cases']
            );
        }

        $this->response = $data;
    }

}
