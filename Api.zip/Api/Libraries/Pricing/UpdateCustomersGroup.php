<?php

namespace Libraries\Pricing;

defined('BASEPATH') || die('No direct script access allowed');

use Abstracted\Api;

class UpdateCustomersGroup extends Api {

    private $Cust_Ids = [];
    private $Remove_Ids = [];
    private $GroupName;
    private $GroupId;

    function __construct() {
        parent::__construct();
    }

    function index() {
        $this->requestType = $this->requestTypePost;
        if (!$this->validateRequestType()) {
            return;
        }
        $this->GroupName = value_post('GroupName');
        $this->Cust_Ids = remove_array_values(array_map(function($item) {
                    return intval(trim($item));
                }, value_post('customerIds')), 0, true);
        sort($this->Cust_Ids);

        $this->Remove_Ids = remove_array_values(array_map(function($item) {
                    return intval(trim($item));
                }, value_post('uncheckIds')), 0, true);
        sort($this->Remove_Ids);
        $this->GroupId = value_post('groupID');
        if (empty($this->Cust_Ids)) {
            $this->statusCode = 400;
            $this->message = "Please Select Cutomers for group";
            return;
        }

        if (empty($this->GroupId)) {
            $this->statusCode = 400;
            $this->message = "Please Select group for Edit Customers";
            return;
        }
        $this->saveCustomersToGroup();
    }

    private function saveCustomersToGroup() {

        if (empty($this->GroupName)) {
            $this->statusCode = 400;
            $this->message = "Please Provide Group Name";
            return;
        }
        $str = '';
        sort($this->Cust_Ids);

        foreach ($this->Cust_Ids as $key => $val) {
            $this->removeCustomerInExistingGroup($this->GroupId, $val);
            $str .= $val . ',';
        }

        $resultids = dbGetCell(dbGetConnection()->where('group_id', $this->GroupId)->get('customer_group_mapping', 1, 'customers_id'));
        if (!empty($resultids)) {
            $str = $this->extractCustomersIdsFromGroup($resultids);
        }

        $data = array(
            'customers_id' => rtrim($str, ','),
            'modified_at' => date("Y-m-d H:i:s", time())
        );
        $updateresult = dbGetConnection()
                ->where('group_id', $this->GroupId)
                ->update('customer_group_mapping', $data);
        if ($updateresult === false) {
            $this->message = 'Update Error Encounted in Customer pricing mappping';
            $this->statusCode = 403;
            return;
        }
        $this->response = [
            'custid' => rtrim($str, ',')
        ];
        return;
    }

    private function extractCustomersIdsFromGroup($resultids) {
        $resultids = explode(",", $resultids);
        foreach ($resultids as $key => $val) {
            if (in_array($val, $this->Remove_Ids)) {
                unset($resultids[$key]);
            }
        }

        foreach ($this->Cust_Ids as $key => $val) {
            if (!in_array($val, $resultids)) {
                $resultids[] = $val;
            }
        }

        sort($resultids);
        $str = '';
        foreach ($resultids as $key => $val) {
            $this->removeCustomerInExistingGroup($this->GroupId, $val);
            $str .= $val . ',';
        }

        return $str;
    }

    private function removeCustomerInExistingGroup($group_id, $excludeCid) {
        $query_url_permission = 'SELECT t1.group_id , t1.customers_id '
                . 'FROM customer_group_mapping as t1 '
                . 'join customer as t2 '
                . 'on FIND_IN_SET(t2.id, t1.customers_id) <> 0 '
                . 'where t2.id = ? ';
        $duplicatecustgroup = dbGetResultArray(dbGetConnection()->rawQuery($query_url_permission, [$excludeCid]));

        foreach ($duplicatecustgroup as $key => $val) {
            if ($key != $group_id) {
                $str = '';
                $newval = explode(',', $val);
                foreach ($newval as $existVal) {
                    if ($excludeCid == $existVal) {
                        continue;
                    }
                    $str .= $existVal . ',';
                }

                $data = array(
                    'customers_id' => rtrim($str, ','),
                    'modified_at' => date("Y-m-d H:i:s", time())
                );
                $updateresult = dbGetConnection()
                        ->where('group_id', $key)
                        ->update('customer_group_mapping', $data);
                if ($updateresult === false) {
                    $this->message = 'Update Error Encounted in Customer pricing mappping';
                    $this->statusCode = 403;
                    return;
                }
            }
        }
    }

}
