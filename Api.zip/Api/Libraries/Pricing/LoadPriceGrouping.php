<?php

namespace Libraries\Pricing;

defined('BASEPATH') || die('No direct script access allowed');

use Abstracted\Api;

class LoadPriceGrouping extends Api {

    private $ownerId;

    function __construct() {
        parent::__construct();
    }

    function index() {
        $this->requestType = $this->requestTypeGet;
        if (!$this->validateRequestType()) {
            return;
        }
        $this->ownerId = value_get('OwnerId');
        if (empty($this->ownerId)) {
            $this->statusCode = 400;
            $this->message = "Please Select Owner";
            return;
        }
        $this->getPriceGroupingInfo();
    }

    private function getPriceGroupingInfo() {
        $Datainfo = dbGetConnection()->where('owner_id', $this->ownerId)->where('deleted_at', NULL, 'IS')->orderby('id', 'Desc')->get('group_pricing');
        $data = array();
        foreach ($Datainfo as $key => $val) {
            $data[] = array(
                'group_id' => $val['id'],
                'groupname' => $val['name']
            );
        }
        if (!count($data)) {
            $this->message = 'No order was found';
            return;
        }
        $this->response = $data;
    }

}
