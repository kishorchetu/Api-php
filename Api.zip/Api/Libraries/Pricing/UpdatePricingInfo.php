<?php

namespace Libraries\Pricing;

defined('BASEPATH') || die('No direct script access allowed');

use Abstracted\Api;

class UpdatePricingInfo extends Api {

    private $PricingInfo;
    private $GroupId;

    function __construct() {
        parent::__construct();
    }

    function index() {
        $this->requestType = $this->requestTypePost;
        if (!$this->validateRequestType()) {
            return;
        }
        $this->GroupId = value_post('groupid');
        $this->PricingInfo = json_decode(str_replace("\\", "", value_post('pricingdata')), true);

        if (empty($this->GroupId) || empty($this->PricingInfo)) {
            $this->statusCode = 400;
            $this->message = "Please update Pricing for products";
            return;
        }

        $custids = dbGetCell(dbGetConnection()->where('group_id', $this->GroupId)->get('customer_group_mapping', 1, 'customers_id'));
        if (empty($custids)) {
            $this->statusCode = 400;
            $this->message = "Please Select Customers First";
            return;
        }

        $info = array(
            'groupid' => $this->GroupId,
            'data' => $this->PricingInfo,
            'custids' => $custids
        );
        $pricingid = dbGetCell(dbGetConnection()->where('group_id', $this->GroupId)->get('pricing_group_mapping', 1, 'id'));
        if (!$pricingid) {
            $this->savePricingInfoToGroup($info);
            $this->response = [
                'title' => 'Pricing Created',
                'response' => 'Group Pricing Created Successfully'
            ];
            return;
        }
        $data = array(
            'group_id' => $this->GroupId,
            'pricinginfo' => json_encode($info),
            'modified_at' => date("Y-m-d H:i:s", time())
        );
        $updateresult = dbGetConnection()
                ->where('id', $pricingid)
                ->update('pricing_group_mapping', $data);
        if ($updateresult === false) {
            $this->message = 'Unable to update pricing Info';
            $this->statusCode = 403;
            return;
        }
        
        if (!saveQueueJob('process-group-pricing', $data)) {
            $this->message = 'Group pricing Not Updated Please try again';
            $this->statusCode = 403;
            return;
        }
        
        $this->response = [
            'title' => 'Pricing Updated',
            'response' => 'Group pricing Updated Successfully be patience reflection takes time'
        ];
        return;
    }

    private function savePricingInfoToGroup($info) {
        $data = array(
            'group_id' => $this->GroupId,
            'pricinginfo' => json_encode($info),
            'created_at' => date("Y-m-d H:i:s", time())
        );
        $resultid = dbInsert('pricing_group_mapping', $data);
        if (!$resultid) {
            $this->statusCode = 500;
            $this->message = "Order Unable to save as temporary";
            return;
        }
    }

}
