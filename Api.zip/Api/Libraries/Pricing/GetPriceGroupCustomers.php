<?php

namespace Libraries\Pricing;

defined('BASEPATH') || die('No direct script access allowed');

use Abstracted\Api;

class GetPriceGroupCustomers extends Api {

    private $group_Id;

    function __construct() {
        parent::__construct();
    }

    function index() {
        $this->requestType = $this->requestTypeGet;
        if (!$this->validateRequestType()) {
            return;
        }
        $this->group_Id = value_get('groupId');
        if (empty($this->group_Id)) {
            $data = dbGetResultArray(dbGetConnection()->where('deleted_at', NULL, 'is')->get('customer_group_mapping', null, 'customers_id'));
            $toStr = '';
            if (!empty($data)) {
                foreach ($data as $val) {
                    $toStr .= $val . ',';
                }
                $data = rtrim($toStr, ',');
            }
            
            $existing_cids =[];
            
        } else {
            $data = dbGetCell(dbGetConnection()->where('group_id', $this->group_Id)->where('deleted_at', NULL, 'is')->get('customer_group_mapping', 1, 'customers_id'));
            $existing_cids = dbGetResultArray(dbGetConnection()->where('deleted_at', NULL, 'is')->where('group_id', $this->group_Id, '!=')->get('customer_group_mapping', null, 'customers_id'));
        }
        
        $str = '';
        if (!empty($existing_cids)) {
            foreach ($existing_cids as $val) {
                $str .= $val . ',';
            }
        }
        

        $this->response = [
            'custid' => $data,
            'uncheckids' => rtrim($str, ',')
        ];
    }
}
