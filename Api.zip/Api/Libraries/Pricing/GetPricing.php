<?php

namespace Libraries\Pricing;

defined('BASEPATH') || die('No direct script access allowed');

use Abstracted\Api;

class GetPricing extends Api {

    private $GroupId;

    function __construct() {
        parent::__construct();
    }

    function index() {
        $this->requestType = $this->requestTypeGet;
        if (!$this->validateRequestType()) {
            return;
        }
        $this->GroupId = value_get('groupId');
        if (empty($this->GroupId)) {
            $this->statusCode = 400;
            $this->message = "Please create Group First";
            return;
        }
        $this->getProductPricingInfo();
    }

    private function getProductPricingInfo() {
        $sql = "SELECT t1.id ,t1.pfamily ,t1.model ,t1.description ,t1.price ,t1.upc ,t1.weight ,t1.active_flavor as ACTIVE ,t2.productname ,t2.type FROM flavor as t1 LEFT JOIN products as t2 ON t1.pfamily = t2.family WHERE t1.active_flavor = '1' and t2.active_family='1' ORDER BY t1.pfamily ASC";
        $data = dbGetConnection()->rawQuery($sql);
        foreach ($data as $key => $val) {
                $data[$key]['group_price'] = '';
        }
        $info = dbGetCell(dbGetConnection()->where('deleted_at', NULL, 'is')->where('group_id', $this->GroupId)->get('pricing_group_mapping', 1, 'pricinginfo'));
        if ($info) {
            $json_info = json_decode($info, true);

            foreach ($data as $key => $val) {
                $data[$key]['group_price'] = '';
                if (array_key_exists($val['id'], $json_info['data'])) {
                    $data[$key]['group_price'] = $json_info['data'][$val["id"]];
                }
            }
        }
        $tabs = array_values(array_map(function($item) {
                    return str_replace(' ', '-', $item);
                }, array_unique(array_column($data, 'type'))));
        $this->response = [
            'table' => view('formats.group_pricing', ['products' => $data, 'tabs' => $tabs])
        ];
    }

}
