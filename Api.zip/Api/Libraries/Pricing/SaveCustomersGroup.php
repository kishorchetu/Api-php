<?php

namespace Libraries\Pricing;

defined('BASEPATH') || die('No direct script access allowed');

use Abstracted\Api;

class SaveCustomersGroup extends Api {

    private $Cust_Ids = [];
    private $GroupName;

    function __construct() {
        parent::__construct();
    }

    function index() {
        $this->requestType = $this->requestTypePost;
        if (!$this->validateRequestType()) {
            return;
        }
        $this->GroupName = value_post('GroupName');
        $this->Cust_Ids = value_post('customerIds');
        $this->OwnerId = value_post('ownerId');
        if (empty($this->Cust_Ids)) {
            $this->statusCode = 400;
            $this->message = "Please Select Cutomers for group";
            return;
        }

        if (empty($this->OwnerId)) {
            $this->statusCode = 400;
            $this->message = "Please Select Owner for group";
            return;
        }
        $this->saveCustomersToGroup();
    }

    private function saveCustomersToGroup() {

        if (empty($this->GroupName)) {
            $this->statusCode = 400;
            $this->message = "Please Provide Group Name";
            return;
        }

        $groupId = dbInsert('group_pricing', array('owner_id' => $this->OwnerId, 'name' => $this->GroupName));
        if (!$groupId) {
            $this->statusCode = 500;
            $this->message = "Invalid Group Name";
            return;
        }

        $CustToStr = '';
        foreach ($this->Cust_Ids as $val) {
            $CustToStr .= $val . ',';
        }
        $CustToStr = rtrim($CustToStr, ',');
        $data = array(
            'group_id' => $groupId,
            'customers_id' => $CustToStr
        );

        $resultid = dbInsert('customer_group_mapping', $data);
        if (!$resultid) {
            $this->statusCode = 500;
            $this->message = "Invalid Group Name";
            return;
        }

        $this->response = [
            'title' => $this->GroupName . ' Created Successfully !!!',
        ];
        return;
    }

}
