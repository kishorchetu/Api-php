<?php

namespace Libraries\Pricing;

defined('BASEPATH') || die('No direct script access allowed');

use Abstracted\Api;

class RemovePricingGroup extends Api {

    private $group_Id;

    function __construct() {
        parent::__construct();
    }

    function index() {
        $this->requestType = $this->requestTypeDelete;
        if (!$this->validateRequestType()) {
            return;
        }
        $this->group_Id = value_get('groupId');
        if (empty($this->group_Id)) {
            $this->statusCode = 400;
            $this->message = "Please Select group to remove";
            return;
        }

        $this->removeCustomersFromGroup();
        $this->removePricingFromGroup();
        $this->removeGroup();

        $this->response = [
            'title' => 'Group Removed Successfully !!!'
        ];
    }

    private function removeCustomersFromGroup() {
        if (!dbGetConnection()->where('group_id', $this->group_Id)->update('customer_group_mapping', array('deleted_at' => date("Y-m-d H:i:s", time())))) {
            $this->statusCode = 500;
            $this->message = 'Somthing went wrong while Deleting customers in Group';
            return;
        }
    }

    private function removePricingFromGroup() {
        if (!dbGetConnection()->where('group_id', $this->group_Id)->update('pricing_group_mapping', array('deleted_at' => date("Y-m-d H:i:s", time())))) {
            $this->statusCode = 500;
            $this->message = 'Somthing went wrong while Deleting pricing in Group';
            return;
        }
    }

    private function removeGroup() {
        if (!dbGetConnection()->where('id', $this->group_Id)->update('group_pricing', array('deleted_at' => date("Y-m-d H:i:s", time())))) {
            $this->statusCode = 500;
            $this->message = 'Somthing went wrong while Group';
            return;
        }
    }

}
