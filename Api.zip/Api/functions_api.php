<?php

spl_autoload_register(function ($class_name) {
    $fileName = base_path('Api/' . $class_name . '.php');
    require_once $fileName;
});

function getClassRelatedToUrl($url = '') {
    if (empty($url)) {
        $url = relative_url();
    }
    $urlArray = array_map(function($i) {
        return join('', array_map(function($i1) {
                    return ucfirst(strtolower($i1));
                }, explode('-', $i)));
    }, explode('/', trim($url, '/')));
    if (value_pick($urlArray, '0') === 'Api') {
        $urlArray[0] = 'Libraries';
    }
    $relativePath = join('/', $urlArray);
    if (!file_exists(base_path('Api/' . $relativePath . '.php'))) {
        $relativePath = 'Libraries/_404';
    }
    return str_replace('/', '\\', $relativePath);
}

function sendApiResponse($data) {
    $statusCode = $data->statusCode;
    $data->response= is_array($data->response)||is_object($data->response)?$data->response:[$data->response];
    if (empty($data->message) && $len = count($data->response)) {
        $data->message = $len . ' record' . ($len > 1 ? 's' : '') . ' found';
    }
    $outputArray = [
        'status' => strpos(strval($data->statusCode), '20') !== false,
        'message' => $data->message,
        'response' => $data->response,
    ];
    unset($data);
    header('Content-type:application/json; charset=utf-8');
    http_response_code($statusCode);
    echo json_encode($outputArray);
    exit();
}
