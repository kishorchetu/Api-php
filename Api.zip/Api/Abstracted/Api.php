<?php
namespace Abstracted;

defined('BASEPATH') || die('No direct script access allowed');


abstract class Api
{
    public $statusCode;
    public $message;
    public $response;
    protected $requestType;
    protected $requestTypeGet;
    protected $requestTypePost;
    protected $requestTypePut;
    protected $requestTypeDelete;

    function __construct()
    {
        $this->statusCode = 200;
        $this->message = '';
        $this->response = [];
        $this->requestTypeGet = 'GET';
        $this->requestTypePost = 'POST';
        $this->requestTypePut = 'PUT';
        $this->requestTypeDelete = 'DELETE';
        $this->requestType = $this->requestTypeGet;
    }

    abstract function index();

    private function getRequestType()
    {
        return strtoupper(value_server('REQUEST_METHOD'));
    }

    protected function validateRequestType()
    {
        if ($this->getRequestType() !== $this->requestType) {
            $this->message = "Invalid request type received: " . $this->getRequestType();
            $this->statusCode = 501;
            return false;
        }
        return true;
    }
}
